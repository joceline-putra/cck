<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-11 08:25:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:06 --> No URI present. Default controller set.
DEBUG - 2023-08-11 08:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:06 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:06 --> Total execution time: 0.2258
DEBUG - 2023-08-11 08:25:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:10 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:11 --> Total execution time: 0.8274
DEBUG - 2023-08-11 08:25:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:12 --> Total execution time: 1.0655
DEBUG - 2023-08-11 08:25:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 08:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:25:13 --> Total execution time: 0.4442
DEBUG - 2023-08-11 08:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:13 --> Total execution time: 0.3938
DEBUG - 2023-08-11 08:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:13 --> Total execution time: 0.5975
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.2700
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.3285
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.3395
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.4432
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.5149
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.5488
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.3446
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.3612
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.3670
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.3630
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.3277
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.3257
DEBUG - 2023-08-11 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:14 --> Total execution time: 0.2993
DEBUG - 2023-08-11 08:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:15 --> Total execution time: 0.2753
DEBUG - 2023-08-11 08:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:25:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:15 --> Total execution time: 0.5621
DEBUG - 2023-08-11 08:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:15 --> Total execution time: 0.5682
DEBUG - 2023-08-11 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:16 --> Total execution time: 0.3082
DEBUG - 2023-08-11 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:16 --> Total execution time: 0.1671
DEBUG - 2023-08-11 08:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:25:17 --> Total execution time: 0.2017
DEBUG - 2023-08-11 08:25:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:25:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:25:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:25:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:25:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:25:17 --> Total execution time: 0.1985
DEBUG - 2023-08-11 08:26:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:26:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:26:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:26:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:26:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:26:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:26:04 --> Total execution time: 0.2426
DEBUG - 2023-08-11 08:36:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:07 --> Total execution time: 0.2520
DEBUG - 2023-08-11 08:36:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:08 --> Total execution time: 0.3164
DEBUG - 2023-08-11 08:36:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:08 --> Total execution time: 0.4552
DEBUG - 2023-08-11 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:11 --> Total execution time: 0.2222
DEBUG - 2023-08-11 08:36:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:12 --> Total execution time: 0.1612
DEBUG - 2023-08-11 08:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:12 --> Total execution time: 0.1929
DEBUG - 2023-08-11 08:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:12 --> Total execution time: 0.1907
DEBUG - 2023-08-11 08:36:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:20 --> Total execution time: 0.2288
DEBUG - 2023-08-11 08:36:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:21 --> Total execution time: 0.2487
DEBUG - 2023-08-11 08:36:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:36:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 08:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:36:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:36:22 --> Total execution time: 0.2682
DEBUG - 2023-08-11 08:36:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:22 --> Total execution time: 0.4100
DEBUG - 2023-08-11 08:36:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:36:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:36:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:36:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:36:22 --> Total execution time: 0.5786
DEBUG - 2023-08-11 08:42:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:42:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:42:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:42:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:42:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:42:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:42:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:42:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:42:36 --> Total execution time: 0.2213
DEBUG - 2023-08-11 08:43:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:43:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:43:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:43:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:43:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:43:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:43:33 --> Total execution time: 0.2500
DEBUG - 2023-08-11 08:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:43:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:43:34 --> Total execution time: 0.1657
DEBUG - 2023-08-11 08:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:43:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:43:35 --> Total execution time: 0.1905
DEBUG - 2023-08-11 08:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:43:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:43:35 --> Total execution time: 0.1895
DEBUG - 2023-08-11 08:43:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:43:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:43:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:43:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:43:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:43:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:43:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:43:37 --> Total execution time: 0.2378
DEBUG - 2023-08-11 08:44:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:44:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:44:07 --> Total execution time: 0.2226
DEBUG - 2023-08-11 08:44:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:44:08 --> Total execution time: 0.1607
DEBUG - 2023-08-11 08:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:44:08 --> Total execution time: 0.1994
DEBUG - 2023-08-11 08:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:44:08 --> Total execution time: 0.1908
DEBUG - 2023-08-11 08:44:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:44:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:44:11 --> Total execution time: 0.2303
DEBUG - 2023-08-11 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:44:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:44:28 --> Total execution time: 0.8494
DEBUG - 2023-08-11 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:44:29 --> Total execution time: 0.1623
DEBUG - 2023-08-11 08:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:44:29 --> Total execution time: 0.1988
DEBUG - 2023-08-11 08:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:44:29 --> Total execution time: 0.1921
DEBUG - 2023-08-11 08:44:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:44:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:44:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:44:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:44:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:44:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:44:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:44:31 --> Total execution time: 0.2339
DEBUG - 2023-08-11 08:45:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:03 --> Total execution time: 0.2320
DEBUG - 2023-08-11 08:45:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:04 --> Total execution time: 0.1818
DEBUG - 2023-08-11 08:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:04 --> Total execution time: 0.2169
DEBUG - 2023-08-11 08:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:04 --> Total execution time: 0.2071
DEBUG - 2023-08-11 08:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:07 --> Total execution time: 0.4121
DEBUG - 2023-08-11 08:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:13 --> Total execution time: 0.2334
DEBUG - 2023-08-11 08:45:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:14 --> Total execution time: 0.1666
DEBUG - 2023-08-11 08:45:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:14 --> Total execution time: 0.1943
DEBUG - 2023-08-11 08:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:15 --> Total execution time: 0.1906
DEBUG - 2023-08-11 08:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:19 --> Total execution time: 0.2265
DEBUG - 2023-08-11 08:45:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:20 --> Total execution time: 0.1643
DEBUG - 2023-08-11 08:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:45:20 --> Total execution time: 0.1952
DEBUG - 2023-08-11 08:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:20 --> Total execution time: 0.1936
DEBUG - 2023-08-11 08:45:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:45:22 --> Total execution time: 0.2323
DEBUG - 2023-08-11 08:45:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:45:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:45:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:45:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:45:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:45:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:45:24 --> PHPMailer class is loaded.
ERROR - 2023-08-11 15:45:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\Wamp\www\git\jrn\application\controllers\Referensi.php 312
DEBUG - 2023-08-11 15:45:25 --> Total execution time: 0.3835
DEBUG - 2023-08-11 08:46:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:46:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:46:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:46:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:46:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:46:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:46:14 --> Total execution time: 0.2213
DEBUG - 2023-08-11 08:46:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:46:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:46:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:46:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:46:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:46:15 --> Total execution time: 0.1630
DEBUG - 2023-08-11 08:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:46:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:46:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:46:15 --> Total execution time: 0.1973
DEBUG - 2023-08-11 08:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:46:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:46:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:46:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:46:15 --> Total execution time: 0.1867
DEBUG - 2023-08-11 08:46:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:46:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:46:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:46:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:46:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:46:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:46:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:46:17 --> Total execution time: 0.2306
DEBUG - 2023-08-11 08:47:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:47:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:47:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:47:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:47:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:47:00 --> Total execution time: 0.2789
DEBUG - 2023-08-11 08:47:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:47:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:47:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:47:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:47:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:47:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:47:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:47:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:47:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 08:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:47:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:47:01 --> Total execution time: 0.2671
DEBUG - 2023-08-11 08:47:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:47:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:47:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:47:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:47:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:01 --> Total execution time: 0.4041
DEBUG - 2023-08-11 08:47:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:47:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:47:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:47:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:47:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:01 --> Total execution time: 0.5698
DEBUG - 2023-08-11 08:47:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:47:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:47:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:47:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:47:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:47:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:47:26 --> Total execution time: 0.2694
DEBUG - 2023-08-11 08:47:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:47:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:47:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:47:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:47:26 --> Total execution time: 0.1637
DEBUG - 2023-08-11 08:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:47:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:47:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:47:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:47:27 --> Total execution time: 0.1977
DEBUG - 2023-08-11 08:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:47:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:47:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:47:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:47:27 --> Total execution time: 0.1916
DEBUG - 2023-08-11 08:47:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:47:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:47:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:47:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:47:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:47:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:47:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:47:29 --> Total execution time: 0.2316
DEBUG - 2023-08-11 08:48:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:48:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:48:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:48:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:48:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:48:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:48:21 --> Total execution time: 0.2511
DEBUG - 2023-08-11 08:48:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:48:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:48:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:48:22 --> Total execution time: 0.1660
DEBUG - 2023-08-11 08:48:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:48:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:48:22 --> Total execution time: 0.1990
DEBUG - 2023-08-11 08:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:48:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:48:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:48:22 --> Total execution time: 0.2135
DEBUG - 2023-08-11 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:48:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:48:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:48:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:48:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:48:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:48:25 --> Total execution time: 0.2235
DEBUG - 2023-08-11 08:48:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:48:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:48:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:48:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:48:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:48:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:48:56 --> Total execution time: 0.2395
DEBUG - 2023-08-11 08:48:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:48:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:48:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:48:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:48:57 --> Total execution time: 0.1595
DEBUG - 2023-08-11 08:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:48:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 15:48:57 --> Total execution time: 0.2016
DEBUG - 2023-08-11 08:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:48:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:48:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:48:57 --> Total execution time: 0.1922
DEBUG - 2023-08-11 08:49:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:49:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:49:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:49:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:49:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:49:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:49:00 --> Total execution time: 0.2291
DEBUG - 2023-08-11 08:49:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:49:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:49:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:49:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:49:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:49:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:49:09 --> Total execution time: 0.2197
DEBUG - 2023-08-11 08:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:49:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:49:09 --> Total execution time: 0.1725
DEBUG - 2023-08-11 08:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:49:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:49:09 --> Total execution time: 0.1918
DEBUG - 2023-08-11 08:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:49:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:49:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:49:09 --> Total execution time: 0.1885
DEBUG - 2023-08-11 08:49:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:49:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:49:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:49:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:49:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:49:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:49:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:49:13 --> Total execution time: 0.2504
DEBUG - 2023-08-11 08:50:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:50:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:50:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:50:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:50:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:50:03 --> Total execution time: 0.3244
DEBUG - 2023-08-11 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:50:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:50:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:50:05 --> Total execution time: 0.1764
DEBUG - 2023-08-11 08:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:50:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:50:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 15:50:05 --> Total execution time: 0.1907
DEBUG - 2023-08-11 08:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:50:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:50:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:50:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:50:05 --> Total execution time: 0.1924
DEBUG - 2023-08-11 08:50:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:50:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:50:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:50:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:50:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:50:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:50:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:50:10 --> Total execution time: 0.2228
DEBUG - 2023-08-11 08:51:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:01 --> Total execution time: 0.2260
DEBUG - 2023-08-11 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 15:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 08:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:02 --> Total execution time: 0.1605
DEBUG - 2023-08-11 08:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:02 --> Total execution time: 0.1941
DEBUG - 2023-08-11 08:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:02 --> Total execution time: 0.2088
DEBUG - 2023-08-11 08:51:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:04 --> Total execution time: 0.2264
DEBUG - 2023-08-11 08:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:07 --> Total execution time: 0.2174
DEBUG - 2023-08-11 08:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 08:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 15:51:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 08:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 15:51:08 --> Total execution time: 0.1664
DEBUG - 2023-08-11 08:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:08 --> Total execution time: 0.1920
DEBUG - 2023-08-11 08:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:08 --> Total execution time: 0.2006
DEBUG - 2023-08-11 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:10 --> Total execution time: 0.2186
DEBUG - 2023-08-11 08:51:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:51:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:51:59 --> Total execution time: 0.2340
DEBUG - 2023-08-11 08:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:51:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:51:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:51:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:51:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:00 --> Total execution time: 0.5661
DEBUG - 2023-08-11 08:52:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:52:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:52:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:52:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:52:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:01 --> Total execution time: 0.1601
DEBUG - 2023-08-11 08:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:52:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:01 --> Total execution time: 0.1916
DEBUG - 2023-08-11 08:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:52:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:01 --> Total execution time: 0.1957
DEBUG - 2023-08-11 08:52:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:52:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:52:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:11 --> Total execution time: 0.2142
DEBUG - 2023-08-11 08:52:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:52:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:52:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:52:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:52:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:52:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:41 --> Total execution time: 0.2165
DEBUG - 2023-08-11 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:52:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:42 --> Total execution time: 0.1623
DEBUG - 2023-08-11 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:52:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:42 --> Total execution time: 0.1907
DEBUG - 2023-08-11 08:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:52:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:52:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:52:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:52:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:43 --> Total execution time: 0.2076
DEBUG - 2023-08-11 08:52:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:52:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:52:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:52:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:52:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:52:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:52:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:52:47 --> Total execution time: 0.2443
DEBUG - 2023-08-11 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:54:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:54:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:54:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:54:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:54:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:54:22 --> Total execution time: 0.2331
DEBUG - 2023-08-11 08:54:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:54:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:54:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:54:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:54:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:54:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:54:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:54:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:54:23 --> Total execution time: 0.1642
DEBUG - 2023-08-11 08:54:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:54:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:54:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:54:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:54:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:54:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:54:23 --> Total execution time: 0.1955
DEBUG - 2023-08-11 08:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:54:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:54:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:54:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:54:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:54:24 --> Total execution time: 0.2072
DEBUG - 2023-08-11 08:54:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:54:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:54:27 --> Total execution time: 0.2325
DEBUG - 2023-08-11 08:55:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:55:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:55:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:55:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:55:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:55:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:55:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:55:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:55:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:55:02 --> Total execution time: 0.3179
DEBUG - 2023-08-11 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:55:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:55:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:55:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:55:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:55:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:55:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:55:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:55:18 --> Total execution time: 0.2797
DEBUG - 2023-08-11 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:55:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:55:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:55:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:55:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:55:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:55:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:55:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:55:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:55:26 --> Total execution time: 0.2978
DEBUG - 2023-08-11 08:56:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:56:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:56:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:56:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:56:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:56:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:56:55 --> Total execution time: 0.2308
DEBUG - 2023-08-11 08:56:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:56:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:56:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:56:57 --> Total execution time: 0.1649
DEBUG - 2023-08-11 08:56:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:56:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:56:57 --> Total execution time: 0.2111
DEBUG - 2023-08-11 08:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:56:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:56:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:56:57 --> Total execution time: 0.1996
DEBUG - 2023-08-11 08:56:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:56:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:56:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:56:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:56:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:56:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:57:00 --> Total execution time: 0.2288
DEBUG - 2023-08-11 08:58:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:58:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:58:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:58:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:58:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:58:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:58:38 --> Total execution time: 0.2220
DEBUG - 2023-08-11 08:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:58:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:58:39 --> Total execution time: 0.1610
DEBUG - 2023-08-11 08:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:58:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:58:39 --> Total execution time: 0.1936
DEBUG - 2023-08-11 08:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:58:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:58:39 --> Total execution time: 0.1910
DEBUG - 2023-08-11 08:58:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:58:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:58:42 --> Total execution time: 0.2891
DEBUG - 2023-08-11 08:58:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:58:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:58:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:58:44 --> Total execution time: 0.1811
DEBUG - 2023-08-11 08:59:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:59:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:59:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:59:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:59:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:59:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:59:12 --> Total execution time: 0.2159
DEBUG - 2023-08-11 08:59:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:59:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:59:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:59:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:59:14 --> Total execution time: 0.1695
DEBUG - 2023-08-11 08:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:59:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:59:14 --> Total execution time: 0.1969
DEBUG - 2023-08-11 08:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:59:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:59:14 --> Total execution time: 0.1862
DEBUG - 2023-08-11 08:59:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:59:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:59:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:59:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:59:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:59:19 --> Total execution time: 0.2396
DEBUG - 2023-08-11 08:59:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 08:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 08:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 08:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 08:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 15:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 15:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 15:59:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 15:59:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 15:59:21 --> Total execution time: 0.2860
DEBUG - 2023-08-11 09:00:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:00:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:00:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:00:49 --> Total execution time: 6.9058
DEBUG - 2023-08-11 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:00:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:00:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:00:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 09:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 16:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:00:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:00:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:00:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:00:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:00:52 --> Total execution time: 2.4796
DEBUG - 2023-08-11 09:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:00:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:00:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:00:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:00:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:00:52 --> Total execution time: 2.4625
DEBUG - 2023-08-11 09:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:00:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:00:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:00:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:00:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:00:52 --> Total execution time: 2.4645
DEBUG - 2023-08-11 09:00:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:00:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:00:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:00:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:00:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:00:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:00:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:00:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:00:55 --> Total execution time: 0.2451
DEBUG - 2023-08-11 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:01:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:01:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:01:08 --> Total execution time: 0.2422
DEBUG - 2023-08-11 09:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:01:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:01:08 --> Total execution time: 0.1615
DEBUG - 2023-08-11 09:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:01:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:01:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:01:09 --> Total execution time: 0.1940
DEBUG - 2023-08-11 09:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:01:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:01:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:01:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:01:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:01:09 --> Total execution time: 0.1922
DEBUG - 2023-08-11 09:01:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:01:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:01:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:01:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:01:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:01:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:01:13 --> Total execution time: 0.2214
DEBUG - 2023-08-11 09:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-11 09:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-11 09:01:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-11 09:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-11 09:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-11 16:01:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-11 16:01:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-11 16:01:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-11 16:01:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 16:01:14 --> Total execution time: 0.3083
