<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-30 01:27:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:00 --> No URI present. Default controller set.
DEBUG - 2023-08-30 01:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:31 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:33 --> Total execution time: 34.8914
DEBUG - 2023-08-30 01:27:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:46 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:48 --> Total execution time: 1.5860
DEBUG - 2023-08-30 01:27:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:50 --> Total execution time: 2.5634
DEBUG - 2023-08-30 01:27:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:27:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:27:54 --> Total execution time: 0.8777
DEBUG - 2023-08-30 01:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:54 --> Total execution time: 0.7853
DEBUG - 2023-08-30 01:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:54 --> Total execution time: 1.2722
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.3076
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.3762
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.4220
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.4498
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.4515
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.5308
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.2656
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.2783
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.3476
DEBUG - 2023-08-30 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:27:57 --> Total execution time: 0.3517
DEBUG - 2023-08-30 01:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:27:58 --> Total execution time: 0.3513
DEBUG - 2023-08-30 01:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:58 --> Total execution time: 0.3408
DEBUG - 2023-08-30 01:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:58 --> Total execution time: 0.3701
DEBUG - 2023-08-30 01:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:58 --> Total execution time: 0.3254
DEBUG - 2023-08-30 01:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:59 --> Total execution time: 1.4147
DEBUG - 2023-08-30 01:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:27:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:27:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:27:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:27:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:27:59 --> Total execution time: 1.5207
DEBUG - 2023-08-30 01:31:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:08 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:31:08 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
ERROR - 2023-08-30 08:31:08 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
DEBUG - 2023-08-30 08:31:08 --> Total execution time: 0.4244
DEBUG - 2023-08-30 01:31:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:09 --> Total execution time: 0.1634
DEBUG - 2023-08-30 01:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:09 --> Total execution time: 0.2209
DEBUG - 2023-08-30 01:31:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:39 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:31:39 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 08:31:39 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 08:31:39 --> Total execution time: 0.5998
DEBUG - 2023-08-30 01:31:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 01:31:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:31:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:39 --> Total execution time: 0.1631
DEBUG - 2023-08-30 01:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:40 --> Total execution time: 0.2206
DEBUG - 2023-08-30 01:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Total execution time: 0.4375
DEBUG - 2023-08-30 01:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:42 --> Total execution time: 0.1631
DEBUG - 2023-08-30 01:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Total execution time: 0.2120
DEBUG - 2023-08-30 01:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:31:42 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:31:42 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:48 --> Total execution time: 0.2083
DEBUG - 2023-08-30 01:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:48 --> Total execution time: 0.1624
DEBUG - 2023-08-30 01:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:49 --> Total execution time: 0.2209
DEBUG - 2023-08-30 01:31:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:31:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:31:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:31:49 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:31:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:31:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:31:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:31:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:31:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:31:49 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:34:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:16 --> Total execution time: 0.3492
DEBUG - 2023-08-30 01:34:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:17 --> Total execution time: 0.1896
DEBUG - 2023-08-30 01:34:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:19 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:20 --> Total execution time: 0.5178
DEBUG - 2023-08-30 01:34:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:20 --> Total execution time: 0.2279
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.1871
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.1649
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.2142
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.2132
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.2614
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.3102
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.3463
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.3759
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.3658
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.2783
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.2717
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.2600
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:21 --> Total execution time: 0.2684
DEBUG - 2023-08-30 01:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:22 --> Total execution time: 0.2822
DEBUG - 2023-08-30 01:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:22 --> Total execution time: 0.2816
DEBUG - 2023-08-30 01:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:22 --> Total execution time: 0.2961
DEBUG - 2023-08-30 01:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:22 --> Total execution time: 0.3023
DEBUG - 2023-08-30 01:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Total execution time: 0.3033
DEBUG - 2023-08-30 01:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:22 --> Total execution time: 0.3104
DEBUG - 2023-08-30 01:34:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:34:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:34:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:34:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:34:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:34:37 --> Total execution time: 0.1964
DEBUG - 2023-08-30 01:35:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:22 --> Total execution time: 0.1999
DEBUG - 2023-08-30 01:35:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:24 --> Total execution time: 0.1866
DEBUG - 2023-08-30 01:35:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:26 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:26 --> Total execution time: 0.5372
DEBUG - 2023-08-30 01:35:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:26 --> Total execution time: 0.2170
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.1861
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.1872
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.2235
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.1861
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.2285
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.2690
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.3065
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.3084
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.3002
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.2710
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:35:27 --> Total execution time: 0.2869
DEBUG - 2023-08-30 01:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:35:28 --> Total execution time: 0.2981
DEBUG - 2023-08-30 01:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:35:28 --> Total execution time: 0.3001
DEBUG - 2023-08-30 01:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:35:28 --> Total execution time: 0.3017
DEBUG - 2023-08-30 01:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:35:28 --> Total execution time: 0.2982
DEBUG - 2023-08-30 01:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:35:28 --> Total execution time: 0.2924
DEBUG - 2023-08-30 01:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:35:28 --> Total execution time: 0.2701
DEBUG - 2023-08-30 01:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Total execution time: 0.2824
DEBUG - 2023-08-30 01:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:28 --> Total execution time: 0.2812
DEBUG - 2023-08-30 01:35:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Total execution time: 0.1976
DEBUG - 2023-08-30 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:30 --> Total execution time: 0.1572
DEBUG - 2023-08-30 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Total execution time: 0.2187
DEBUG - 2023-08-30 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:35:30 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:35:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:35:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:35:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:35:30 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:36:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:36:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:36:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:36:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:36:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:36:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:36:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:36:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:36:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:36:30 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:36:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:36:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:36:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:36:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:36:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:36:30 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:37:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:37:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:37:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:37:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:37:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:37:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:37:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:21 --> Total execution time: 0.1993
DEBUG - 2023-08-30 01:37:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:37:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:37:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:37:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:37:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:37:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:37:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:37:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:37:22 --> Total execution time: 0.1682
DEBUG - 2023-08-30 01:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:37:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:37:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:23 --> Total execution time: 0.2207
DEBUG - 2023-08-30 01:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:37:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:37:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:37:23 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:37:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:37:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:37:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:37:23 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:37:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:37:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:37:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:37:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:37:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:37:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:37:26 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
ERROR - 2023-08-30 08:37:26 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
DEBUG - 2023-08-30 08:37:26 --> Total execution time: 0.3970
DEBUG - 2023-08-30 01:37:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:37:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:37:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:37:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:37:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:37:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:37:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:37:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:37:27 --> Total execution time: 0.1657
DEBUG - 2023-08-30 01:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:37:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:37:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:37:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:37:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:37:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:37:28 --> Total execution time: 0.2190
DEBUG - 2023-08-30 01:38:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:38:04 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
ERROR - 2023-08-30 08:38:04 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
DEBUG - 2023-08-30 08:38:04 --> Total execution time: 0.1927
DEBUG - 2023-08-30 01:38:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:05 --> Total execution time: 0.1665
DEBUG - 2023-08-30 01:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:05 --> Total execution time: 0.2164
DEBUG - 2023-08-30 01:38:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:38:08 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:38:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:38:10 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
ERROR - 2023-08-30 08:38:10 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
DEBUG - 2023-08-30 08:38:10 --> Total execution time: 0.1940
DEBUG - 2023-08-30 01:38:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:11 --> Total execution time: 0.1966
DEBUG - 2023-08-30 01:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:12 --> Total execution time: 0.2185
DEBUG - 2023-08-30 01:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:38:34 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
ERROR - 2023-08-30 08:38:34 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
DEBUG - 2023-08-30 08:38:34 --> Total execution time: 0.2179
DEBUG - 2023-08-30 01:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:35 --> Total execution time: 0.1602
DEBUG - 2023-08-30 01:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:36 --> Total execution time: 0.2194
DEBUG - 2023-08-30 01:38:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:39 --> Total execution time: 0.2835
DEBUG - 2023-08-30 01:38:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:40 --> Total execution time: 0.1648
DEBUG - 2023-08-30 01:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:40 --> Total execution time: 0.2465
DEBUG - 2023-08-30 01:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:42 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:38:42 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
ERROR - 2023-08-30 08:38:42 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
DEBUG - 2023-08-30 08:38:42 --> Total execution time: 0.2531
DEBUG - 2023-08-30 01:38:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:43 --> Total execution time: 0.1700
DEBUG - 2023-08-30 01:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:43 --> Total execution time: 0.2155
DEBUG - 2023-08-30 01:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:45 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:38:45 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
ERROR - 2023-08-30 08:38:45 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
DEBUG - 2023-08-30 08:38:45 --> Total execution time: 0.1908
DEBUG - 2023-08-30 01:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:46 --> Total execution time: 0.1720
DEBUG - 2023-08-30 01:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:38:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:38:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:46 --> Total execution time: 0.2142
DEBUG - 2023-08-30 01:39:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:39:37 --> Total execution time: 0.1944
DEBUG - 2023-08-30 01:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:39:39 --> Total execution time: 0.2127
DEBUG - 2023-08-30 01:39:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:39:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:41 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:41 --> Total execution time: 0.5492
DEBUG - 2023-08-30 01:39:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:42 --> Total execution time: 0.2247
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:39:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.1905
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.1630
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2338
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.1896
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2064
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2098
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2907
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2577
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2223
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2505
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2343
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2597
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2612
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2586
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2470
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2550
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2376
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:39:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:43 --> Total execution time: 0.2513
DEBUG - 2023-08-30 01:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:39:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:44 --> Total execution time: 0.2496
DEBUG - 2023-08-30 01:39:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:39:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:39:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:39:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:39:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:39:59 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:39:59 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
ERROR - 2023-08-30 08:39:59 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
DEBUG - 2023-08-30 08:39:59 --> Total execution time: 0.1950
DEBUG - 2023-08-30 01:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:00 --> Total execution time: 0.1655
DEBUG - 2023-08-30 01:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:00 --> Total execution time: 0.2133
DEBUG - 2023-08-30 01:40:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:03 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:40:03 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
ERROR - 2023-08-30 08:40:03 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
DEBUG - 2023-08-30 08:40:03 --> Total execution time: 0.1940
DEBUG - 2023-08-30 01:40:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:04 --> Total execution time: 0.1618
DEBUG - 2023-08-30 01:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:04 --> Total execution time: 0.2444
DEBUG - 2023-08-30 01:40:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:40:04 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:40:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:40:26 --> 404 Page Not Found: 
DEBUG - 2023-08-30 01:40:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:27 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:40:27 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
ERROR - 2023-08-30 08:40:27 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
DEBUG - 2023-08-30 08:40:27 --> Total execution time: 0.1895
DEBUG - 2023-08-30 01:40:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:28 --> Total execution time: 0.1685
DEBUG - 2023-08-30 01:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:28 --> Total execution time: 0.2086
DEBUG - 2023-08-30 01:40:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:31 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:40:31 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
ERROR - 2023-08-30 08:40:31 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
DEBUG - 2023-08-30 08:40:31 --> Total execution time: 0.1891
DEBUG - 2023-08-30 01:40:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:32 --> Total execution time: 0.1669
DEBUG - 2023-08-30 01:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:32 --> Total execution time: 0.2192
DEBUG - 2023-08-30 01:40:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:34 --> Total execution time: 0.1955
DEBUG - 2023-08-30 01:40:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:40:35 --> Total execution time: 0.1725
DEBUG - 2023-08-30 01:40:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:35 --> Total execution time: 0.2467
DEBUG - 2023-08-30 01:40:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 08:40:36 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
ERROR - 2023-08-30 08:40:36 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
DEBUG - 2023-08-30 08:40:36 --> Total execution time: 0.1976
DEBUG - 2023-08-30 01:40:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:37 --> Total execution time: 0.1610
DEBUG - 2023-08-30 01:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:37 --> Total execution time: 0.2190
DEBUG - 2023-08-30 01:40:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:37 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:40:37 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
ERROR - 2023-08-30 08:40:37 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
DEBUG - 2023-08-30 08:40:37 --> Total execution time: 0.2009
DEBUG - 2023-08-30 01:40:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:40:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:38 --> Total execution time: 0.1649
DEBUG - 2023-08-30 01:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:40:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:40:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:40:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:40:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:38 --> Total execution time: 0.2154
DEBUG - 2023-08-30 01:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:50:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:50:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:50:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:50:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:50:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:50:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:50:47 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:50:47 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
ERROR - 2023-08-30 08:50:47 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\label.php 233
DEBUG - 2023-08-30 08:50:47 --> Total execution time: 3.2122
DEBUG - 2023-08-30 01:50:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:50:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:50:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:50:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:50:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:50:52 --> Total execution time: 3.7994
DEBUG - 2023-08-30 01:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:50:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:50:53 --> Total execution time: 3.8570
DEBUG - 2023-08-30 01:50:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:50:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:51:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:51:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:51:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:51:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:51:00 --> Total execution time: 5.4881
DEBUG - 2023-08-30 01:51:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:51:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:51:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:51:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:51:03 --> Total execution time: 2.4384
DEBUG - 2023-08-30 01:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:51:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:51:03 --> Total execution time: 2.4835
DEBUG - 2023-08-30 01:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:51:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:51:03 --> Total execution time: 2.4721
DEBUG - 2023-08-30 01:52:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:11 --> Total execution time: 0.3149
DEBUG - 2023-08-30 01:52:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:12 --> Total execution time: 0.1664
DEBUG - 2023-08-30 01:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:52:12 --> Total execution time: 0.2528
DEBUG - 2023-08-30 01:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:12 --> Total execution time: 0.2647
DEBUG - 2023-08-30 01:52:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:18 --> Total execution time: 0.2698
DEBUG - 2023-08-30 01:52:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:18 --> Total execution time: 0.2513
DEBUG - 2023-08-30 01:52:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:39 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:52:39 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 08:52:39 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 08:52:39 --> Total execution time: 0.2848
DEBUG - 2023-08-30 01:52:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:40 --> Total execution time: 0.1616
DEBUG - 2023-08-30 01:52:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:40 --> Total execution time: 0.2241
DEBUG - 2023-08-30 01:52:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:41 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 214
ERROR - 2023-08-30 08:52:41 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 214
DEBUG - 2023-08-30 08:52:41 --> Total execution time: 0.3507
DEBUG - 2023-08-30 01:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:42 --> Total execution time: 0.1676
DEBUG - 2023-08-30 01:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:42 --> Total execution time: 0.2308
DEBUG - 2023-08-30 01:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:44 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:52:44 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 08:52:44 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 08:52:44 --> Total execution time: 0.2719
DEBUG - 2023-08-30 01:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 01:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:52:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 01:52:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:52:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:44 --> Total execution time: 0.1673
DEBUG - 2023-08-30 01:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:45 --> Total execution time: 0.2212
DEBUG - 2023-08-30 01:52:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:48 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 214
ERROR - 2023-08-30 08:52:48 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 214
DEBUG - 2023-08-30 08:52:48 --> Total execution time: 0.2770
DEBUG - 2023-08-30 01:52:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 01:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:52:49 --> Total execution time: 0.1661
DEBUG - 2023-08-30 01:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:52:49 --> Total execution time: 0.2262
DEBUG - 2023-08-30 01:52:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:52:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:52:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:52:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:52:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:52:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:52:59 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:52:59 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 08:52:59 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 08:52:59 --> Total execution time: 0.2941
DEBUG - 2023-08-30 01:53:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:53:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:53:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:53:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:53:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:53:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:53:00 --> Total execution time: 0.1644
DEBUG - 2023-08-30 01:53:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:53:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:53:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:53:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:53:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:53:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:53:00 --> Total execution time: 0.2233
DEBUG - 2023-08-30 01:53:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:53:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:53:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:53:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:53:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:53:12 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 214
ERROR - 2023-08-30 08:53:12 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 214
DEBUG - 2023-08-30 08:53:12 --> Total execution time: 0.2751
DEBUG - 2023-08-30 01:53:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:53:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:53:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:53:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:53:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:53:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:53:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:53:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:53:13 --> Total execution time: 0.1641
DEBUG - 2023-08-30 01:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:53:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:53:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:53:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:53:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:53:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:53:13 --> Total execution time: 0.2217
DEBUG - 2023-08-30 01:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:59:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:59:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:59:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:59:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:59:54 --> PHPMailer class is loaded.
ERROR - 2023-08-30 08:59:54 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 08:59:54 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 08:59:54 --> Total execution time: 0.2904
DEBUG - 2023-08-30 01:59:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:59:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:59:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:59:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:59:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:59:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:59:55 --> Total execution time: 0.1579
DEBUG - 2023-08-30 01:59:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 01:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 01:59:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 01:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 01:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:59:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 08:59:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 08:59:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 08:59:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:59:55 --> Total execution time: 0.2240
DEBUG - 2023-08-30 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:00:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:00:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:00:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:00:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:00:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:00:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:00:04 --> PHPMailer class is loaded.
ERROR - 2023-08-30 09:00:04 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 09:00:04 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 09:00:04 --> Total execution time: 0.2794
DEBUG - 2023-08-30 02:00:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:00:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:00:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:00:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:00:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:00:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:00:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:00:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:00:05 --> Total execution time: 0.1769
DEBUG - 2023-08-30 02:00:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:00:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:00:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:00:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:00:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:00:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:00:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:00:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:00:05 --> Total execution time: 0.2272
DEBUG - 2023-08-30 02:00:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:00:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-08-30 02:01:12 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-30 02:01:12 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=7828 C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-30 02:01:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-30 02:01:12 --> Unable to connect to the database
DEBUG - 2023-08-30 02:01:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:01:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:01:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:01:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:01:34 --> PHPMailer class is loaded.
ERROR - 2023-08-30 09:01:35 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 09:01:35 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 09:01:35 --> Total execution time: 0.2891
DEBUG - 2023-08-30 02:01:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:01:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:01:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:01:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:01:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:01:36 --> Total execution time: 0.1630
DEBUG - 2023-08-30 02:01:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:01:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:01:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:01:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:01:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:01:36 --> Total execution time: 0.2308
DEBUG - 2023-08-30 02:01:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:01:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:01:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:01:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:01:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:01:44 --> PHPMailer class is loaded.
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: account_purchase C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 107
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: account_sales C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 130
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: account_inventory C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 153
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 214
ERROR - 2023-08-30 09:01:44 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\asset.php 214
DEBUG - 2023-08-30 09:01:44 --> Total execution time: 0.2669
DEBUG - 2023-08-30 02:01:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:01:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:01:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:01:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:01:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:01:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:01:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:01:45 --> Total execution time: 0.1617
DEBUG - 2023-08-30 02:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:01:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:01:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:01:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:01:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:01:45 --> Total execution time: 0.2243
DEBUG - 2023-08-30 02:47:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:06 --> Total execution time: 0.3976
DEBUG - 2023-08-30 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:08 --> Total execution time: 0.1688
DEBUG - 2023-08-30 02:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 02:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:47:08 --> Total execution time: 0.2514
DEBUG - 2023-08-30 02:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:08 --> Total execution time: 0.2769
DEBUG - 2023-08-30 02:47:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:47:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:15 --> Total execution time: 0.2024
DEBUG - 2023-08-30 02:47:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:47:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 09:47:18 --> 404 Page Not Found: 
DEBUG - 2023-08-30 02:47:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:47:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:20 --> Total execution time: 0.2035
DEBUG - 2023-08-30 02:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 02:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 02:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 02:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:21 --> Total execution time: 0.1767
DEBUG - 2023-08-30 02:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 02:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 02:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:47:21 --> Total execution time: 0.2497
DEBUG - 2023-08-30 02:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 09:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:47:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 09:47:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:47:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:47:21 --> Total execution time: 0.2744
DEBUG - 2023-08-30 06:16:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:16:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 06:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:16:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 06:16:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 06:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:16:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:16:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:44 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:44 --> Total execution time: 0.5963
DEBUG - 2023-08-30 06:16:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:16:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 06:16:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:16:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:16:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:16:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:16:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:50 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:50 --> Total execution time: 0.6937
DEBUG - 2023-08-30 06:16:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:16:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 06:16:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:16:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:16:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:16:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:16:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:51 --> Total execution time: 0.2066
DEBUG - 2023-08-30 06:16:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:16:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 06:16:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:16:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:16:52 --> Total execution time: 0.1657
DEBUG - 2023-08-30 06:16:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 06:16:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:16:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:16:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 06:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 13:16:52 --> Total execution time: 0.2145
DEBUG - 2023-08-30 06:16:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:16:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:16:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:16:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:16:52 --> Total execution time: 0.3505
DEBUG - 2023-08-30 06:17:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:17:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 06:17:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:17:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:17:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:17:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:17:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:07 --> Total execution time: 0.2131
DEBUG - 2023-08-30 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 06:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 06:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 06:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 06:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:17:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:17:08 --> Total execution time: 0.1693
DEBUG - 2023-08-30 06:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 06:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:17:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:17:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 06:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 13:17:08 --> Total execution time: 0.2457
DEBUG - 2023-08-30 06:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 13:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 13:17:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 13:17:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 13:17:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 13:17:08 --> Total execution time: 0.2769
DEBUG - 2023-08-30 08:25:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:25:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:25:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:25:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:25:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:25:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:25:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:25:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:25:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:25:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:25:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:25:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:25:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:50 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:50 --> Total execution time: 0.1747
DEBUG - 2023-08-30 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:25:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:25:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:25:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:25:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:25:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:25:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:53 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:54 --> Total execution time: 0.6343
DEBUG - 2023-08-30 08:25:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:25:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:25:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:25:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:25:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:25:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:25:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:54 --> Total execution time: 0.2031
DEBUG - 2023-08-30 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:25:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:25:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:25:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:25:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:25:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:25:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:25:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:25:55 --> Total execution time: 0.1649
DEBUG - 2023-08-30 08:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:25:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:25:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:25:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:25:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:25:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:25:56 --> Total execution time: 0.2601
DEBUG - 2023-08-30 08:25:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:25:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:25:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:25:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:25:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:25:56 --> Total execution time: 0.2790
DEBUG - 2023-08-30 08:33:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:33:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:33:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:33:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:33:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:33:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:33:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:33:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:33:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 15:33:14 --> Severity: Notice --> Undefined variable: image_width C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\asset\index_js.php 19
ERROR - 2023-08-30 15:33:14 --> Severity: Notice --> Undefined variable: image_height C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\asset\index_js.php 20
DEBUG - 2023-08-30 15:33:14 --> Total execution time: 0.2158
DEBUG - 2023-08-30 08:33:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:33:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:33:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:33:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:33:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:33:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:33:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:33:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:33:16 --> Total execution time: 0.1718
DEBUG - 2023-08-30 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:33:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:33:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:33:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:33:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:33:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:33:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:34:00 --> Total execution time: 0.2162
DEBUG - 2023-08-30 08:34:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:34:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:34:01 --> Total execution time: 0.1822
DEBUG - 2023-08-30 08:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:34:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:34:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:34:01 --> Total execution time: 0.2746
DEBUG - 2023-08-30 08:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:34:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:34:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:34:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:34:01 --> Total execution time: 0.2981
DEBUG - 2023-08-30 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:38:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:38:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:38:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:38:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:38:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:18 --> Total execution time: 0.2270
DEBUG - 2023-08-30 08:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:38:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:38:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:38:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:38:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:38:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:38:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:38:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 15:38:20 --> Total execution time: 0.1896
DEBUG - 2023-08-30 08:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:38:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:38:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:38:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:38:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:38:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:38:21 --> Total execution time: 0.2366
DEBUG - 2023-08-30 08:38:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:38:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:38:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:38:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:38:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:21 --> Total execution time: 0.3914
DEBUG - 2023-08-30 08:38:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:38:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:38:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:38:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:38:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:38:55 --> Total execution time: 0.2450
DEBUG - 2023-08-30 08:38:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:38:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:38:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:38:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:38:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:38:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:38:57 --> Total execution time: 0.2327
DEBUG - 2023-08-30 08:38:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:38:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:38:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:38:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:38:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:38:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:38:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:38:59 --> Total execution time: 0.2215
DEBUG - 2023-08-30 08:39:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:39:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:39:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:39:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:39:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 15:39:08 --> Severity: Notice --> Undefined property: Asset::$Produk_model C:\Wamp\www\git\jrn\application\controllers\Asset.php 309
ERROR - 2023-08-30 15:39:08 --> Severity: error --> Exception: Call to a member function update_produk() on null C:\Wamp\www\git\jrn\application\controllers\Asset.php 309
DEBUG - 2023-08-30 08:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:39:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:39:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:39:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:39:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:34 --> Total execution time: 0.4140
DEBUG - 2023-08-30 08:39:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:39:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:39:36 --> Total execution time: 0.1763
DEBUG - 2023-08-30 08:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:39:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:39:36 --> Total execution time: 0.4504
DEBUG - 2023-08-30 08:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:39:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:39:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:36 --> Total execution time: 0.4861
DEBUG - 2023-08-30 08:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:39:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:39:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:39:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:39:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:39 --> Total execution time: 0.2047
DEBUG - 2023-08-30 08:39:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:39:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:39:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:41 --> Total execution time: 0.1836
DEBUG - 2023-08-30 08:39:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:39:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:39:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:39:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:39:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:39:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:39:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:39:58 --> Total execution time: 0.2087
DEBUG - 2023-08-30 08:40:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:40:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:40:05 --> Total execution time: 0.2159
DEBUG - 2023-08-30 08:40:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:40:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:40:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:40:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:40:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:40:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:40:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-30 15:40:20 --> Query error: PROCEDURE banj5733_jrn.sp_journal_from_asset does not exist - Invalid query: CALL sp_journal_from_asset('create',93)
DEBUG - 2023-08-30 08:40:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:40:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:40:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:40:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:40:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:40:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:36 --> Total execution time: 2.1481
DEBUG - 2023-08-30 08:40:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:40:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:40:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:40:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:40:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:40:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:46 --> Total execution time: 0.3139
DEBUG - 2023-08-30 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:40:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:40:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:40:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:40:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:40:48 --> Total execution time: 0.1993
DEBUG - 2023-08-30 08:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:40:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:40:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:48 --> Total execution time: 0.5017
DEBUG - 2023-08-30 08:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:40:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:40:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:40:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:40:48 --> Total execution time: 0.5312
DEBUG - 2023-08-30 08:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:41:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:41:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:41:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:41:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:41:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:41:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:07 --> Total execution time: 0.2491
DEBUG - 2023-08-30 08:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:41:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:41:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:41:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:41:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:41:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:41:09 --> Total execution time: 0.1898
DEBUG - 2023-08-30 08:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:41:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:41:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:41:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:41:09 --> Total execution time: 0.5149
DEBUG - 2023-08-30 08:41:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:41:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:41:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:41:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:09 --> Total execution time: 0.5302
DEBUG - 2023-08-30 08:41:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:41:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:41:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:41:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:41:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:41:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:41:27 --> Total execution time: 0.4298
DEBUG - 2023-08-30 08:41:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:41:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:41:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:41:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:41:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:41:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:41:32 --> Total execution time: 0.2220
DEBUG - 2023-08-30 08:41:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:41:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:41:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:41:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:41:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:41:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:41:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:44 --> Total execution time: 0.3201
DEBUG - 2023-08-30 08:41:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:41:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:41:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:41:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:41:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:41:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:41:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:41:45 --> Total execution time: 0.4219
DEBUG - 2023-08-30 08:43:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:43:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:43:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:43:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:43:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:43:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:43:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:20 --> Total execution time: 0.2179
DEBUG - 2023-08-30 08:43:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:43:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:43:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:43:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:43:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:43:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:43:21 --> Total execution time: 0.2561
DEBUG - 2023-08-30 08:43:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:43:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:43:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:43:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:43:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:43:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:43:22 --> Total execution time: 0.3020
DEBUG - 2023-08-30 08:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:43:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:43:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:22 --> Total execution time: 0.3260
DEBUG - 2023-08-30 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:43:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:43:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:43:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:43:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:43:39 --> Total execution time: 0.2120
DEBUG - 2023-08-30 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:43:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:43:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:43:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:43:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:43:39 --> Total execution time: 0.1946
DEBUG - 2023-08-30 08:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:43:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:43:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:43:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:43:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:43:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:43:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:43:46 --> Total execution time: 0.2091
DEBUG - 2023-08-30 08:44:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:01 --> Total execution time: 0.3280
DEBUG - 2023-08-30 08:44:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:01 --> Total execution time: 0.3539
DEBUG - 2023-08-30 08:44:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:44:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:09 --> Total execution time: 0.1943
DEBUG - 2023-08-30 08:44:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:44:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:10 --> Total execution time: 0.1728
DEBUG - 2023-08-30 08:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:44:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:44:11 --> Total execution time: 0.3152
DEBUG - 2023-08-30 08:44:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:11 --> Total execution time: 0.3373
DEBUG - 2023-08-30 08:44:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:44:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:32 --> Total execution time: 0.2072
DEBUG - 2023-08-30 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:33 --> Total execution time: 0.1688
DEBUG - 2023-08-30 08:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:44:33 --> Total execution time: 0.3338
DEBUG - 2023-08-30 08:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:33 --> Total execution time: 0.3578
DEBUG - 2023-08-30 08:44:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:44:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:44:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:44:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:44:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:44:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:44:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:44:37 --> Total execution time: 0.2545
DEBUG - 2023-08-30 08:46:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:46:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:46:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:46:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:46:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:46:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:46:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:18 --> Total execution time: 0.1988
DEBUG - 2023-08-30 08:46:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:46:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:46:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:46:20 --> Total execution time: 0.1940
DEBUG - 2023-08-30 08:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:46:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:46:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:46:20 --> Total execution time: 0.4494
DEBUG - 2023-08-30 08:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:46:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:46:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:46:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:20 --> Total execution time: 0.3991
DEBUG - 2023-08-30 08:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:46:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:46:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:46:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:46:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:46:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:46:22 --> Total execution time: 0.2241
DEBUG - 2023-08-30 08:47:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:47:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:47:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:47:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:47:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:47:14 --> PHPMailer class is loaded.
ERROR - 2023-08-30 15:47:15 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 15:47:15 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 15:47:15 --> Total execution time: 0.3895
DEBUG - 2023-08-30 08:47:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:47:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:47:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:47:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:47:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:47:16 --> Total execution time: 0.1551
DEBUG - 2023-08-30 08:47:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:47:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:47:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:47:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:47:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:47:16 --> Total execution time: 0.2152
DEBUG - 2023-08-30 08:47:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:47:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:47:26 --> Total execution time: 0.3024
DEBUG - 2023-08-30 08:47:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:47:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:47:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:47:26 --> Total execution time: 0.1938
DEBUG - 2023-08-30 08:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:47:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:47:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:47:26 --> Total execution time: 0.2077
DEBUG - 2023-08-30 08:48:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:48:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:48:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:48:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:48:32 --> PHPMailer class is loaded.
ERROR - 2023-08-30 15:48:32 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 15:48:32 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 15:48:32 --> Total execution time: 0.3284
DEBUG - 2023-08-30 08:48:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:48:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:48:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:48:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:48:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:48:33 --> Total execution time: 0.1621
DEBUG - 2023-08-30 08:48:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:48:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:48:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:48:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:48:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:48:33 --> Total execution time: 0.2513
DEBUG - 2023-08-30 08:48:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:48:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:48:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:48:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:48:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:48:37 --> Total execution time: 0.3160
DEBUG - 2023-08-30 08:48:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:48:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:48:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:48:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:48:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:48:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:48:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 08:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:48:38 --> Total execution time: 0.1915
DEBUG - 2023-08-30 08:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:48:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:48:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:48:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:48:38 --> Total execution time: 0.2435
DEBUG - 2023-08-30 08:48:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:48:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:48:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:48:43 --> Total execution time: 0.2692
DEBUG - 2023-08-30 08:48:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:48:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:48:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:48:43 --> Total execution time: 0.2097
DEBUG - 2023-08-30 08:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:48:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:48:43 --> Total execution time: 0.2617
DEBUG - 2023-08-30 08:50:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:50:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:50:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:50:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:50:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:50:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:50:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:27 --> Total execution time: 0.2566
DEBUG - 2023-08-30 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:50:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:50:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:50:28 --> Total execution time: 0.1885
DEBUG - 2023-08-30 08:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:50:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:50:28 --> Total execution time: 0.3701
DEBUG - 2023-08-30 08:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:50:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:50:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:28 --> Total execution time: 0.4016
DEBUG - 2023-08-30 08:50:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:50:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:50:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:50:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:50:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:50:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:50:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:50:30 --> Total execution time: 0.2296
DEBUG - 2023-08-30 08:51:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:51:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:51:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:51:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:51:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:51:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:51:01 --> Total execution time: 0.2296
DEBUG - 2023-08-30 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:56:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:56:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:56:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:56:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:56:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:28 --> Total execution time: 0.2140
DEBUG - 2023-08-30 08:56:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:56:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:56:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:56:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:56:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:56:29 --> Total execution time: 0.1758
DEBUG - 2023-08-30 08:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:56:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:56:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:56:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:56:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:56:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:30 --> Total execution time: 0.3815
DEBUG - 2023-08-30 08:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:56:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:56:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:56:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:56:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:30 --> Total execution time: 0.4006
DEBUG - 2023-08-30 08:56:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:56:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:56:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:56:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:56:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:56:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:56:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:56:32 --> Total execution time: 0.2280
DEBUG - 2023-08-30 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:58:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:58:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:49 --> Total execution time: 0.2199
DEBUG - 2023-08-30 08:58:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:58:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:58:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:58:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:58:50 --> Total execution time: 0.1980
DEBUG - 2023-08-30 08:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:58:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:58:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 08:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 15:58:50 --> Total execution time: 0.3466
DEBUG - 2023-08-30 08:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:58:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:58:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:58:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:50 --> Total execution time: 0.3658
DEBUG - 2023-08-30 08:58:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:58:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:58:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:58:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:58:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:58:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:58:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:58:52 --> Total execution time: 0.2358
DEBUG - 2023-08-30 08:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:59:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:59:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:47 --> Total execution time: 0.1997
DEBUG - 2023-08-30 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:59:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:59:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:59:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:59:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:59:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:59:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:59:48 --> Total execution time: 0.2010
DEBUG - 2023-08-30 08:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:59:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:59:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:59:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:59:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:48 --> Total execution time: 0.3812
DEBUG - 2023-08-30 08:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:59:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:59:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:59:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:59:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:49 --> Total execution time: 0.3968
DEBUG - 2023-08-30 08:59:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 08:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 08:59:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 08:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 08:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 15:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 15:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 15:59:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 15:59:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 15:59:51 --> Total execution time: 0.2542
DEBUG - 2023-08-30 09:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:02:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:02:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:02:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:02:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:02:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:43 --> Total execution time: 0.2600
DEBUG - 2023-08-30 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 16:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:02:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:02:44 --> Total execution time: 0.2130
DEBUG - 2023-08-30 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:02:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:02:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 16:02:45 --> Total execution time: 0.5214
DEBUG - 2023-08-30 09:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:02:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:45 --> Total execution time: 0.4960
DEBUG - 2023-08-30 09:02:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:02:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:02:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:02:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:02:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:02:49 --> PHPMailer class is loaded.
ERROR - 2023-08-30 16:02:49 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 16:02:49 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 16:02:49 --> Total execution time: 0.3230
DEBUG - 2023-08-30 09:02:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:02:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:02:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:02:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:02:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:02:50 --> Total execution time: 0.2352
DEBUG - 2023-08-30 09:02:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:02:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:02:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:02:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:02:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:02:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:02:51 --> Total execution time: 0.2621
DEBUG - 2023-08-30 09:03:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:14 --> Total execution time: 0.2907
DEBUG - 2023-08-30 09:03:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 09:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 16:03:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:14 --> Total execution time: 0.1892
DEBUG - 2023-08-30 09:03:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:14 --> Total execution time: 0.2409
DEBUG - 2023-08-30 09:03:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:24 --> Total execution time: 0.3028
DEBUG - 2023-08-30 09:03:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:25 --> Total execution time: 0.2714
DEBUG - 2023-08-30 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:37 --> PHPMailer class is loaded.
ERROR - 2023-08-30 16:03:37 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
ERROR - 2023-08-30 16:03:37 --> Severity: Notice --> Undefined variable: selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\product\product.php 430
DEBUG - 2023-08-30 16:03:37 --> Total execution time: 0.2739
DEBUG - 2023-08-30 09:03:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:39 --> Total execution time: 0.1868
DEBUG - 2023-08-30 09:03:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:39 --> Total execution time: 0.2527
DEBUG - 2023-08-30 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:42 --> Total execution time: 0.3561
DEBUG - 2023-08-30 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:42 --> Total execution time: 0.2042
DEBUG - 2023-08-30 09:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:42 --> Total execution time: 0.2469
DEBUG - 2023-08-30 09:03:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:47 --> Total execution time: 0.2788
DEBUG - 2023-08-30 09:03:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 09:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 09:03:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-30 09:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 09:03:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 09:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-30 16:03:48 --> Total execution time: 0.2737
DEBUG - 2023-08-30 09:03:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 16:03:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-30 16:03:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-30 16:03:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-30 16:03:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-30 16:03:48 --> Total execution time: 0.3314
