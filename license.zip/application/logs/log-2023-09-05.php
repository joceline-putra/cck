<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-05 04:38:23 --> Severity: User Error --> Composer detected issues in your platform: Your Composer dependencies require a PHP version ">= 7.3.0". You are running 7.0.33. C:\Wamp\www\git\jrn\vendor\composer\platform_check.php 24
DEBUG - 2023-09-05 07:22:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:22:07 --> No URI present. Default controller set.
DEBUG - 2023-09-05 07:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:22:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:22:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:22:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:22:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:22:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:22:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:22:25 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:22:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:22:26 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:22:26 --> Total execution time: 19.8908
DEBUG - 2023-09-05 07:25:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:28 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:25:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:28 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:28 --> Total execution time: 1.4343
DEBUG - 2023-09-05 07:25:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:29 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:29 --> Total execution time: 1.0319
DEBUG - 2023-09-05 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:25:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:25:31 --> Total execution time: 0.5599
DEBUG - 2023-09-05 07:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:31 --> Total execution time: 0.5231
DEBUG - 2023-09-05 07:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:25:31 --> Total execution time: 0.8821
DEBUG - 2023-09-05 07:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:31 --> Total execution time: 0.7829
DEBUG - 2023-09-05 07:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:31 --> Total execution time: 0.8242
DEBUG - 2023-09-05 07:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:25:31 --> Total execution time: 0.8651
DEBUG - 2023-09-05 07:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:31 --> Total execution time: 0.5898
DEBUG - 2023-09-05 07:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:31 --> Total execution time: 0.5741
DEBUG - 2023-09-05 07:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.2891
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.2944
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.2868
DEBUG - 2023-09-05 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:25:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:25:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.2609
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.2728
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:25:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 07:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.2842
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.2704
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.2693
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.2724
DEBUG - 2023-09-05 07:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:25:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:32 --> Total execution time: 0.7998
DEBUG - 2023-09-05 07:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:25:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:25:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:25:33 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:25:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:25:33 --> Total execution time: 0.8843
DEBUG - 2023-09-05 07:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:26:10 --> PHPMailer class is loaded.
ERROR - 2023-09-05 14:26:11 --> Severity: Warning --> Undefined variable $user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:26:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:26:11 --> Severity: Warning --> Undefined variable $menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
ERROR - 2023-09-05 14:26:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
DEBUG - 2023-09-05 14:26:11 --> Total execution time: 0.4938
DEBUG - 2023-09-05 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:26:11 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:26:11 --> Total execution time: 0.1557
DEBUG - 2023-09-05 07:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:26:11 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:26:11 --> Total execution time: 0.2110
DEBUG - 2023-09-05 07:26:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:26:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:26:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:26:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:26:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:26:52 --> PHPMailer class is loaded.
ERROR - 2023-09-05 14:26:52 --> Severity: Warning --> Undefined variable $user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:26:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:26:52 --> Severity: Warning --> Undefined variable $menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
ERROR - 2023-09-05 14:26:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
DEBUG - 2023-09-05 14:26:52 --> Total execution time: 0.1912
DEBUG - 2023-09-05 07:26:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:26:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:26:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:26:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:26:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:26:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:26:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:26:53 --> Total execution time: 0.1609
DEBUG - 2023-09-05 07:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:26:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:26:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:26:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:26:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:26:53 --> Total execution time: 0.1918
DEBUG - 2023-09-05 07:27:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:27:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:27:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:27:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:27:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:27:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:27:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:27:00 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:27:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-05 14:27:00 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
ERROR - 2023-09-05 14:27:00 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
DEBUG - 2023-09-05 14:27:00 --> Total execution time: 0.5204
DEBUG - 2023-09-05 07:27:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:27:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:27:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:27:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:27:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:27:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:27:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:27:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:27:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:27:01 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:27:01 --> Total execution time: 0.1610
DEBUG - 2023-09-05 07:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:27:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:27:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:27:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:27:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:27:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:27:01 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:27:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:27:01 --> Total execution time: 0.2281
DEBUG - 2023-09-05 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:29:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:29:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:29:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:29:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:29:30 --> PHPMailer class is loaded.
ERROR - 2023-09-05 14:29:30 --> Severity: Warning --> Undefined variable $user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:29:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:29:30 --> Severity: Warning --> Undefined variable $menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
ERROR - 2023-09-05 14:29:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
DEBUG - 2023-09-05 14:29:30 --> Total execution time: 0.2311
DEBUG - 2023-09-05 07:29:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:29:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:29:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:29:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:29:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:29:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:29:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:29:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:29:31 --> Total execution time: 0.1608
DEBUG - 2023-09-05 07:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:29:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:29:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:29:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:29:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:29:31 --> Total execution time: 0.1945
DEBUG - 2023-09-05 07:29:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:29:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:29:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:29:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:29:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:29:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:29:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:29:35 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:29:35 --> Total execution time: 0.2379
DEBUG - 2023-09-05 07:30:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:16 --> Total execution time: 0.6320
DEBUG - 2023-09-05 07:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:17 --> Total execution time: 0.1640
DEBUG - 2023-09-05 07:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:30:17 --> Total execution time: 0.2341
DEBUG - 2023-09-05 07:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:17 --> Total execution time: 0.3174
DEBUG - 2023-09-05 07:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:17 --> Total execution time: 0.4247
DEBUG - 2023-09-05 07:30:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:20 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-05 14:30:20 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
ERROR - 2023-09-05 14:30:20 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
DEBUG - 2023-09-05 14:30:21 --> Total execution time: 0.3621
DEBUG - 2023-09-05 07:30:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:21 --> Total execution time: 0.1656
DEBUG - 2023-09-05 07:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:21 --> Total execution time: 0.2165
DEBUG - 2023-09-05 07:30:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:28 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:28 --> Total execution time: 1.0623
DEBUG - 2023-09-05 07:30:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:30 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:30 --> Total execution time: 0.8875
DEBUG - 2023-09-05 07:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:30 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:30 --> Total execution time: 0.9271
DEBUG - 2023-09-05 07:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:30 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:30 --> Total execution time: 0.9824
DEBUG - 2023-09-05 07:30:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:50 --> Total execution time: 0.3756
DEBUG - 2023-09-05 07:30:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:50 --> Total execution time: 0.1602
DEBUG - 2023-09-05 07:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Total execution time: 0.8537
DEBUG - 2023-09-05 07:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:30:51 --> Total execution time: 0.9105
DEBUG - 2023-09-05 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Total execution time: 0.1884
DEBUG - 2023-09-05 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Total execution time: 0.2032
DEBUG - 2023-09-05 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:51 --> Total execution time: 0.1988
DEBUG - 2023-09-05 07:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:52 --> Total execution time: 0.1883
DEBUG - 2023-09-05 07:30:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:52 --> Total execution time: 0.2033
DEBUG - 2023-09-05 07:30:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:54 --> Total execution time: 0.2933
DEBUG - 2023-09-05 07:30:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:55 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:55 --> Total execution time: 0.1679
DEBUG - 2023-09-05 07:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 07:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:55 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:55 --> Total execution time: 0.1954
DEBUG - 2023-09-05 07:30:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:55 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:55 --> Total execution time: 0.2348
DEBUG - 2023-09-05 07:30:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:56 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:56 --> Total execution time: 0.1899
DEBUG - 2023-09-05 07:30:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:58 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:59 --> Total execution time: 0.3079
DEBUG - 2023-09-05 07:30:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:59 --> Total execution time: 0.1595
DEBUG - 2023-09-05 07:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:30:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:30:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:59 --> Total execution time: 0.1967
DEBUG - 2023-09-05 07:30:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:30:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:30:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:30:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:30:59 --> Total execution time: 0.2374
DEBUG - 2023-09-05 07:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:00 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:00 --> Total execution time: 0.1924
DEBUG - 2023-09-05 07:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:02 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:02 --> Total execution time: 0.3201
DEBUG - 2023-09-05 07:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:03 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:03 --> Total execution time: 0.1608
DEBUG - 2023-09-05 07:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:03 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:31:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:03 --> Total execution time: 0.1899
DEBUG - 2023-09-05 07:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:03 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:03 --> Total execution time: 0.2457
DEBUG - 2023-09-05 07:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:04 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:05 --> Total execution time: 0.5154
DEBUG - 2023-09-05 07:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:05 --> Total execution time: 0.1691
DEBUG - 2023-09-05 07:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:31:05 --> Total execution time: 0.2436
DEBUG - 2023-09-05 07:31:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:05 --> Total execution time: 0.3069
DEBUG - 2023-09-05 07:31:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:31:12 --> Total execution time: 0.1713
DEBUG - 2023-09-05 07:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:12 --> Total execution time: 0.2255
DEBUG - 2023-09-05 07:31:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:14 --> Total execution time: 0.5395
DEBUG - 2023-09-05 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:14 --> Total execution time: 0.1576
DEBUG - 2023-09-05 07:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:31:15 --> Total execution time: 0.2176
DEBUG - 2023-09-05 07:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:15 --> Total execution time: 0.3151
DEBUG - 2023-09-05 07:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:15 --> Total execution time: 0.3995
DEBUG - 2023-09-05 07:31:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:51 --> Total execution time: 0.7425
DEBUG - 2023-09-05 07:31:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:31:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:52 --> Total execution time: 0.1710
DEBUG - 2023-09-05 07:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:31:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:31:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:31:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:31:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:31:52 --> Total execution time: 0.2177
DEBUG - 2023-09-05 07:32:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:04 --> PHPMailer class is loaded.
ERROR - 2023-09-05 14:32:04 --> Severity: Warning --> Undefined variable $user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:32:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:32:04 --> Severity: Warning --> Undefined variable $menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
ERROR - 2023-09-05 14:32:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
DEBUG - 2023-09-05 14:32:04 --> Total execution time: 0.1942
DEBUG - 2023-09-05 07:32:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:05 --> Total execution time: 0.1652
DEBUG - 2023-09-05 07:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:05 --> Total execution time: 0.1952
DEBUG - 2023-09-05 07:32:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:07 --> Total execution time: 0.2556
DEBUG - 2023-09-05 07:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:08 --> Total execution time: 0.1610
DEBUG - 2023-09-05 07:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:08 --> Total execution time: 0.1942
DEBUG - 2023-09-05 07:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:09 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:09 --> Total execution time: 0.5446
DEBUG - 2023-09-05 07:32:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:12 --> Total execution time: 0.1933
DEBUG - 2023-09-05 07:32:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:13 --> Total execution time: 0.1643
DEBUG - 2023-09-05 07:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:13 --> Total execution time: 0.2163
DEBUG - 2023-09-05 07:32:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:14 --> PHPMailer class is loaded.
ERROR - 2023-09-05 14:32:14 --> Severity: Warning --> Undefined variable $user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:32:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:32:14 --> Severity: Warning --> Undefined variable $menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
ERROR - 2023-09-05 14:32:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
DEBUG - 2023-09-05 14:32:14 --> Total execution time: 0.1897
DEBUG - 2023-09-05 07:32:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:15 --> Total execution time: 0.1808
DEBUG - 2023-09-05 07:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:15 --> Total execution time: 0.1950
DEBUG - 2023-09-05 07:32:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-05 14:32:16 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
ERROR - 2023-09-05 14:32:16 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
DEBUG - 2023-09-05 14:32:16 --> Total execution time: 0.1998
DEBUG - 2023-09-05 07:32:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:17 --> Total execution time: 0.1671
DEBUG - 2023-09-05 07:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:17 --> Total execution time: 0.2218
DEBUG - 2023-09-05 07:32:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-05 14:32:21 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
ERROR - 2023-09-05 14:32:21 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
ERROR - 2023-09-05 14:32:21 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
DEBUG - 2023-09-05 14:32:21 --> Total execution time: 0.2490
DEBUG - 2023-09-05 07:32:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:22 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:22 --> Total execution time: 0.1640
DEBUG - 2023-09-05 07:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:22 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:22 --> Total execution time: 0.2196
DEBUG - 2023-09-05 07:32:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:31 --> Total execution time: 0.2314
DEBUG - 2023-09-05 07:32:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:35 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:35 --> Total execution time: 0.2197
DEBUG - 2023-09-05 07:32:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:32:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:36 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:36 --> Total execution time: 0.1653
DEBUG - 2023-09-05 07:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:32:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:32:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:32:36 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:32:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:32:36 --> Total execution time: 0.2184
DEBUG - 2023-09-05 07:33:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:33:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:33:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:33:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:33:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:33:20 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:33:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:21 --> Total execution time: 0.2088
DEBUG - 2023-09-05 07:33:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:33:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:33:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:33:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:33:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:33:24 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:33:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:24 --> Total execution time: 0.2500
DEBUG - 2023-09-05 07:33:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:33:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:33:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:33:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:33:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:33:27 --> PHPMailer class is loaded.
ERROR - 2023-09-05 14:33:27 --> Severity: Warning --> Undefined variable $user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:33:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:33:27 --> Severity: Warning --> Undefined variable $menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
ERROR - 2023-09-05 14:33:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
DEBUG - 2023-09-05 14:33:27 --> Total execution time: 0.2119
DEBUG - 2023-09-05 07:33:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:33:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:33:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:33:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:33:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:33:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:33:28 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:33:28 --> Total execution time: 0.1654
DEBUG - 2023-09-05 07:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:33:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:33:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:33:29 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:33:29 --> Total execution time: 0.1925
DEBUG - 2023-09-05 07:33:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:33:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:33:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:33:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:33:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:33:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:33:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:33:31 --> Total execution time: 0.2145
DEBUG - 2023-09-05 07:35:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:35:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:35:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:35:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:35:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:35:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:35:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:35:55 --> PHPMailer class is loaded.
ERROR - 2023-09-05 14:35:55 --> Severity: Warning --> Undefined variable $user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:35:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-05 14:35:55 --> Severity: Warning --> Undefined variable $menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
ERROR - 2023-09-05 14:35:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
DEBUG - 2023-09-05 14:35:55 --> Total execution time: 0.2081
DEBUG - 2023-09-05 07:35:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:35:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:35:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:35:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:35:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:35:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:35:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:35:56 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:35:56 --> Total execution time: 0.1675
DEBUG - 2023-09-05 07:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:35:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:35:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:35:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:35:56 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:35:56 --> Total execution time: 0.1971
DEBUG - 2023-09-05 07:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:37:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:37:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:07 --> Total execution time: 0.3246
DEBUG - 2023-09-05 07:37:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:37:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:37:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:37:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:37:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:08 --> Total execution time: 0.1639
DEBUG - 2023-09-05 07:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:37:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:37:08 --> Total execution time: 0.2159
DEBUG - 2023-09-05 07:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:37:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Total execution time: 0.2972
DEBUG - 2023-09-05 07:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:37:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:08 --> Total execution time: 0.3745
DEBUG - 2023-09-05 07:37:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:37:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:37:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:37:39 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:39 --> Total execution time: 0.3276
DEBUG - 2023-09-05 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:37:40 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:40 --> Total execution time: 0.1903
DEBUG - 2023-09-05 07:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:37:40 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:37:40 --> Total execution time: 0.2251
DEBUG - 2023-09-05 07:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:37:40 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:37:40 --> Total execution time: 0.3878
DEBUG - 2023-09-05 07:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:37:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:37:40 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:37:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:37:41 --> Total execution time: 0.4084
DEBUG - 2023-09-05 07:38:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:38:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:38:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:38:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:38:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:38:24 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:38:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:24 --> Total execution time: 0.3210
DEBUG - 2023-09-05 07:38:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:38:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:38:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:38:26 --> Total execution time: 0.1685
DEBUG - 2023-09-05 07:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:38:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:38:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Total execution time: 0.2707
DEBUG - 2023-09-05 07:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:38:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:38:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Total execution time: 0.3050
DEBUG - 2023-09-05 07:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:38:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:38:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:38:26 --> Total execution time: 0.3952
DEBUG - 2023-09-05 07:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:39:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:22 --> Total execution time: 0.3416
DEBUG - 2023-09-05 07:39:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:39:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:39:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:39:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:39:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:39:24 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:39:24 --> Total execution time: 0.2136
DEBUG - 2023-09-05 07:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:39:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:39:24 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:39:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:39:24 --> Total execution time: 0.2270
DEBUG - 2023-09-05 07:39:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:39:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:39:24 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:39:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:25 --> Total execution time: 0.3065
DEBUG - 2023-09-05 07:39:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:39:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:39:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:39:25 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:39:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:39:25 --> Total execution time: 0.3853
DEBUG - 2023-09-05 07:41:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:22 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:22 --> Total execution time: 0.3370
DEBUG - 2023-09-05 07:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:41:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:41:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:23 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:24 --> Total execution time: 0.1806
DEBUG - 2023-09-05 07:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:24 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:41:24 --> Total execution time: 0.2198
DEBUG - 2023-09-05 07:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:24 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:41:24 --> Total execution time: 0.2543
DEBUG - 2023-09-05 07:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:24 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:24 --> Total execution time: 0.3457
DEBUG - 2023-09-05 07:41:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:51 --> Total execution time: 0.1957
DEBUG - 2023-09-05 07:41:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:51 --> Total execution time: 0.2312
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Total execution time: 0.1890
DEBUG - 2023-09-05 07:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:52 --> Total execution time: 0.1531
DEBUG - 2023-09-05 07:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:52 --> Total execution time: 0.1804
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:52 --> Total execution time: 0.2050
DEBUG - 2023-09-05 07:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:41:52 --> Total execution time: 0.2461
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.3689
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.3145
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.4346
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.5032
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.3626
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.3465
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.2632
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.2750
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.2661
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.2717
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.2678
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.2679
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.2764
DEBUG - 2023-09-05 07:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:53 --> Total execution time: 0.2468
DEBUG - 2023-09-05 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:54 --> Total execution time: 0.8939
DEBUG - 2023-09-05 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:55 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:55 --> Total execution time: 0.1650
DEBUG - 2023-09-05 07:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:55 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:41:55 --> Total execution time: 0.2434
DEBUG - 2023-09-05 07:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:55 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:55 --> Total execution time: 0.3056
DEBUG - 2023-09-05 07:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:41:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:41:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:41:56 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:41:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:41:56 --> Total execution time: 0.3915
DEBUG - 2023-09-05 07:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:13 --> Total execution time: 0.1838
DEBUG - 2023-09-05 07:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:13 --> Total execution time: 0.2175
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.1910
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.1642
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.2454
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.2060
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.2405
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.3107
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.3312
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.3545
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.2688
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.2723
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.2486
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.2495
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.2543
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:42:14 --> Total execution time: 0.2459
DEBUG - 2023-09-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:15 --> Total execution time: 0.2501
DEBUG - 2023-09-05 07:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:15 --> Total execution time: 0.2480
DEBUG - 2023-09-05 07:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:15 --> Total execution time: 0.2517
DEBUG - 2023-09-05 07:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Total execution time: 0.2428
DEBUG - 2023-09-05 07:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:15 --> Total execution time: 0.2635
DEBUG - 2023-09-05 07:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:42 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:42 --> Total execution time: 0.3292
DEBUG - 2023-09-05 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:43 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:43 --> Total execution time: 0.1660
DEBUG - 2023-09-05 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:43 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Total execution time: 0.2313
DEBUG - 2023-09-05 07:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:43 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Total execution time: 0.2887
DEBUG - 2023-09-05 07:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:42:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:42:43 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:42:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:42:43 --> Total execution time: 0.3461
DEBUG - 2023-09-05 07:50:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:50:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:50:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:50:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:50:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:50:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:50:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:51 --> Total execution time: 0.3449
DEBUG - 2023-09-05 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:50:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:50:52 --> Total execution time: 0.1798
DEBUG - 2023-09-05 07:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:50:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:50:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:50:52 --> Total execution time: 0.2190
DEBUG - 2023-09-05 07:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:50:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:50:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:50:52 --> Total execution time: 0.2630
DEBUG - 2023-09-05 07:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:50:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:50:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:50:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:50:52 --> Total execution time: 0.3380
DEBUG - 2023-09-05 07:53:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:53:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-09-05 07:53:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-09-05 07:53:23 --> Unable to connect to the database
DEBUG - 2023-09-05 07:53:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:53:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:55:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:03 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:03 --> Total execution time: 0.3470
DEBUG - 2023-09-05 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:05 --> Total execution time: 0.1726
DEBUG - 2023-09-05 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 14:55:05 --> Total execution time: 0.2185
DEBUG - 2023-09-05 07:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:55:05 --> Total execution time: 0.2934
DEBUG - 2023-09-05 07:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:05 --> Total execution time: 0.3503
DEBUG - 2023-09-05 07:55:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:55:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:50 --> Total execution time: 0.3286
DEBUG - 2023-09-05 07:55:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:52 --> Total execution time: 0.1637
DEBUG - 2023-09-05 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 07:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:55:52 --> Total execution time: 0.2209
DEBUG - 2023-09-05 07:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 07:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 14:55:52 --> Total execution time: 0.2742
DEBUG - 2023-09-05 07:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 14:55:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 14:55:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 14:55:52 --> Total execution time: 0.3617
DEBUG - 2023-09-05 07:58:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:58:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 07:59:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 07:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 07:59:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:01:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:01:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:01:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:01:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:01:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:12 --> Total execution time: 0.3542
DEBUG - 2023-09-05 08:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:01:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:01:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:01:15 --> Total execution time: 0.1894
DEBUG - 2023-09-05 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:01:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:01:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:01:15 --> Total execution time: 0.2335
DEBUG - 2023-09-05 08:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:01:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:01:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Total execution time: 0.2649
DEBUG - 2023-09-05 08:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:01:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:01:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:15 --> Total execution time: 0.3566
DEBUG - 2023-09-05 08:01:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:01:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:01:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:01:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:01:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:48 --> Total execution time: 0.3274
DEBUG - 2023-09-05 08:01:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:01:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:01:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:01:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:01:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:01:50 --> Total execution time: 0.1682
DEBUG - 2023-09-05 08:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:01:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:01:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:01:50 --> Total execution time: 0.2190
DEBUG - 2023-09-05 08:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:01:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:01:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Total execution time: 0.2599
DEBUG - 2023-09-05 08:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:01:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:01:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:01:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:01:50 --> Total execution time: 0.3315
DEBUG - 2023-09-05 08:02:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:02:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:02:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:02:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:02:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:02:10 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:02:10 --> Total execution time: 0.1887
DEBUG - 2023-09-05 08:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:02:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:27 --> Total execution time: 0.3244
DEBUG - 2023-09-05 08:02:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:02:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 08:02:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:02:28 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:02:28 --> Total execution time: 0.2046
DEBUG - 2023-09-05 08:02:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:02:28 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:02:28 --> Total execution time: 0.2189
DEBUG - 2023-09-05 08:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:02:28 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:02:28 --> Total execution time: 0.2429
DEBUG - 2023-09-05 08:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:02:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:02:28 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:02:28 --> Total execution time: 0.3206
DEBUG - 2023-09-05 08:03:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:03:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:08 --> Total execution time: 0.3251
DEBUG - 2023-09-05 08:03:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:03:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:03:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:10 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:10 --> Total execution time: 0.1668
DEBUG - 2023-09-05 08:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:10 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:03:10 --> Total execution time: 0.2228
DEBUG - 2023-09-05 08:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:10 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:03:10 --> Total execution time: 0.2808
DEBUG - 2023-09-05 08:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:10 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:10 --> Total execution time: 0.3631
DEBUG - 2023-09-05 08:03:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:37 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:37 --> Total execution time: 0.3297
DEBUG - 2023-09-05 08:03:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:03:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:03:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:03:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:38 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:38 --> Total execution time: 0.1683
DEBUG - 2023-09-05 08:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:38 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:03:38 --> Total execution time: 0.2241
DEBUG - 2023-09-05 08:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:38 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:38 --> Total execution time: 0.2759
DEBUG - 2023-09-05 08:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:03:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:03:38 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:03:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:03:39 --> Total execution time: 0.3521
DEBUG - 2023-09-05 08:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:04:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:04:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:04:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:04:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:04:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:04:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:16 --> Total execution time: 0.3266
DEBUG - 2023-09-05 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:04:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:04:17 --> Total execution time: 0.1671
DEBUG - 2023-09-05 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:04:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:04:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:04:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:04:18 --> Total execution time: 0.2227
DEBUG - 2023-09-05 08:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:04:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:04:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:04:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:04:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:04:18 --> Total execution time: 0.2367
DEBUG - 2023-09-05 08:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:04:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:04:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:04:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:04:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:18 --> Total execution time: 0.3161
DEBUG - 2023-09-05 08:04:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:04:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:04:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:04:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:04:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:04:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:04:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:04:47 --> Total execution time: 0.2298
DEBUG - 2023-09-05 08:08:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:18 --> Total execution time: 0.2156
DEBUG - 2023-09-05 08:08:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:20 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:20 --> Total execution time: 0.1912
DEBUG - 2023-09-05 08:08:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:21 --> Total execution time: 0.1969
DEBUG - 2023-09-05 08:08:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:24 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:24 --> Total execution time: 0.2291
DEBUG - 2023-09-05 08:08:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:26 --> Total execution time: 0.1934
DEBUG - 2023-09-05 08:08:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:28 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:28 --> Total execution time: 0.1974
DEBUG - 2023-09-05 08:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:31 --> Total execution time: 0.1957
DEBUG - 2023-09-05 08:08:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:32 --> Total execution time: 0.1885
DEBUG - 2023-09-05 08:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:34 --> Total execution time: 0.1873
DEBUG - 2023-09-05 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:08:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:08:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:08:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:08:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:08:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:08:38 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:08:38 --> Total execution time: 0.1964
DEBUG - 2023-09-05 08:10:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:10:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:10:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:10:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:35 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:35 --> Total execution time: 0.6246
DEBUG - 2023-09-05 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:10:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:10:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:10:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:10:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:10:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:37 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:37 --> Total execution time: 0.1755
DEBUG - 2023-09-05 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:10:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:10:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:10:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:38 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:10:38 --> Total execution time: 0.2499
DEBUG - 2023-09-05 08:10:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:10:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:38 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:38 --> Total execution time: 0.2944
DEBUG - 2023-09-05 08:10:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:10:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:38 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:38 --> Total execution time: 0.3447
DEBUG - 2023-09-05 08:10:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:10:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:10:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:10:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:57 --> Total execution time: 0.3340
DEBUG - 2023-09-05 08:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 08:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:59 --> Total execution time: 0.1672
DEBUG - 2023-09-05 08:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:10:59 --> Total execution time: 0.2168
DEBUG - 2023-09-05 08:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:59 --> Total execution time: 0.2765
DEBUG - 2023-09-05 08:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:10:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:10:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:10:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:10:59 --> Total execution time: 0.3462
DEBUG - 2023-09-05 08:12:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:12:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:12:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:12:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:12:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:12:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:12:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:50 --> Total execution time: 0.3224
DEBUG - 2023-09-05 08:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:12:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:12:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:12:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 08:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:12:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:12:53 --> Total execution time: 0.1627
DEBUG - 2023-09-05 08:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:12:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:12:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:12:53 --> Total execution time: 0.2229
DEBUG - 2023-09-05 08:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:12:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:12:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:53 --> Total execution time: 0.2770
DEBUG - 2023-09-05 08:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:12:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:12:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:12:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:12:53 --> Total execution time: 0.3606
DEBUG - 2023-09-05 08:13:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:13:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:13:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:18 --> Total execution time: 0.3481
DEBUG - 2023-09-05 08:13:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 08:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:20 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:20 --> Total execution time: 0.2927
DEBUG - 2023-09-05 08:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:20 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:13:20 --> Total execution time: 0.2832
DEBUG - 2023-09-05 08:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:20 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Total execution time: 0.3110
DEBUG - 2023-09-05 08:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:20 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:20 --> Total execution time: 0.4007
DEBUG - 2023-09-05 08:13:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:13:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:13:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:54 --> Total execution time: 0.3407
DEBUG - 2023-09-05 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:57 --> Total execution time: 0.1668
DEBUG - 2023-09-05 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Total execution time: 0.2247
DEBUG - 2023-09-05 08:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:13:57 --> Total execution time: 0.2250
DEBUG - 2023-09-05 08:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:13:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:13:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:13:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:13:57 --> Total execution time: 0.3098
DEBUG - 2023-09-05 08:16:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:16:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:16:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:16:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:16:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:16:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:16:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:16 --> Total execution time: 0.3373
DEBUG - 2023-09-05 08:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:16:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:16:18 --> Total execution time: 0.1604
DEBUG - 2023-09-05 08:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:16:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:16:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:16:18 --> Total execution time: 0.2158
DEBUG - 2023-09-05 08:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:16:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:16:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:19 --> Total execution time: 0.2604
DEBUG - 2023-09-05 08:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:16:19 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:16:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:16:19 --> Total execution time: 0.3644
DEBUG - 2023-09-05 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:18:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:46 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:46 --> Total execution time: 0.1928
DEBUG - 2023-09-05 08:19:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:47 --> Total execution time: 0.7111
DEBUG - 2023-09-05 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:19:48 --> Total execution time: 0.1903
DEBUG - 2023-09-05 08:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:48 --> Total execution time: 0.1791
DEBUG - 2023-09-05 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:19:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:19:48 --> Total execution time: 0.2626
DEBUG - 2023-09-05 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:48 --> Total execution time: 0.2045
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.3182
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.3342
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2704
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.3406
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.3251
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2745
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2452
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2402
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2475
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2507
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2514
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2456
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2434
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2507
DEBUG - 2023-09-05 08:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:49 --> Total execution time: 0.2505
DEBUG - 2023-09-05 08:19:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:52 --> Total execution time: 0.3278
DEBUG - 2023-09-05 08:19:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:53 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:19:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:19:53 --> Total execution time: 0.1940
DEBUG - 2023-09-05 08:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:19:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:54 --> Total execution time: 0.2202
DEBUG - 2023-09-05 08:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:19:54 --> Total execution time: 0.2587
DEBUG - 2023-09-05 08:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:19:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:19:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:19:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:19:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:19:54 --> Total execution time: 0.3444
DEBUG - 2023-09-05 08:24:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:24:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:24:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:24:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:24:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:24:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:51 --> Total execution time: 0.3507
DEBUG - 2023-09-05 08:24:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:24:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:24:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:24:54 --> Total execution time: 0.1705
DEBUG - 2023-09-05 08:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:24:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:24:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:24:54 --> Total execution time: 0.2312
DEBUG - 2023-09-05 08:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:24:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:24:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Total execution time: 0.2731
DEBUG - 2023-09-05 08:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:24:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:24:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:24:54 --> Total execution time: 0.3686
DEBUG - 2023-09-05 08:25:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:25:23 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:25:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:23 --> Total execution time: 0.3309
DEBUG - 2023-09-05 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:25:25 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:25:25 --> Total execution time: 0.1631
DEBUG - 2023-09-05 08:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:25:25 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:25:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:25 --> Total execution time: 0.2206
DEBUG - 2023-09-05 08:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:25:25 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:25:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:25:25 --> Total execution time: 0.2344
DEBUG - 2023-09-05 08:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:25:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:25:25 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:25:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:25:26 --> Total execution time: 0.3415
DEBUG - 2023-09-05 08:26:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:26:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:26:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:26:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:26:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:26:03 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:26:03 --> Total execution time: 0.1883
DEBUG - 2023-09-05 08:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:26:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:26:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:26:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:26:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:26:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:26:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:26:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:26:14 --> Total execution time: 0.8878
DEBUG - 2023-09-05 08:27:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:27:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:27:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:27:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:27:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:27:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:27:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:27:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:27:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:27:32 --> Total execution time: 0.6700
DEBUG - 2023-09-05 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:27:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:27:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:27:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:27:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:27:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:27:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:27:32 --> Total execution time: 0.2287
DEBUG - 2023-09-05 08:31:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:31:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:31:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:31:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:31:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:31:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:31:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:31:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:31:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:31:59 --> Total execution time: 0.3519
DEBUG - 2023-09-05 08:32:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:32:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:32:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 08:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:32:01 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:32:01 --> Total execution time: 0.1740
DEBUG - 2023-09-05 08:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:32:01 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:32:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:32:02 --> Total execution time: 0.2755
DEBUG - 2023-09-05 08:32:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:32:02 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:32:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:02 --> Total execution time: 0.3499
DEBUG - 2023-09-05 08:32:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:32:02 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:32:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:02 --> Total execution time: 0.4318
DEBUG - 2023-09-05 08:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:32:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:32:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:32:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:32:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:48 --> Total execution time: 0.3457
DEBUG - 2023-09-05 08:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:32:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:32:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:32:50 --> Total execution time: 0.1671
DEBUG - 2023-09-05 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:32:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:32:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:32:50 --> Total execution time: 0.2745
DEBUG - 2023-09-05 08:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:32:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:32:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:50 --> Total execution time: 0.2794
DEBUG - 2023-09-05 08:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:32:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:32:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:50 --> Total execution time: 0.3507
DEBUG - 2023-09-05 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:32:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:32:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:32:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:32:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:32:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:32:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:32:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-05 15:32:58 --> Severity: error --> Exception: implode(): Argument #2 ($array) must be of type ?array, string given C:\Wamp\www\git\jrn\application\controllers\Pos.php 1235
DEBUG - 2023-09-05 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 08:33:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 08:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 08:33:09 --> Total execution time: 2.8524
DEBUG - 2023-09-05 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:34:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:34:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:13 --> Total execution time: 0.3295
DEBUG - 2023-09-05 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:34:14 --> Total execution time: 0.1637
DEBUG - 2023-09-05 08:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:34:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:34:14 --> Total execution time: 0.2743
DEBUG - 2023-09-05 08:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:34:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Total execution time: 0.3297
DEBUG - 2023-09-05 08:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:34:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:14 --> Total execution time: 0.4074
DEBUG - 2023-09-05 08:34:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:34:17 --> Total execution time: 0.2923
DEBUG - 2023-09-05 08:34:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:34:17 --> Total execution time: 0.1898
DEBUG - 2023-09-05 08:34:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:34:17 --> Total execution time: 0.2276
DEBUG - 2023-09-05 08:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:34:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:18 --> Total execution time: 0.2999
DEBUG - 2023-09-05 08:34:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:34:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:34:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:34:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:34:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:34:18 --> Total execution time: 0.3348
DEBUG - 2023-09-05 08:37:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:37:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:37:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:37:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:37:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:37:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:49 --> Total execution time: 0.3335
DEBUG - 2023-09-05 08:37:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:37:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:37:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:37:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:37:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:37:51 --> Total execution time: 0.1692
DEBUG - 2023-09-05 08:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:37:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:37:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:37:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:37:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:37:51 --> Total execution time: 0.2792
DEBUG - 2023-09-05 08:37:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:37:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:37:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Total execution time: 0.3286
DEBUG - 2023-09-05 08:37:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:37:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:37:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:37:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:37:51 --> Total execution time: 0.3941
DEBUG - 2023-09-05 08:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:03 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:03 --> Total execution time: 0.3383
DEBUG - 2023-09-05 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:04 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:04 --> Total execution time: 0.1638
DEBUG - 2023-09-05 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:04 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:38:04 --> Total execution time: 0.3029
DEBUG - 2023-09-05 08:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:04 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:04 --> Total execution time: 0.3086
DEBUG - 2023-09-05 08:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:04 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:05 --> Total execution time: 0.4003
DEBUG - 2023-09-05 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:44 --> Total execution time: 0.3398
DEBUG - 2023-09-05 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:46 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:46 --> Total execution time: 0.1617
DEBUG - 2023-09-05 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:38:47 --> Total execution time: 0.2835
DEBUG - 2023-09-05 08:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:47 --> Total execution time: 0.3209
DEBUG - 2023-09-05 08:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:47 --> Total execution time: 0.4197
DEBUG - 2023-09-05 08:38:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:49 --> Total execution time: 0.3349
DEBUG - 2023-09-05 08:38:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:50 --> Total execution time: 0.1658
DEBUG - 2023-09-05 08:38:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:38:50 --> Total execution time: 0.2784
DEBUG - 2023-09-05 08:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:50 --> Total execution time: 0.3013
DEBUG - 2023-09-05 08:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:38:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:38:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:38:51 --> Total execution time: 0.4046
DEBUG - 2023-09-05 08:40:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:40:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:40:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:40:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:40:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:40:11 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:40:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:11 --> Total execution time: 0.3297
DEBUG - 2023-09-05 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:40:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:40:13 --> Total execution time: 0.1644
DEBUG - 2023-09-05 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:40:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:40:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:40:13 --> Total execution time: 0.3278
DEBUG - 2023-09-05 08:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:40:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:40:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:40:13 --> Total execution time: 0.3201
DEBUG - 2023-09-05 08:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:40:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:40:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:40:14 --> Total execution time: 0.3837
DEBUG - 2023-09-05 08:41:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:41:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:41:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:41:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:41:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:41:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:41:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:14 --> Total execution time: 0.3502
DEBUG - 2023-09-05 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:41:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:41:16 --> Total execution time: 0.1614
DEBUG - 2023-09-05 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:41:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:41:16 --> Total execution time: 0.2757
DEBUG - 2023-09-05 08:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:41:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Total execution time: 0.3348
DEBUG - 2023-09-05 08:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:41:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:41:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:41:16 --> Total execution time: 0.4123
DEBUG - 2023-09-05 08:42:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:42:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:42:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:42:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:42:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:42:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:42:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:48 --> Total execution time: 0.3387
DEBUG - 2023-09-05 08:42:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:42:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:42:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:42:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:42:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:42:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:42:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:42:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:42:50 --> Total execution time: 0.1657
DEBUG - 2023-09-05 08:42:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:42:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:42:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:42:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:42:51 --> Total execution time: 0.2812
DEBUG - 2023-09-05 08:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:42:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:42:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:51 --> Total execution time: 0.2990
DEBUG - 2023-09-05 08:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:42:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:42:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:42:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:42:51 --> Total execution time: 0.3934
DEBUG - 2023-09-05 08:43:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:43:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:43:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:43:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 08:43:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:43:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 08:43:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 08:43:07 --> Total execution time: 1.4863
DEBUG - 2023-09-05 08:43:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:43:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:43:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 08:43:27 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:43:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 08:43:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 08:43:28 --> Total execution time: 1.2682
DEBUG - 2023-09-05 08:44:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:44:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:44:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:44:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:44:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:44:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:44:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:49 --> Total execution time: 0.3320
DEBUG - 2023-09-05 08:44:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:44:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:44:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:44:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:44:51 --> Total execution time: 0.1928
DEBUG - 2023-09-05 08:44:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:44:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:44:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:44:51 --> Total execution time: 0.2801
DEBUG - 2023-09-05 08:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:44:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:44:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Total execution time: 0.2593
DEBUG - 2023-09-05 08:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:44:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:44:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:44:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:51 --> Total execution time: 0.3492
DEBUG - 2023-09-05 08:44:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:44:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:44:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:44:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:44:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:44:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:44:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:44:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-05 15:44:55 --> Severity: error --> Exception: implode(): Argument #2 ($array) must be of type ?array, string given C:\Wamp\www\git\jrn\application\controllers\Pos.php 1235
DEBUG - 2023-09-05 08:46:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:46:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:46:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:46:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:46:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:46:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:34 --> Total execution time: 0.3478
DEBUG - 2023-09-05 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:46:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:46:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:46:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:46:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:46:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:46:36 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 15:46:36 --> Total execution time: 0.1814
DEBUG - 2023-09-05 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:46:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:46:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:46:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:46:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:46:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:46:37 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:46:37 --> Total execution time: 0.2739
DEBUG - 2023-09-05 08:46:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:46:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:46:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:46:37 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:37 --> Total execution time: 0.3000
DEBUG - 2023-09-05 08:46:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:46:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:46:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:46:37 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:46:37 --> Total execution time: 0.3800
DEBUG - 2023-09-05 08:47:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:47:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:47:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:47:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:47:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:47:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:47:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:47:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:47:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:47:57 --> Total execution time: 0.3360
DEBUG - 2023-09-05 08:47:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:47:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:47:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:47:59 --> Total execution time: 0.1656
DEBUG - 2023-09-05 08:47:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:47:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:47:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:47:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:47:59 --> Total execution time: 0.2772
DEBUG - 2023-09-05 08:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:47:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:47:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:47:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:48:00 --> Total execution time: 0.3062
DEBUG - 2023-09-05 08:48:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:48:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:48:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:48:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:48:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:48:00 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:48:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:48:00 --> Total execution time: 0.4036
DEBUG - 2023-09-05 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:48:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:48:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:48:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:48:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:48:16 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:48:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-05 15:48:16 --> Severity: error --> Exception: implode(): Argument #2 ($array) must be of type ?array, string given C:\Wamp\www\git\jrn\application\controllers\Pos.php 1235
DEBUG - 2023-09-05 08:50:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:50:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:50:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:50:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:50:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:50:11 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:50:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:11 --> Total execution time: 0.3558
DEBUG - 2023-09-05 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:50:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:50:13 --> Total execution time: 0.1766
DEBUG - 2023-09-05 08:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:50:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:50:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:50:13 --> Total execution time: 0.3026
DEBUG - 2023-09-05 08:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:50:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:50:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Total execution time: 0.3500
DEBUG - 2023-09-05 08:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:50:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:50:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:50:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:50:13 --> Total execution time: 0.4276
DEBUG - 2023-09-05 08:51:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:51:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:51:03 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:51:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:03 --> Total execution time: 0.3242
DEBUG - 2023-09-05 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:51:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:51:05 --> Total execution time: 0.1986
DEBUG - 2023-09-05 08:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:51:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:51:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:51:05 --> Total execution time: 0.2743
DEBUG - 2023-09-05 08:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:51:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:51:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:51:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:06 --> Total execution time: 0.3226
DEBUG - 2023-09-05 08:51:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:51:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:51:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:51:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:51:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:06 --> Total execution time: 0.4065
DEBUG - 2023-09-05 08:51:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:51:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:51:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:51:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:51:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:51:58 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:51:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:51:59 --> Total execution time: 0.3411
DEBUG - 2023-09-05 08:52:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:52:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:52:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:01 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:52:01 --> Total execution time: 0.1661
DEBUG - 2023-09-05 08:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:01 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:52:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:52:01 --> Total execution time: 0.2758
DEBUG - 2023-09-05 08:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:01 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:52:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Total execution time: 0.3040
DEBUG - 2023-09-05 08:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:01 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:52:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:01 --> Total execution time: 0.4095
DEBUG - 2023-09-05 08:52:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:52:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:52:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:52:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:52:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-05 15:52:08 --> Severity: error --> Exception: implode(): Argument #2 ($array) must be of type ?array, string given C:\Wamp\www\git\jrn\application\controllers\Pos.php 1235
DEBUG - 2023-09-05 08:52:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:52:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:52:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:52:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:53 --> Total execution time: 0.3504
DEBUG - 2023-09-05 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 08:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 08:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 15:52:54 --> Total execution time: 0.1627
DEBUG - 2023-09-05 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-05 08:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-05 08:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-05 08:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:52:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 08:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-05 15:52:54 --> Total execution time: 0.2775
DEBUG - 2023-09-05 08:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:52:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:54 --> Total execution time: 0.3026
DEBUG - 2023-09-05 08:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-05 15:52:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-05 15:52:54 --> PHPMailer class is loaded.
DEBUG - 2023-09-05 15:52:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 15:52:55 --> Total execution time: 0.3721
ERROR - 2023-09-05 09:53:45 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
ERROR - 2023-09-05 09:58:29 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
ERROR - 2023-09-05 09:59:22 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
ERROR - 2023-09-05 10:18:37 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
