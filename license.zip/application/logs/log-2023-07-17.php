<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-17 06:21:34 --> Severity: User Error --> Composer detected issues in your platform: Your Composer dependencies require a PHP version ">= 7.3.0". You are running 7.0.33. C:\Wamp\www\git\jrn\vendor\composer\platform_check.php 24
ERROR - 2023-07-17 06:21:58 --> Severity: User Error --> Composer detected issues in your platform: Your Composer dependencies require a PHP version ">= 7.3.0". You are running 7.0.33. C:\Wamp\www\git\jrn\vendor\composer\platform_check.php 24
DEBUG - 2023-07-17 06:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:36:11 --> No URI present. Default controller set.
DEBUG - 2023-07-17 06:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:36:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:36:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:36:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:36:12 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:36:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:12 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:12 --> Total execution time: 2.1108
DEBUG - 2023-07-17 06:36:13 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:36:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:36:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:36:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:36:13 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:36:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-17 13:36:13 --> 404 Page Not Found: 
DEBUG - 2023-07-17 06:36:24 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:36:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:36:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:36:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:36:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:36:24 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:36:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:24 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:36:25 --> Total execution time: 0.9100
DEBUG - 2023-07-17 06:37:01 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:37:01 --> No URI present. Default controller set.
DEBUG - 2023-07-17 06:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:37:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:37:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:37:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:37:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:37:02 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:37:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:02 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:02 --> Total execution time: 0.1714
DEBUG - 2023-07-17 06:37:02 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:37:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:37:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:37:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:37:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:37:02 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:37:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-17 13:37:02 --> 404 Page Not Found: 
DEBUG - 2023-07-17 06:37:15 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:37:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:37:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:37:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:37:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:37:15 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:37:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-17 13:37:15 --> 404 Page Not Found: 
DEBUG - 2023-07-17 06:37:21 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:37:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:37:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:37:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:37:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:37:22 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:37:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:22 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:37:22 --> Total execution time: 0.6381
DEBUG - 2023-07-17 06:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:38:49 --> No URI present. Default controller set.
DEBUG - 2023-07-17 06:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:38:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:38:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:38:49 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:38:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:38:49 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:38:49 --> Total execution time: 0.1783
DEBUG - 2023-07-17 06:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:38:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:38:50 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:38:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-17 13:38:50 --> 404 Page Not Found: 
DEBUG - 2023-07-17 06:39:09 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:39:09 --> No URI present. Default controller set.
DEBUG - 2023-07-17 06:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:39:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:39:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:39:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:39:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:39:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:39:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:39:09 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:39:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:39:09 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:39:09 --> Total execution time: 0.1696
DEBUG - 2023-07-17 06:39:09 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:39:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:39:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:39:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:39:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:39:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:39:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:39:10 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:39:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-17 13:39:10 --> 404 Page Not Found: 
DEBUG - 2023-07-17 06:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:13 --> No URI present. Default controller set.
DEBUG - 2023-07-17 06:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:13 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:13 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:13 --> Total execution time: 0.1602
DEBUG - 2023-07-17 06:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:40:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:14 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-17 13:40:14 --> 404 Page Not Found: 
DEBUG - 2023-07-17 06:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:53 --> No URI present. Default controller set.
DEBUG - 2023-07-17 06:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:40:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:53 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:53 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:53 --> Total execution time: 0.1779
DEBUG - 2023-07-17 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:40:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:57 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:57 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:57 --> Total execution time: 0.6424
DEBUG - 2023-07-17 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:58 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:58 --> Total execution time: 0.2545
DEBUG - 2023-07-17 06:40:58 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:58 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-17 13:40:58 --> 404 Page Not Found: 
DEBUG - 2023-07-17 06:40:58 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:58 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-17 13:40:58 --> 404 Page Not Found: 
DEBUG - 2023-07-17 06:40:59 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:59 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 06:40:59 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:59 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 13:40:59 --> Total execution time: 0.2085
DEBUG - 2023-07-17 06:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 06:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 13:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:59 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:59 --> Total execution time: 0.2168
DEBUG - 2023-07-17 06:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:40:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:40:59 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:40:59 --> Total execution time: 0.2689
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:00 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 13:41:00 --> Total execution time: 0.2471
DEBUG - 2023-07-17 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 13:41:00 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 13:41:00 --> Total execution time: 0.2899
DEBUG - 2023-07-17 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 13:41:00 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 13:41:00 --> Total execution time: 0.3423
DEBUG - 2023-07-17 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 13:41:00 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 13:41:00 --> Total execution time: 0.4376
DEBUG - 2023-07-17 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:00 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 13:41:00 --> Total execution time: 0.4802
DEBUG - 2023-07-17 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:00 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 13:41:00 --> Total execution time: 0.4666
DEBUG - 2023-07-17 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:00 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 13:41:00 --> Total execution time: 0.3090
DEBUG - 2023-07-17 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:00 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 13:41:00 --> Total execution time: 0.2919
DEBUG - 2023-07-17 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:01 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:41:01 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 13:41:01 --> Total execution time: 0.2911
DEBUG - 2023-07-17 06:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 06:41:01 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 13:41:01 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 13:41:01 --> Total execution time: 0.2604
DEBUG - 2023-07-17 06:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 06:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:01 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:01 --> UTF-8 Support Enabled
DEBUG - 2023-07-17 06:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-17 06:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-17 06:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 13:41:01 --> Total execution time: 0.2579
DEBUG - 2023-07-17 06:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:01 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:41:01 --> Total execution time: 0.2671
DEBUG - 2023-07-17 06:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:01 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 13:41:01 --> Total execution time: 0.2475
DEBUG - 2023-07-17 06:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:01 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 06:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 06:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-17 13:41:01 --> Total execution time: 0.2417
DEBUG - 2023-07-17 06:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:01 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:41:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Total execution time: 0.2221
DEBUG - 2023-07-17 06:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-17 13:41:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-17 13:41:01 --> PHPMailer class is loaded.
DEBUG - 2023-07-17 13:41:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 13:41:01 --> Total execution time: 0.3212
