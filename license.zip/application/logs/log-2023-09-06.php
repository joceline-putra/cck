<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-06 01:14:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:39 --> No URI present. Default controller set.
DEBUG - 2023-09-06 01:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:39 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:39 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:39 --> Total execution time: 0.3414
DEBUG - 2023-09-06 01:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:42 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:42 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:42 --> Total execution time: 0.6165
DEBUG - 2023-09-06 01:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:43 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:43 --> Total execution time: 0.2347
DEBUG - 2023-09-06 01:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:14:44 --> Total execution time: 0.2158
DEBUG - 2023-09-06 01:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:44 --> Total execution time: 0.1670
DEBUG - 2023-09-06 01:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:44 --> Total execution time: 0.2049
DEBUG - 2023-09-06 01:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:14:44 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.1923
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2366
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.3050
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2676
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.3905
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.4212
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2181
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2425
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2453
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2606
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2684
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2793
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2754
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2740
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2757
DEBUG - 2023-09-06 01:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:45 --> Total execution time: 0.2755
DEBUG - 2023-09-06 01:14:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:51 --> PHPMailer class is loaded.
ERROR - 2023-09-06 08:14:51 --> Severity: Warning --> Undefined variable $user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-06 08:14:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-06 08:14:51 --> Severity: Warning --> Undefined variable $menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
ERROR - 2023-09-06 08:14:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
DEBUG - 2023-09-06 08:14:51 --> Total execution time: 0.2130
DEBUG - 2023-09-06 01:14:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:14:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:14:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:14:52 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:52 --> Total execution time: 0.1635
DEBUG - 2023-09-06 01:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:52 --> Total execution time: 0.1839
DEBUG - 2023-09-06 01:14:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:55 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:55 --> Total execution time: 0.1985
DEBUG - 2023-09-06 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:14:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:14:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:14:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:14:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:14:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:14:56 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:14:57 --> Total execution time: 0.1829
DEBUG - 2023-09-06 01:15:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:03 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:03 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:15:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:03 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:03 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:03 --> Total execution time: 0.1717
DEBUG - 2023-09-06 01:15:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:05 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:15:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:05 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:05 --> Total execution time: 0.1795
DEBUG - 2023-09-06 01:15:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:18 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:18 --> Total execution time: 0.4077
DEBUG - 2023-09-06 01:15:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:18 --> Total execution time: 0.3262
DEBUG - 2023-09-06 01:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:19 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:15:19 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:19 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:19 --> Total execution time: 0.1686
DEBUG - 2023-09-06 01:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:19 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:15:19 --> Total execution time: 0.2206
DEBUG - 2023-09-06 01:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:19 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Total execution time: 0.2835
DEBUG - 2023-09-06 01:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:19 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:20 --> Total execution time: 0.3796
DEBUG - 2023-09-06 01:15:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:20 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:20 --> Total execution time: 0.4566
DEBUG - 2023-09-06 01:15:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:15:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:15:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:15:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:15:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:15:58 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:15:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:15:58 --> Total execution time: 0.3617
DEBUG - 2023-09-06 01:23:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:23:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:23:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:23:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:23:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:23:19 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:23:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:19 --> Total execution time: 0.3451
DEBUG - 2023-09-06 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:23:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:23:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:23:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:23:21 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:23:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:23:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:23:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:23:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:23:21 --> Total execution time: 0.1621
DEBUG - 2023-09-06 01:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:23:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:23:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:23:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:23:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:23:21 --> Total execution time: 0.2504
DEBUG - 2023-09-06 01:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:23:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:23:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Total execution time: 0.2937
DEBUG - 2023-09-06 01:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:23:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:23:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Total execution time: 0.3360
DEBUG - 2023-09-06 01:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:23:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:23:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:23:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:21 --> Total execution time: 0.4580
DEBUG - 2023-09-06 01:23:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:23:40 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:23:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:23:40 --> Total execution time: 0.3381
DEBUG - 2023-09-06 01:27:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:27:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:27:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:27:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:27:04 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:27:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:04 --> Total execution time: 0.3503
DEBUG - 2023-09-06 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:27:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:27:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:27:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:27:06 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:27:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:27:06 --> Total execution time: 0.1903
DEBUG - 2023-09-06 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:27:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:27:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Total execution time: 0.2296
DEBUG - 2023-09-06 01:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:27:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:27:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:27:06 --> Total execution time: 0.3309
DEBUG - 2023-09-06 01:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:27:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:27:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:27:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:07 --> Total execution time: 0.3503
DEBUG - 2023-09-06 01:27:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:27:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:27:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:27:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:27:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:27:07 --> Total execution time: 0.4514
DEBUG - 2023-09-06 01:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:32:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:32:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:32:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:32:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:32:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:49 --> Total execution time: 0.3430
DEBUG - 2023-09-06 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 01:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:32:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:32:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:32:51 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 01:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:32:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:32:51 --> Total execution time: 0.2515
DEBUG - 2023-09-06 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:32:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:32:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:32:51 --> Total execution time: 0.2514
DEBUG - 2023-09-06 01:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:32:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:32:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:32:51 --> Total execution time: 0.2922
DEBUG - 2023-09-06 01:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:32:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:32:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Total execution time: 0.3237
DEBUG - 2023-09-06 01:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:32:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:32:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:32:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:32:51 --> Total execution time: 0.4399
DEBUG - 2023-09-06 01:33:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:33:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:33:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:33:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:33:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:33:46 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:33:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:46 --> Total execution time: 0.3336
DEBUG - 2023-09-06 01:33:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:33:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:33:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:33:47 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:33:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:33:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:33:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:33:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:33:47 --> Total execution time: 0.1600
DEBUG - 2023-09-06 01:33:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:33:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:33:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:33:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:33:47 --> Total execution time: 0.2283
DEBUG - 2023-09-06 01:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:33:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:33:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:33:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:48 --> Total execution time: 0.2747
DEBUG - 2023-09-06 01:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:33:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:33:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:33:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:33:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:48 --> Total execution time: 0.3631
DEBUG - 2023-09-06 01:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:33:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:33:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:33:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:33:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:33:48 --> Total execution time: 0.4543
DEBUG - 2023-09-06 01:35:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:35:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:35:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:35:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:35:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:35:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:35:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:35:51 --> Total execution time: 1.4595
DEBUG - 2023-09-06 01:39:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:39:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:39:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:39:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:39:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:39:28 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:39:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:28 --> Total execution time: 0.3897
DEBUG - 2023-09-06 01:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:39:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:39:31 --> Total execution time: 0.2020
DEBUG - 2023-09-06 01:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:39:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:39:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:39:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 08:39:31 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:39:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:39:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:39:31 --> Total execution time: 0.2533
DEBUG - 2023-09-06 01:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:39:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:39:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:39:31 --> Total execution time: 0.3332
DEBUG - 2023-09-06 01:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:39:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:39:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Total execution time: 0.4262
DEBUG - 2023-09-06 01:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:39:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:39:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:39:31 --> Total execution time: 0.5393
DEBUG - 2023-09-06 01:40:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:40:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:40:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:40:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:40:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:40:25 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:40:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:25 --> Total execution time: 0.3294
DEBUG - 2023-09-06 01:40:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:40:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:40:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:40:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:40:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:40:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:40:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:40:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:40:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:40:26 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:40:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:40:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:40:27 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:40:27 --> Total execution time: 0.1767
DEBUG - 2023-09-06 01:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:40:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:40:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:40:27 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:40:27 --> Total execution time: 0.2430
DEBUG - 2023-09-06 01:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:40:27 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:40:27 --> Total execution time: 0.2757
DEBUG - 2023-09-06 01:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:40:27 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Total execution time: 0.3544
DEBUG - 2023-09-06 01:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:40:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:40:27 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:40:27 --> Total execution time: 0.4411
DEBUG - 2023-09-06 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:41:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:41:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:41:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:41:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:41:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:41:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:41:22 --> Total execution time: 0.3695
DEBUG - 2023-09-06 01:43:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:29 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:29 --> Total execution time: 0.3397
DEBUG - 2023-09-06 01:43:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:43:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:43:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:43:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:30 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:30 --> Total execution time: 0.1932
DEBUG - 2023-09-06 01:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:43:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:43:30 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:43:30 --> Total execution time: 0.1661
DEBUG - 2023-09-06 01:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:30 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:43:30 --> Total execution time: 0.1920
DEBUG - 2023-09-06 01:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:30 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:43:30 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:30 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:30 --> Total execution time: 0.1932
DEBUG - 2023-09-06 01:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:31 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:31 --> Total execution time: 0.2030
DEBUG - 2023-09-06 01:43:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:33 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:33 --> Total execution time: 0.3223
DEBUG - 2023-09-06 01:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:43:34 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:34 --> Total execution time: 0.2171
DEBUG - 2023-09-06 01:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:43:34 --> Total execution time: 0.2160
DEBUG - 2023-09-06 01:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:35 --> Total execution time: 0.2570
DEBUG - 2023-09-06 01:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:35 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:43:35 --> Total execution time: 0.2602
DEBUG - 2023-09-06 01:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:43:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:43:35 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:43:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:43:35 --> Total execution time: 0.3207
DEBUG - 2023-09-06 01:45:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:45:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:45:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:45:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:45:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:45:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:45:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:07 --> Total execution time: 0.3539
DEBUG - 2023-09-06 01:45:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:45:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:45:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:45:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:45:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:45:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:45:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:45:08 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:45:09 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:45:09 --> Total execution time: 0.1618
DEBUG - 2023-09-06 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:45:09 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:45:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:45:09 --> Total execution time: 0.2478
DEBUG - 2023-09-06 01:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:45:09 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:45:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:45:09 --> Total execution time: 0.2935
DEBUG - 2023-09-06 01:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:45:09 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:45:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Total execution time: 0.3128
DEBUG - 2023-09-06 01:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:45:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:45:09 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:45:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:45:09 --> Total execution time: 0.3962
DEBUG - 2023-09-06 01:47:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:47:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:47:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:47:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:47:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:48 --> Total execution time: 0.2258
DEBUG - 2023-09-06 01:47:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:47:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:47:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 01:47:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:47:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:47:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:47:49 --> Total execution time: 0.1869
DEBUG - 2023-09-06 01:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:47:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:47:49 --> Total execution time: 0.1776
DEBUG - 2023-09-06 01:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:47:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:47:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:47:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:47:49 --> Total execution time: 0.2064
DEBUG - 2023-09-06 01:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:47:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:47:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:47:49 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:47:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 01:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:47:49 --> Total execution time: 0.2269
DEBUG - 2023-09-06 01:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:47:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:47:49 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:47:49 --> Total execution time: 0.2291
DEBUG - 2023-09-06 01:48:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:48:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:48:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:48:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:48:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:48:05 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:48:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:05 --> Total execution time: 1.0574
DEBUG - 2023-09-06 01:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:48:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:48:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:48:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 01:48:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:48:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:48:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:48:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:48:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 08:48:06 --> 404 Page Not Found: 
DEBUG - 2023-09-06 01:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:48:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:48:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:48:07 --> Total execution time: 0.1667
DEBUG - 2023-09-06 01:48:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:48:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 01:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 01:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 01:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:48:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:48:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:48:07 --> Total execution time: 0.2228
DEBUG - 2023-09-06 01:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:48:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:48:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 01:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:48:07 --> Total execution time: 0.2685
DEBUG - 2023-09-06 01:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:48:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:48:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Total execution time: 0.3311
DEBUG - 2023-09-06 01:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:48:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 08:48:07 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 08:48:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:48:07 --> Total execution time: 0.4082
DEBUG - 2023-09-06 06:17:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:17:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:17:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:17:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:17:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:17:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:17:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:17:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:17:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:17:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:17:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:17:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:17:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:17:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:17:15 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:17:15 --> Total execution time: 0.2093
DEBUG - 2023-09-06 06:21:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:21:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:21:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:21:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:21:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:21:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:06 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:06 --> Total execution time: 0.6186
DEBUG - 2023-09-06 06:21:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:21:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:21:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:21:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:21:06 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:21:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:07 --> Total execution time: 0.3766
DEBUG - 2023-09-06 06:21:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:21:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:21:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:21:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:21:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-09-06 13:21:08 --> 404 Page Not Found: 
DEBUG - 2023-09-06 06:21:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:21:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:21:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:21:08 --> Total execution time: 0.2364
DEBUG - 2023-09-06 06:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:21:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:21:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:21:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:21:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Total execution time: 0.2774
DEBUG - 2023-09-06 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:21:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:21:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:21:08 --> Total execution time: 0.2529
DEBUG - 2023-09-06 06:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:21:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:21:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Total execution time: 0.3672
DEBUG - 2023-09-06 06:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:21:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:21:08 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:21:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:08 --> Total execution time: 0.5307
DEBUG - 2023-09-06 06:21:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:21:56 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:21:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:21:56 --> Total execution time: 0.3891
DEBUG - 2023-09-06 06:23:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:40 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:40 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:23:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:40 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:40 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:40 --> Total execution time: 0.1850
DEBUG - 2023-09-06 06:23:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:44 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:23:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:44 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:44 --> Total execution time: 0.1789
DEBUG - 2023-09-06 06:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:48 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:48 --> Total execution time: 0.6470
DEBUG - 2023-09-06 06:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:49 --> Total execution time: 0.2301
DEBUG - 2023-09-06 06:23:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 13:23:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.2458
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 13:23:50 --> 404 Page Not Found: 
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.1999
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.2361
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.1946
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.2557
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.2730
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.3516
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.3730
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.3909
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:50 --> Total execution time: 0.2977
DEBUG - 2023-09-06 06:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:23:51 --> Total execution time: 0.2817
DEBUG - 2023-09-06 06:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:51 --> Total execution time: 0.2910
DEBUG - 2023-09-06 06:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 13:23:51 --> Total execution time: 0.2847
DEBUG - 2023-09-06 06:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:51 --> Total execution time: 0.2793
DEBUG - 2023-09-06 06:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:51 --> Total execution time: 0.2794
DEBUG - 2023-09-06 06:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:51 --> Total execution time: 0.2535
DEBUG - 2023-09-06 06:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:23:51 --> Total execution time: 0.2684
DEBUG - 2023-09-06 06:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Total execution time: 0.2667
DEBUG - 2023-09-06 06:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:23:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:23:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:23:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:23:51 --> Total execution time: 0.2646
DEBUG - 2023-09-06 06:24:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:24:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:24:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:24:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:24:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:24:01 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:24:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:24:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:24:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:24:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:24:46 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:24:46 --> Total execution time: 0.3189
DEBUG - 2023-09-06 06:24:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:24:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 13:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:24:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:24:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 13:24:47 --> 404 Page Not Found: 
DEBUG - 2023-09-06 06:24:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:24:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:24:47 --> Total execution time: 0.1868
DEBUG - 2023-09-06 06:24:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:24:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:24:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:24:47 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:24:48 --> Total execution time: 0.2569
DEBUG - 2023-09-06 06:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:24:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:24:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:24:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:24:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:48 --> Total execution time: 0.3333
DEBUG - 2023-09-06 06:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:24:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:24:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:24:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:24:48 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:24:48 --> Total execution time: 0.4508
DEBUG - 2023-09-06 06:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:19 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:19 --> Total execution time: 0.3466
DEBUG - 2023-09-06 06:25:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 06:25:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:25:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:25:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 13:25:21 --> 404 Page Not Found: 
DEBUG - 2023-09-06 06:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:25:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 06:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 13:25:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:21 --> Total execution time: 0.2003
DEBUG - 2023-09-06 06:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:21 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 06:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:25:22 --> Total execution time: 0.2467
DEBUG - 2023-09-06 06:25:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:22 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:22 --> Total execution time: 0.3325
DEBUG - 2023-09-06 06:25:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:22 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:22 --> Total execution time: 0.4089
DEBUG - 2023-09-06 06:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:25:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:57 --> Total execution time: 0.3279
DEBUG - 2023-09-06 06:25:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:58 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 13:25:58 --> 404 Page Not Found: 
DEBUG - 2023-09-06 06:25:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 06:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:25:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 13:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:59 --> Total execution time: 0.2138
DEBUG - 2023-09-06 06:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 06:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 06:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 06:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:25:59 --> Total execution time: 0.2681
DEBUG - 2023-09-06 06:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 06:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 13:25:59 --> Total execution time: 0.3297
DEBUG - 2023-09-06 06:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Total execution time: 0.3793
DEBUG - 2023-09-06 06:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 13:25:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 13:25:59 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 13:25:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 13:25:59 --> Total execution time: 0.5054
DEBUG - 2023-09-06 07:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:49:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:49:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:49:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:49:15 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:49:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:15 --> Total execution time: 0.3745
DEBUG - 2023-09-06 07:49:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:49:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:49:17 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:49:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 14:49:17 --> 404 Page Not Found: 
DEBUG - 2023-09-06 07:49:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:49:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:49:18 --> Total execution time: 0.1647
DEBUG - 2023-09-06 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:49:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:49:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:49:18 --> Total execution time: 0.2315
DEBUG - 2023-09-06 07:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:49:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:49:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Total execution time: 0.2860
DEBUG - 2023-09-06 07:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:49:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:49:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Total execution time: 0.3685
DEBUG - 2023-09-06 07:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:49:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:49:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:49:18 --> Total execution time: 0.4530
DEBUG - 2023-09-06 07:52:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:52:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:52:11 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:52:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:11 --> Total execution time: 0.3970
DEBUG - 2023-09-06 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:52:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:52:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 14:52:12 --> 404 Page Not Found: 
DEBUG - 2023-09-06 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:52:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:52:12 --> Total execution time: 0.1637
DEBUG - 2023-09-06 07:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:52:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:52:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:52:12 --> Total execution time: 0.2197
DEBUG - 2023-09-06 07:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:52:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:52:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:52:12 --> Total execution time: 0.2683
DEBUG - 2023-09-06 07:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:52:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:52:12 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:52:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:13 --> Total execution time: 0.3618
DEBUG - 2023-09-06 07:52:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:52:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:52:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:52:13 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:52:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:52:13 --> Total execution time: 0.4386
DEBUG - 2023-09-06 07:53:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:33 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:34 --> Total execution time: 0.3412
DEBUG - 2023-09-06 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 14:53:34 --> 404 Page Not Found: 
DEBUG - 2023-09-06 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:34 --> Total execution time: 0.1648
DEBUG - 2023-09-06 07:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:53:34 --> Total execution time: 0.2195
DEBUG - 2023-09-06 07:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:35 --> Total execution time: 0.2757
DEBUG - 2023-09-06 07:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:35 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:35 --> Total execution time: 0.3231
DEBUG - 2023-09-06 07:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:35 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:35 --> Total execution time: 0.4446
DEBUG - 2023-09-06 07:53:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:56 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:56 --> Total execution time: 0.3212
DEBUG - 2023-09-06 07:53:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:56 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 14:53:56 --> 404 Page Not Found: 
DEBUG - 2023-09-06 07:53:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:57 --> Total execution time: 0.1691
DEBUG - 2023-09-06 07:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 07:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:53:57 --> Total execution time: 0.2223
DEBUG - 2023-09-06 07:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:57 --> Total execution time: 0.3109
DEBUG - 2023-09-06 07:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:53:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:53:57 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:53:57 --> Total execution time: 0.3722
DEBUG - 2023-09-06 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:41 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:41 --> Total execution time: 0.3568
DEBUG - 2023-09-06 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:42 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 14:54:42 --> 404 Page Not Found: 
DEBUG - 2023-09-06 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:42 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:42 --> Total execution time: 0.1624
DEBUG - 2023-09-06 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:42 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:54:42 --> Total execution time: 0.2182
DEBUG - 2023-09-06 07:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:42 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Total execution time: 0.2702
DEBUG - 2023-09-06 07:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:42 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Total execution time: 0.3277
DEBUG - 2023-09-06 07:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:42 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:42 --> Total execution time: 0.4441
DEBUG - 2023-09-06 07:54:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:50 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:50 --> Total execution time: 0.3385
DEBUG - 2023-09-06 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:54:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 14:54:51 --> 404 Page Not Found: 
DEBUG - 2023-09-06 07:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 14:54:51 --> Total execution time: 0.1609
DEBUG - 2023-09-06 07:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:54:51 --> Total execution time: 0.2333
DEBUG - 2023-09-06 07:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Total execution time: 0.2860
DEBUG - 2023-09-06 07:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:51 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:52 --> Total execution time: 0.3403
DEBUG - 2023-09-06 07:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:54:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:54:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:54:52 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:54:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:54:52 --> Total execution time: 0.4477
DEBUG - 2023-09-06 07:55:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:55:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:55:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:55:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:55:22 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:55:22 --> Total execution time: 0.3129
DEBUG - 2023-09-06 07:55:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:55:23 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:55:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 14:55:23 --> 404 Page Not Found: 
DEBUG - 2023-09-06 07:55:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:55:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 07:55:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 14:55:23 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:55:23 --> Total execution time: 0.1714
DEBUG - 2023-09-06 07:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:55:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:55:23 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 07:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:55:23 --> Total execution time: 0.2257
DEBUG - 2023-09-06 07:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:55:23 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:55:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 07:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 14:55:23 --> Total execution time: 0.2856
DEBUG - 2023-09-06 07:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:55:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:55:23 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:55:24 --> Total execution time: 0.3163
DEBUG - 2023-09-06 07:58:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:58:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:58:15 --> Total execution time: 0.2316
DEBUG - 2023-09-06 07:58:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:58:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:58:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:58:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:58:19 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:58:20 --> Total execution time: 0.2242
DEBUG - 2023-09-06 07:58:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:58:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:58:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:58:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:58:22 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:58:22 --> Total execution time: 0.2317
DEBUG - 2023-09-06 07:58:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:58:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:58:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:58:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:58:23 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:58:23 --> Total execution time: 0.2317
DEBUG - 2023-09-06 07:58:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:58:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:58:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:58:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:58:23 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:58:23 --> Total execution time: 0.2121
DEBUG - 2023-09-06 07:58:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:58:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:58:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:58:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:58:25 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:58:25 --> Total execution time: 0.2219
DEBUG - 2023-09-06 07:58:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:58:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:58:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:58:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:58:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:58:26 --> Total execution time: 0.2160
DEBUG - 2023-09-06 07:58:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:58:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:58:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:58:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:58:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:58:29 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:58:29 --> Total execution time: 0.2234
DEBUG - 2023-09-06 07:58:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 07:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 07:58:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 07:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 07:58:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 14:58:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 14:58:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 14:58:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 14:58:34 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 14:58:34 --> Total execution time: 0.2224
DEBUG - 2023-09-06 08:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:10:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:10:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 15:10:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 15:10:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 15:10:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 15:10:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 15:10:13 --> PHPMailer class is loaded.
ERROR - 2023-09-06 15:10:13 --> Severity: Warning --> Undefined variable $user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-06 15:10:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 624
ERROR - 2023-09-06 15:10:13 --> Severity: Warning --> Undefined variable $menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
ERROR - 2023-09-06 15:10:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 641
DEBUG - 2023-09-06 15:10:13 --> Total execution time: 0.2672
DEBUG - 2023-09-06 08:10:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:10:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 15:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 15:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 15:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 15:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 15:10:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 15:10:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-06 15:10:14 --> 404 Page Not Found: 
DEBUG - 2023-09-06 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:10:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 15:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 08:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 15:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 15:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 08:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 15:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 15:10:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 15:10:14 --> Total execution time: 0.2008
DEBUG - 2023-09-06 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 15:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 15:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 15:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 15:10:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 15:10:14 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 15:10:14 --> Total execution time: 0.1869
DEBUG - 2023-09-06 08:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 08:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 08:10:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-06 08:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-06 08:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 15:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 15:10:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-06 15:10:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-06 15:10:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-06 15:10:18 --> PHPMailer class is loaded.
DEBUG - 2023-09-06 15:10:18 --> Total execution time: 0.2442
