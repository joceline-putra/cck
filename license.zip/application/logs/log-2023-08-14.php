<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-14 07:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:10:20 --> No URI present. Default controller set.
DEBUG - 2023-08-14 07:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:10:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:10:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:10:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:10:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:10:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:10:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:10:22 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:10:22 --> Total execution time: 2.3922
DEBUG - 2023-08-14 07:12:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:10 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:11 --> Total execution time: 0.8774
DEBUG - 2023-08-14 07:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:12 --> Total execution time: 0.8045
DEBUG - 2023-08-14 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 07:12:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.7217
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.6113
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.5617
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.6097
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 1.0752
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 1.0022
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.5764
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.5546
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.4977
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.6149
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.2798
DEBUG - 2023-08-14 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.2652
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:12:14 --> Total execution time: 0.2431
DEBUG - 2023-08-14 07:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 07:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 14:12:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 14:12:15 --> Total execution time: 0.2010
DEBUG - 2023-08-14 07:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:12:15 --> Total execution time: 0.2586
DEBUG - 2023-08-14 07:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:15 --> Total execution time: 0.2624
DEBUG - 2023-08-14 07:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:15 --> Total execution time: 0.3042
DEBUG - 2023-08-14 07:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:16 --> Total execution time: 1.4384
DEBUG - 2023-08-14 07:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:16 --> Total execution time: 1.5255
DEBUG - 2023-08-14 07:12:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:25 --> Total execution time: 0.5593
DEBUG - 2023-08-14 07:12:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 07:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 14:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:26 --> Total execution time: 0.2089
DEBUG - 2023-08-14 07:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:12:26 --> Total execution time: 0.2313
DEBUG - 2023-08-14 07:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:12:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:12:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:12:26 --> Total execution time: 0.2017
DEBUG - 2023-08-14 07:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:13:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:13:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:13:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:13:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:13:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:13:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:13:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:13:33 --> Total execution time: 0.2322
DEBUG - 2023-08-14 07:13:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:13:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:13:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 07:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 14:13:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 14:13:35 --> Total execution time: 0.1668
DEBUG - 2023-08-14 07:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:13:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:13:35 --> Total execution time: 0.2223
DEBUG - 2023-08-14 07:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:13:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:13:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:13:35 --> Total execution time: 0.2062
DEBUG - 2023-08-14 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:18:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:18:14 --> Total execution time: 0.3143
DEBUG - 2023-08-14 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:18:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:18:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 07:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:18:14 --> Total execution time: 0.2592
DEBUG - 2023-08-14 07:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:18:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:18:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:18:14 --> Total execution time: 0.3548
DEBUG - 2023-08-14 07:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:18:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:18:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:18:14 --> Total execution time: 0.5805
DEBUG - 2023-08-14 07:19:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:19:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:19:55 --> Total execution time: 0.2659
DEBUG - 2023-08-14 07:19:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:19:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:19:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:19:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:19:55 --> Total execution time: 0.3524
DEBUG - 2023-08-14 07:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:19:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:19:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Total execution time: 0.4519
DEBUG - 2023-08-14 07:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:19:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:19:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:19:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:19:55 --> Total execution time: 0.5707
DEBUG - 2023-08-14 07:23:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:23:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:23:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:23:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:23:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:23:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:23:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:23:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:23:34 --> Total execution time: 0.2343
DEBUG - 2023-08-14 07:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 07:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 14:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 07:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 14:23:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:23:36 --> Total execution time: 0.1592
DEBUG - 2023-08-14 07:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:23:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:23:36 --> Total execution time: 0.2250
DEBUG - 2023-08-14 07:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:23:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:23:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:23:36 --> Total execution time: 0.2055
DEBUG - 2023-08-14 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:24:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:24:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:24:41 --> Total execution time: 0.2954
DEBUG - 2023-08-14 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:24:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:24:41 --> Total execution time: 0.3547
DEBUG - 2023-08-14 07:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:24:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:24:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Total execution time: 0.4277
DEBUG - 2023-08-14 07:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:24:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:24:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:24:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:24:41 --> Total execution time: 0.5496
DEBUG - 2023-08-14 07:25:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:25:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:25:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:25:21 --> Total execution time: 0.2223
DEBUG - 2023-08-14 07:25:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:25:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:25:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:25:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:25:23 --> Total execution time: 0.1632
DEBUG - 2023-08-14 07:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:25:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:25:23 --> Total execution time: 0.2368
DEBUG - 2023-08-14 07:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:25:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:25:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:25:23 --> Total execution time: 0.2435
DEBUG - 2023-08-14 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:25:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:25:26 --> Total execution time: 0.2758
DEBUG - 2023-08-14 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 07:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:25:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:25:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 07:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:25:26 --> Total execution time: 0.2625
DEBUG - 2023-08-14 07:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:25:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:25:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:26 --> Total execution time: 0.3529
DEBUG - 2023-08-14 07:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:25:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:25:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:25:26 --> Total execution time: 0.5715
DEBUG - 2023-08-14 07:27:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:27:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:27:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:27:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:27:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:27:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:27:33 --> Total execution time: 0.2246
DEBUG - 2023-08-14 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:27:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:27:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:27:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:27:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:27:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:27:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:27:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:27:34 --> Total execution time: 0.2507
DEBUG - 2023-08-14 07:27:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:27:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:27:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:27:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:27:34 --> Total execution time: 0.2366
DEBUG - 2023-08-14 07:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:27:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:27:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:27:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:27:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:27:35 --> Total execution time: 1.2998
DEBUG - 2023-08-14 07:27:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:27:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:27:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:27:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:27:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:27:40 --> Total execution time: 0.1971
DEBUG - 2023-08-14 07:27:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:27:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:27:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:27:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:27:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:27:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:27:44 --> Total execution time: 0.2087
DEBUG - 2023-08-14 07:27:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:27:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:27:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:27:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:27:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:27:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:27:52 --> Total execution time: 0.1834
DEBUG - 2023-08-14 07:27:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:27:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:27:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:27:54 --> Total execution time: 0.1950
DEBUG - 2023-08-14 07:28:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:28:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:28:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:28:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:28:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:28:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:28:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:28:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:28:03 --> Total execution time: 0.1980
DEBUG - 2023-08-14 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:28:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:28:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:28:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:28:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:28:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:28:40 --> Total execution time: 0.1883
DEBUG - 2023-08-14 07:28:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:28:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:28:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:28:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:28:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:28:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:28:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:28:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:28:48 --> Total execution time: 0.2096
DEBUG - 2023-08-14 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:28:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:28:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:28:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:28:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:28:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:28:51 --> Total execution time: 0.1998
DEBUG - 2023-08-14 07:30:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:30:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:30:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:30:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:30:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:30:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:30:23 --> Total execution time: 0.2407
DEBUG - 2023-08-14 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:30:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:30:24 --> Total execution time: 0.1712
DEBUG - 2023-08-14 07:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:30:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:30:24 --> Total execution time: 0.2538
DEBUG - 2023-08-14 07:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:30:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:30:24 --> Total execution time: 0.2446
DEBUG - 2023-08-14 07:30:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:30:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:30:28 --> Total execution time: 0.2035
DEBUG - 2023-08-14 07:30:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:30:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:30:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:30:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:30:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:30:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:30:36 --> Total execution time: 0.2044
DEBUG - 2023-08-14 07:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:30:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:30:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:30:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:30:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:30:39 --> Total execution time: 0.1962
DEBUG - 2023-08-14 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:30:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:30:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:30:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:30:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:30:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:30:40 --> Total execution time: 0.1864
DEBUG - 2023-08-14 07:30:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:30:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:30:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:30:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:30:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:30:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:30:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:30:48 --> Total execution time: 0.2194
DEBUG - 2023-08-14 07:31:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:31:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:31:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:31:40 --> Total execution time: 0.2167
DEBUG - 2023-08-14 07:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:31:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:31:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:31:40 --> Total execution time: 0.2076
DEBUG - 2023-08-14 07:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:31:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:31:42 --> Total execution time: 0.1885
DEBUG - 2023-08-14 07:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:31:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:31:42 --> Total execution time: 0.2679
DEBUG - 2023-08-14 07:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:31:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:31:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:31:42 --> Total execution time: 0.2321
DEBUG - 2023-08-14 07:32:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:32:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:32:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:32:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:32:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:32:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:32:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:32:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:32:42 --> Total execution time: 0.2276
DEBUG - 2023-08-14 07:32:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:32:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:32:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:32:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:32:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:32:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:32:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:32:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:32:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:32:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:32:43 --> Total execution time: 0.1869
DEBUG - 2023-08-14 07:32:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:32:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:32:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:32:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:32:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:32:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:32:44 --> Total execution time: 0.2715
DEBUG - 2023-08-14 07:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:32:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:32:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:32:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:32:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:32:44 --> Total execution time: 0.2038
DEBUG - 2023-08-14 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:33:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:33:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:33:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:33:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:33:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:33:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:33:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:33:43 --> Total execution time: 0.2121
DEBUG - 2023-08-14 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:34:28 --> Total execution time: 0.2272
DEBUG - 2023-08-14 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:34:30 --> Total execution time: 0.1691
DEBUG - 2023-08-14 07:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:34:30 --> Total execution time: 0.2562
DEBUG - 2023-08-14 07:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:34:30 --> Total execution time: 0.2472
DEBUG - 2023-08-14 07:34:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:34:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:34:39 --> Total execution time: 0.2400
DEBUG - 2023-08-14 07:34:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:34:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 07:34:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 14:34:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 14:34:40 --> Total execution time: 0.1809
DEBUG - 2023-08-14 07:34:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:34:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:34:41 --> Total execution time: 0.2471
DEBUG - 2023-08-14 07:34:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:34:41 --> Total execution time: 0.2394
DEBUG - 2023-08-14 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:34:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:34:56 --> Total execution time: 0.3034
DEBUG - 2023-08-14 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:34:56 --> Total execution time: 0.3597
DEBUG - 2023-08-14 07:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:34:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:56 --> Total execution time: 0.4863
DEBUG - 2023-08-14 07:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:34:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:34:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:34:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:34:56 --> Total execution time: 0.5635
DEBUG - 2023-08-14 07:35:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:35:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:35:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:35:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:35:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:35:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:35:00 --> Total execution time: 0.3551
DEBUG - 2023-08-14 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:35:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:35:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:35:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:35:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:35:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:35:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:05 --> Total execution time: 0.2776
DEBUG - 2023-08-14 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:35:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:35:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:35:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:35:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:35:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:35:21 --> Total execution time: 0.3212
DEBUG - 2023-08-14 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:35:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:35:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:35:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:35:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:35:25 --> Total execution time: 0.2940
DEBUG - 2023-08-14 07:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:35:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:35:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:35:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:35:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:35:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:35:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:35:48 --> Total execution time: 0.2970
DEBUG - 2023-08-14 07:37:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:37:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:37:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:37:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:37:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:37:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:37:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:37:38 --> PHPMailer class is loaded.
ERROR - 2023-08-14 14:37:38 --> Severity: Warning --> Undefined array key "branch_2_address" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 52
ERROR - 2023-08-14 14:37:38 --> Severity: Warning --> Undefined array key "branch_2_phone" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 53
DEBUG - 2023-08-14 14:37:38 --> Total execution time: 0.4495
DEBUG - 2023-08-14 07:38:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:38:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:38:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:38:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:38:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:38:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:38:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:38:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:39:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:39:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:39:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:39:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:39:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:39:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:39:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:39:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:39:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:39:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:39:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:40:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:40:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:40:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:40:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:40:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:40:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:40:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:40:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:40:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:40:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:40:17 --> Total execution time: 0.3010
DEBUG - 2023-08-14 07:50:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:50:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:50:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:50:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:50:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:50:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:50:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:50:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:52:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:52:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:52:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:52:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:52:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:52:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:52:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:52:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:53:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:53:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:53:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:53:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:53:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:53:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:53:05 --> PHPMailer class is loaded.
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:05 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
DEBUG - 2023-08-14 14:53:05 --> Total execution time: 0.3487
DEBUG - 2023-08-14 07:53:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:53:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:53:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:53:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:53:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:53:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:53:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:53:11 --> PHPMailer class is loaded.
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 97
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_part_number" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 100
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_division" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 101
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_price" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 102
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_qty" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 103
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_unit" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 104
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_total" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 105
ERROR - 2023-08-14 14:53:11 --> Severity: Warning --> Undefined array key "order_item_note" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\prints\purchase_order.php 106
DEBUG - 2023-08-14 14:53:11 --> Total execution time: 0.3430
DEBUG - 2023-08-14 07:53:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:53:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:53:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:53:36 --> Total execution time: 0.2879
DEBUG - 2023-08-14 07:54:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:54:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:54:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:54:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:54:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:54:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:54:02 --> Total execution time: 0.2359
DEBUG - 2023-08-14 07:54:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:54:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:54:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:54:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:54:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:54:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:54:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:54:04 --> Total execution time: 0.2180
DEBUG - 2023-08-14 07:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:54:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:54:04 --> Total execution time: 0.2983
DEBUG - 2023-08-14 07:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:54:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:54:04 --> Total execution time: 0.2244
DEBUG - 2023-08-14 07:54:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:54:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:54:08 --> Total execution time: 0.2686
DEBUG - 2023-08-14 07:54:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:54:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:54:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 07:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:54:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:54:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 07:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:54:08 --> Total execution time: 0.2282
DEBUG - 2023-08-14 07:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:54:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:54:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:54:09 --> Total execution time: 0.4441
DEBUG - 2023-08-14 07:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:54:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:54:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:54:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:54:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:54:09 --> Total execution time: 0.5504
DEBUG - 2023-08-14 07:55:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:13 --> Total execution time: 0.3237
DEBUG - 2023-08-14 07:55:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:55:13 --> Total execution time: 0.3744
DEBUG - 2023-08-14 07:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:13 --> Total execution time: 0.4550
DEBUG - 2023-08-14 07:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:14 --> Total execution time: 0.5691
DEBUG - 2023-08-14 07:55:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:55:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:48 --> Total execution time: 0.2803
DEBUG - 2023-08-14 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:49 --> Total execution time: 0.1929
DEBUG - 2023-08-14 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:49 --> Total execution time: 0.2639
DEBUG - 2023-08-14 07:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:49 --> Total execution time: 0.2299
DEBUG - 2023-08-14 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:52 --> Total execution time: 0.3123
DEBUG - 2023-08-14 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:55:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 07:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:55:53 --> Total execution time: 0.2766
DEBUG - 2023-08-14 07:55:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:53 --> Total execution time: 0.4143
DEBUG - 2023-08-14 07:55:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:55:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:55:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:55:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:55:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:55:53 --> Total execution time: 0.6121
DEBUG - 2023-08-14 07:58:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:58:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:58:48 --> Total execution time: 0.2611
DEBUG - 2023-08-14 07:58:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:58:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:58:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 07:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 07:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 07:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:58:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:58:49 --> Total execution time: 0.1639
DEBUG - 2023-08-14 07:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 07:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:58:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 07:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 14:58:49 --> Total execution time: 0.2235
DEBUG - 2023-08-14 07:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 14:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 14:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 14:58:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 14:58:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 14:58:49 --> Total execution time: 0.1997
DEBUG - 2023-08-14 08:00:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:00:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:00:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:00:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:00:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:00:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:00:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:00:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:00:47 --> Total execution time: 0.2396
DEBUG - 2023-08-14 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:00:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 08:00:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 15:00:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 08:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 15:00:49 --> Total execution time: 0.1643
DEBUG - 2023-08-14 08:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:00:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:00:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:00:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:00:49 --> Total execution time: 0.2196
DEBUG - 2023-08-14 08:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:00:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:00:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:00:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:00:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:00:50 --> Total execution time: 0.8906
DEBUG - 2023-08-14 08:01:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:01 --> Total execution time: 0.2663
DEBUG - 2023-08-14 08:01:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 08:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 15:01:01 --> Total execution time: 0.3526
DEBUG - 2023-08-14 08:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Total execution time: 0.4565
DEBUG - 2023-08-14 08:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:01 --> Total execution time: 0.5406
DEBUG - 2023-08-14 08:01:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:05 --> Total execution time: 0.1930
DEBUG - 2023-08-14 08:01:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:17 --> Total execution time: 0.7598
DEBUG - 2023-08-14 08:01:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:18 --> Total execution time: 0.1818
DEBUG - 2023-08-14 08:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:19 --> Total execution time: 0.3774
DEBUG - 2023-08-14 08:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:20 --> Total execution time: 0.1847
DEBUG - 2023-08-14 08:01:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:22 --> Total execution time: 0.1786
DEBUG - 2023-08-14 08:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:39 --> Total execution time: 0.2826
DEBUG - 2023-08-14 08:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:39 --> Total execution time: 0.4022
DEBUG - 2023-08-14 08:01:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:47 --> Total execution time: 0.1895
DEBUG - 2023-08-14 08:01:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:49 --> Total execution time: 0.1918
DEBUG - 2023-08-14 08:01:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:51 --> Total execution time: 0.1860
DEBUG - 2023-08-14 08:01:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:01:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:01:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:01:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:01:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:01:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:01:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:01:52 --> Total execution time: 0.2323
DEBUG - 2023-08-14 08:02:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:02:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:02:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:02:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:02:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:02:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:02:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:02:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:02:08 --> Total execution time: 0.2721
DEBUG - 2023-08-14 08:02:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:02:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:02:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:02:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:02:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:02:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:02:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:02:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:02:09 --> Total execution time: 0.4234
DEBUG - 2023-08-14 08:02:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:02:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:02:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:02:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:02:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:02:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:02:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:02:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:02:56 --> Total execution time: 0.2756
DEBUG - 2023-08-14 08:05:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:05:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:05:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:05:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:05:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:05:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:05:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:05:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:05:02 --> Total execution time: 0.2518
DEBUG - 2023-08-14 08:05:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:05:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:05:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 08:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 15:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:05:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:05:03 --> Total execution time: 0.1688
DEBUG - 2023-08-14 08:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:05:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 08:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 15:05:03 --> Total execution time: 0.2222
DEBUG - 2023-08-14 08:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:05:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:05:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:05:03 --> Total execution time: 0.2018
DEBUG - 2023-08-14 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:05:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:05:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:05:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:05:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:05:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:05:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:05:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:05:11 --> Total execution time: 0.1848
DEBUG - 2023-08-14 08:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:08:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:08:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:08:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:08:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:08:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:08:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:08:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:08:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:08:37 --> Total execution time: 0.2656
DEBUG - 2023-08-14 08:08:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:08:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:08:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:08:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:08:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:08:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:08:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:08:51 --> Total execution time: 0.2397
DEBUG - 2023-08-14 08:09:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:09:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:09:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:09:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:09:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:09:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:09:05 --> Total execution time: 0.6063
DEBUG - 2023-08-14 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:09:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:09:06 --> Total execution time: 0.1675
DEBUG - 2023-08-14 08:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:09:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 08:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 15:09:06 --> Total execution time: 0.2262
DEBUG - 2023-08-14 08:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:09:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:09:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:09:06 --> Total execution time: 0.2103
DEBUG - 2023-08-14 08:09:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:09:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:09:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:09:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:09:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:09:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:09:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:09:09 --> Total execution time: 0.2708
DEBUG - 2023-08-14 08:50:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:50:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:50:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:50:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:50:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:50:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:50:54 --> Total execution time: 0.2366
DEBUG - 2023-08-14 08:50:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:50:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:50:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:50:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:50:55 --> Total execution time: 0.1654
DEBUG - 2023-08-14 08:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:50:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 08:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 15:50:55 --> Total execution time: 0.2584
DEBUG - 2023-08-14 08:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:50:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:50:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:50:55 --> Total execution time: 0.2490
DEBUG - 2023-08-14 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:50:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:50:59 --> Total execution time: 0.2970
DEBUG - 2023-08-14 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-14 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-14 08:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-14 08:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:50:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 08:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 08:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-14 15:50:59 --> Total execution time: 0.4522
DEBUG - 2023-08-14 08:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:50:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:50:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:51:00 --> Total execution time: 0.5757
DEBUG - 2023-08-14 08:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:51:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-14 15:51:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-14 15:51:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-14 15:51:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-14 15:51:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-14 15:51:00 --> Total execution time: 0.6746
