<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-07 03:52:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:20 --> No URI present. Default controller set.
DEBUG - 2023-08-07 03:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:23 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:24 --> Total execution time: 3.8380
DEBUG - 2023-08-07 03:52:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:28 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:29 --> Total execution time: 0.7909
DEBUG - 2023-08-07 03:52:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:30 --> Total execution time: 1.0517
DEBUG - 2023-08-07 03:52:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 03:52:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2023-08-07 10:52:31 --> 404 Page Not Found: 
DEBUG - 2023-08-07 03:52:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:52:31 --> 404 Page Not Found: 
DEBUG - 2023-08-07 03:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 03:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 10:52:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 03:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 10:52:32 --> Total execution time: 0.6686
DEBUG - 2023-08-07 03:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 10:52:32 --> Total execution time: 1.0104
DEBUG - 2023-08-07 03:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 10:52:32 --> Total execution time: 1.0320
DEBUG - 2023-08-07 03:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 03:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 10:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.7829
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.8374
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.8662
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.6554
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.3234
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.2974
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.3653
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.3457
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.3489
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.2853
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.2435
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.2384
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.2343
DEBUG - 2023-08-07 03:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:33 --> Total execution time: 0.3440
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 03:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 10:52:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:34 --> Total execution time: 1.1204
DEBUG - 2023-08-07 03:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:52:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:52:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:52:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:52:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:52:34 --> Total execution time: 1.2246
DEBUG - 2023-08-07 03:53:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:53:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:53:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:53:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:53:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:53:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:53:49 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
ERROR - 2023-08-07 10:53:49 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
DEBUG - 2023-08-07 10:53:49 --> Total execution time: 0.6185
DEBUG - 2023-08-07 03:53:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:53:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:53:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:53:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:53:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:53:50 --> 404 Page Not Found: 
DEBUG - 2023-08-07 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:53:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:53:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:53:50 --> 404 Page Not Found: 
DEBUG - 2023-08-07 03:53:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:53:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:53:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:53:50 --> Total execution time: 0.1552
DEBUG - 2023-08-07 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:53:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:53:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:50 --> Total execution time: 0.2199
DEBUG - 2023-08-07 03:53:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:53:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:53:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:53 --> Total execution time: 0.2244
DEBUG - 2023-08-07 03:53:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:53:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:53:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:53:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:53:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:53:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:53:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:53:58 --> 404 Page Not Found: 
DEBUG - 2023-08-07 03:54:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:54:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:54:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:54:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:54:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:54:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:54:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:54:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:54:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:54:34 --> Total execution time: 0.2377
DEBUG - 2023-08-07 03:54:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:54:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:54:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:54:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:54:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:54:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:54:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:54:34 --> Total execution time: 0.2225
DEBUG - 2023-08-07 03:54:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:54:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:54:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:54:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:54:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:54:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:54:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:54:36 --> Total execution time: 0.2261
DEBUG - 2023-08-07 03:55:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:55:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:55:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:55:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:55:11 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 10:55:11 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 10:55:11 --> Total execution time: 0.3589
DEBUG - 2023-08-07 03:55:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:55:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:55:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:55:11 --> 404 Page Not Found: 
DEBUG - 2023-08-07 03:55:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:55:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:55:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:55:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:55:11 --> 404 Page Not Found: 
DEBUG - 2023-08-07 03:55:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:55:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:55:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:55:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:55:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:55:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:55:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:55:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:55:12 --> Total execution time: 0.1786
DEBUG - 2023-08-07 03:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:55:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:55:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:55:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:55:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:55:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:55:12 --> Total execution time: 0.2440
DEBUG - 2023-08-07 03:58:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:58:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:58:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:58:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:58:43 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
ERROR - 2023-08-07 10:58:43 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
DEBUG - 2023-08-07 10:58:43 --> Total execution time: 0.2733
DEBUG - 2023-08-07 03:58:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:58:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:58:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:58:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 03:58:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-08-07 10:58:43 --> 404 Page Not Found: 
DEBUG - 2023-08-07 03:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:58:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:58:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:58:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:58:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 10:58:43 --> 404 Page Not Found: 
DEBUG - 2023-08-07 03:58:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:58:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 03:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 03:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 03:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:58:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:58:44 --> Total execution time: 0.1729
DEBUG - 2023-08-07 03:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 03:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 10:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 10:58:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 10:58:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 10:58:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 10:58:44 --> Total execution time: 0.2230
DEBUG - 2023-08-07 04:03:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:03:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:03:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:03:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:03:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:03:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:03:09 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:03:09 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:03:09 --> Total execution time: 0.2693
DEBUG - 2023-08-07 04:03:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:03:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:03:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 11:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:03:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:03:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:03:10 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:03:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:03:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:03:10 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:03:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:03:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:03:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:03:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:03:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 04:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 11:03:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:03:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:03:11 --> Total execution time: 0.2100
DEBUG - 2023-08-07 04:03:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:03:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:03:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:03:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:03:11 --> Total execution time: 0.2527
DEBUG - 2023-08-07 04:04:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:04:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:04:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:04:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:04:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:04:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:04:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:04:40 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
ERROR - 2023-08-07 11:04:40 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
DEBUG - 2023-08-07 11:04:40 --> Total execution time: 0.2765
DEBUG - 2023-08-07 04:04:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:04:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:04:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:04:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:04:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:04:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:04:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:04:40 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:04:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:04:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:04:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:04:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:04:41 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:04:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:04:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:04:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:04:41 --> Total execution time: 0.1646
DEBUG - 2023-08-07 04:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:04:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:04:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:04:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:04:41 --> Total execution time: 0.2227
DEBUG - 2023-08-07 04:07:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:07:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:07:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:07:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:07:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:07:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:07:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:07:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:07:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:10:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:10:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:10:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:10:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:10:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:10:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:10:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:10:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:10:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:10:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:10:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:10:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:10:50 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:10:50 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:10:50 --> Total execution time: 3.5348
DEBUG - 2023-08-07 04:10:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:10:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:10:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:10:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:10:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:10:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:10:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 04:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 11:10:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:10:51 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:10:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:10:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:10:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:10:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:10:51 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:10:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:10:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:10:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:10:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:10:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:10:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:10:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:10:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:10:52 --> Total execution time: 0.1834
DEBUG - 2023-08-07 04:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:10:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:10:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:10:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:10:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:10:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:10:52 --> Total execution time: 0.2508
DEBUG - 2023-08-07 04:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:11:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:11:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:11:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:11:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:11:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:11:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:16:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:16:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:16:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:16:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:16:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:16:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:16:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:16:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:16:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:16:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:16:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:16:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:16:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:16:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:16:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:16:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:16:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:16:59 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:16:59 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:16:59 --> Total execution time: 0.2815
DEBUG - 2023-08-07 04:16:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:16:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:16:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:16:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:16:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:16:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:16:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:16:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:16:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:16:59 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:17:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:17:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:17:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:17:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:17:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:17:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:17:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:17:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:17:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:17:00 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:17:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:17:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:17:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:17:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:17:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:17:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:17:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:17:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:17:01 --> Total execution time: 0.1885
DEBUG - 2023-08-07 04:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:17:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:17:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:17:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:17:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:17:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:17:01 --> Total execution time: 0.2429
DEBUG - 2023-08-07 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:18:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:18:52 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:18:52 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:18:52 --> Total execution time: 0.2907
DEBUG - 2023-08-07 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:18:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:18:52 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:18:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:18:52 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:18:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:18:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:18:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:18:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:18:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:18:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:18:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:18:54 --> Total execution time: 0.1587
DEBUG - 2023-08-07 04:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:18:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:18:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:18:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:18:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:18:54 --> Total execution time: 0.2465
DEBUG - 2023-08-07 04:20:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:20:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:20:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:20:14 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:20:14 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:20:14 --> Total execution time: 0.2763
DEBUG - 2023-08-07 04:20:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:20:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:20:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:20:14 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:20:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:20:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:20:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:20:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:20:14 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:20:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:20:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:20:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:20:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:20:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:20:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:20:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:20:15 --> Total execution time: 0.1656
DEBUG - 2023-08-07 04:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:20:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:20:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:20:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:20:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:20:15 --> Total execution time: 0.2633
DEBUG - 2023-08-07 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:21:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:21:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:21:55 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:21:55 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:21:55 --> Total execution time: 0.2820
DEBUG - 2023-08-07 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:21:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:21:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:21:55 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:21:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:21:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:21:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:21:55 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:21:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:21:56 --> Total execution time: 0.1668
DEBUG - 2023-08-07 04:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:21:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:21:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:21:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:21:56 --> Total execution time: 0.2669
DEBUG - 2023-08-07 04:22:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:22:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:22:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:22:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:22:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:22:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:22:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:22:26 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:22:26 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:22:26 --> Total execution time: 0.2907
DEBUG - 2023-08-07 04:22:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:22:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:22:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:22:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:22:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:22:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:22:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:22:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:22:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:22:27 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:22:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:22:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:22:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:22:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:22:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:22:27 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:22:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:22:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 11:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:22:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:22:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:22:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:22:28 --> Total execution time: 0.1966
DEBUG - 2023-08-07 04:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:22:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:22:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:22:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:22:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:22:28 --> Total execution time: 0.2834
DEBUG - 2023-08-07 04:23:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:23:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:23:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:23:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:23:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:23:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:23:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:23:55 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:23:55 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:23:55 --> Total execution time: 0.2803
DEBUG - 2023-08-07 04:23:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:23:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:23:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:23:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:23:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:23:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:23:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:23:55 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:23:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:23:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:23:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:23:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:23:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:23:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:23:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:23:56 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:23:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:23:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:23:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:23:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:23:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:23:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:23:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:23:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:23:57 --> Total execution time: 0.1661
DEBUG - 2023-08-07 04:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:23:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:23:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:23:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:23:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:23:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:23:57 --> Total execution time: 0.2487
DEBUG - 2023-08-07 04:24:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:24:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:24:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:24:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:24:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:24:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:24:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:04 --> Total execution time: 0.2384
DEBUG - 2023-08-07 04:24:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:24:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:24:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:24:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:24:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:24:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:24:53 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:24:53 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:24:53 --> Total execution time: 0.2941
DEBUG - 2023-08-07 04:24:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:24:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:24:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:24:54 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:24:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:24:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:24:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:24:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:24:54 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:24:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:24:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:24:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:24:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:24:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:24:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:24:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:24:55 --> Total execution time: 0.1674
DEBUG - 2023-08-07 04:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:24:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:24:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:24:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:24:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:55 --> Total execution time: 0.2403
DEBUG - 2023-08-07 04:24:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:24:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:24:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:24:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:24:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:24:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:24:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:24:58 --> Total execution time: 0.2314
DEBUG - 2023-08-07 04:26:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:26:06 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:26:06 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:26:06 --> Total execution time: 0.2854
DEBUG - 2023-08-07 04:26:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:26:06 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:26:06 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:26:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:07 --> Total execution time: 0.1660
DEBUG - 2023-08-07 04:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:07 --> Total execution time: 0.2443
DEBUG - 2023-08-07 04:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:10 --> Total execution time: 0.2302
DEBUG - 2023-08-07 04:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:15 --> Total execution time: 0.2113
DEBUG - 2023-08-07 04:26:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:23 --> Total execution time: 0.5142
DEBUG - 2023-08-07 04:26:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:26:23 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:26:23 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:26:23 --> Total execution time: 0.2808
DEBUG - 2023-08-07 04:26:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:26:24 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:26:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:26:24 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:26:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:25 --> Total execution time: 0.1662
DEBUG - 2023-08-07 04:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:25 --> Total execution time: 0.2447
DEBUG - 2023-08-07 04:26:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:26:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:26:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:26:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:26:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:26:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:26:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:26:39 --> Total execution time: 0.2297
DEBUG - 2023-08-07 04:27:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:27:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:27:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:27:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:27:16 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:27:16 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:27:16 --> Total execution time: 0.2768
DEBUG - 2023-08-07 04:27:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:27:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:27:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:27:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:27:16 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:27:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:27:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:27:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:27:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:27:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:27:16 --> 404 Page Not Found: 
DEBUG - 2023-08-07 04:27:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:27:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:27:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:27:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:27:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:27:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:27:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:27:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:27:17 --> Total execution time: 0.1667
DEBUG - 2023-08-07 04:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:27:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:27:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:27:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:27:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:27:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:17 --> Total execution time: 0.2424
DEBUG - 2023-08-07 04:27:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:27:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:27:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:27:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:27:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:27:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:27:20 --> Total execution time: 0.2348
DEBUG - 2023-08-07 04:28:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:28:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:28:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:28:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:28:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:28:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:28:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:28:19 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:28:19 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:28:19 --> Total execution time: 0.2911
DEBUG - 2023-08-07 04:28:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:28:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:28:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:28:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:28:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:28:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:28:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:28:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:28:20 --> Total execution time: 0.1981
DEBUG - 2023-08-07 04:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:28:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:28:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:28:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:28:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:28:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:20 --> Total execution time: 0.2834
DEBUG - 2023-08-07 04:28:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:28:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:28:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:28:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:28:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:28:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:24 --> Total execution time: 0.2703
DEBUG - 2023-08-07 04:28:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:28:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:28:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:28:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:28:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:28:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:28:45 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:28:45 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:28:45 --> Total execution time: 0.2992
DEBUG - 2023-08-07 04:28:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:28:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:28:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:28:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:28:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:28:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:28:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:28:46 --> Total execution time: 0.1634
DEBUG - 2023-08-07 04:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:28:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:28:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:28:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:28:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:47 --> Total execution time: 0.2396
DEBUG - 2023-08-07 04:28:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:28:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:28:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:28:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:28:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:28:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:28:49 --> Total execution time: 0.2303
DEBUG - 2023-08-07 04:29:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:29:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:29:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:29:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:29:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:29:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:29:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:29:37 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:29:37 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:29:37 --> Total execution time: 0.2921
DEBUG - 2023-08-07 04:29:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:29:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:29:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:29:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:29:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:29:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:29:39 --> Total execution time: 0.1747
DEBUG - 2023-08-07 04:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:29:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:29:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:29:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:29:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:39 --> Total execution time: 0.2832
DEBUG - 2023-08-07 04:29:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:29:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:29:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:29:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:29:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:29:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:29:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:42 --> Total execution time: 0.2481
DEBUG - 2023-08-07 04:29:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:29:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:29:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:29:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:29:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:29:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:29:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:29:42 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:29:42 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:29:42 --> Total execution time: 0.2725
DEBUG - 2023-08-07 04:29:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:29:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:29:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:29:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:29:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:29:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:29:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:29:43 --> Total execution time: 0.1650
DEBUG - 2023-08-07 04:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:29:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:29:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:29:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:29:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:44 --> Total execution time: 0.2599
DEBUG - 2023-08-07 04:29:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:29:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:29:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:29:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:29:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:29:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:29:47 --> Total execution time: 0.2474
DEBUG - 2023-08-07 04:30:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:15 --> Total execution time: 0.2084
DEBUG - 2023-08-07 04:30:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:18 --> Total execution time: 0.1881
DEBUG - 2023-08-07 04:30:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:22 --> Total execution time: 0.2404
DEBUG - 2023-08-07 04:30:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:22 --> Total execution time: 0.2542
DEBUG - 2023-08-07 04:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:24 --> Total execution time: 0.2273
DEBUG - 2023-08-07 04:30:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:28 --> Total execution time: 0.2143
DEBUG - 2023-08-07 04:30:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:30:32 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:30:32 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:30:32 --> Total execution time: 0.2733
DEBUG - 2023-08-07 04:30:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:33 --> Total execution time: 0.1690
DEBUG - 2023-08-07 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:33 --> Total execution time: 0.2429
DEBUG - 2023-08-07 04:30:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:35 --> Total execution time: 0.2257
DEBUG - 2023-08-07 04:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:30:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:30:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:30:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:30:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:30:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:30:42 --> Total execution time: 0.9016
DEBUG - 2023-08-07 04:34:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:34:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:34:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:34:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:34:16 --> Total execution time: 0.2539
DEBUG - 2023-08-07 04:34:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:34:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:34:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:34:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:36:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:36:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:36:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:36:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:36:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:36:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:36:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:36:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:36:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:37:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:37:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:37:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:37:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:37:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:37:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:37:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:37:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:37:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:37:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:37:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:37:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:37:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:37:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:37:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:37:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:37:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '! 6
AND `contact_identity_number` = '33782323254242'' at line 5 - Invalid query: SELECT *
FROM `contacts`
WHERE `contact_type` = 3
AND `contact_branch_id` = 1
AND contact_id ! 6
AND `contact_identity_number` = '33782323254242'
DEBUG - 2023-08-07 04:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:38:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:38:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:38:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:38:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:38:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:38:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:38:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:38:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:38:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:39:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:39:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:40:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:40:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:40:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:40:00 --> Total execution time: 0.2014
DEBUG - 2023-08-07 04:41:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:41:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:41:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:41:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:41:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:41:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:41:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:41:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:41:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:41:10 --> Total execution time: 0.2227
DEBUG - 2023-08-07 04:41:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:41:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:41:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:41:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:41:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:41:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:41:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:41:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:41:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:41:39 --> Total execution time: 0.2076
DEBUG - 2023-08-07 04:42:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:42:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:42:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:42:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:42:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:42:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 04:42:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:42:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:42:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:42:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:42:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:42:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:20 --> Total execution time: 0.1946
DEBUG - 2023-08-07 04:42:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:42:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:32 --> Total execution time: 0.2782
DEBUG - 2023-08-07 04:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:32 --> Total execution time: 0.2434
DEBUG - 2023-08-07 04:42:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:42:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:42:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:42:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:42:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:42:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:42:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:42:39 --> Total execution time: 0.2274
DEBUG - 2023-08-07 04:43:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:43:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:43:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:43:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:43:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:43:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:04 --> Total execution time: 0.1932
DEBUG - 2023-08-07 04:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:43:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:43:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:43:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:43:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:19 --> Total execution time: 0.1951
DEBUG - 2023-08-07 04:43:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:43:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:43:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:43:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:43:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:43:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:24 --> Total execution time: 0.2699
DEBUG - 2023-08-07 04:43:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:43:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:43:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:43:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:43:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:43:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:43:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:43:25 --> Total execution time: 0.2474
DEBUG - 2023-08-07 04:46:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:46:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:46:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:46:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:46:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:46:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:46:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:46:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:46:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:46:06 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:46:06 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:46:06 --> Total execution time: 0.3191
DEBUG - 2023-08-07 04:46:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:46:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:46:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:46:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:46:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:46:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:46:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:46:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:46:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:46:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:46:07 --> Total execution time: 0.1901
DEBUG - 2023-08-07 04:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:46:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:46:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:46:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:46:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:46:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:46:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:46:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:46:07 --> Total execution time: 0.2595
DEBUG - 2023-08-07 04:54:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:54:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:54:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:54:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:54:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:54:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:54:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:54:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:54:28 --> Total execution time: 0.4067
DEBUG - 2023-08-07 04:55:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:55:28 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
ERROR - 2023-08-07 11:55:28 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
DEBUG - 2023-08-07 11:55:28 --> Total execution time: 0.2889
DEBUG - 2023-08-07 04:55:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:29 --> Total execution time: 0.1665
DEBUG - 2023-08-07 04:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:29 --> Total execution time: 0.2235
DEBUG - 2023-08-07 04:55:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:31 --> Total execution time: 0.2285
DEBUG - 2023-08-07 04:55:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:55:36 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\customer.php 278
ERROR - 2023-08-07 11:55:36 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\customer.php 278
DEBUG - 2023-08-07 11:55:37 --> Total execution time: 0.3471
DEBUG - 2023-08-07 04:55:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:37 --> Total execution time: 0.1642
DEBUG - 2023-08-07 04:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:38 --> Total execution time: 0.2407
DEBUG - 2023-08-07 04:55:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:40 --> Total execution time: 0.2223
DEBUG - 2023-08-07 04:55:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-07 11:55:41 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
ERROR - 2023-08-07 11:55:41 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\employee.php 247
DEBUG - 2023-08-07 11:55:41 --> Total execution time: 0.2952
DEBUG - 2023-08-07 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:42 --> Total execution time: 0.1712
DEBUG - 2023-08-07 04:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:42 --> Total execution time: 0.2485
DEBUG - 2023-08-07 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:43 --> PHPMailer class is loaded.
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 175
ERROR - 2023-08-07 11:55:43 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 175
DEBUG - 2023-08-07 11:55:43 --> Total execution time: 0.4399
DEBUG - 2023-08-07 04:55:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 04:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 04:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 04:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:44 --> Total execution time: 0.1742
DEBUG - 2023-08-07 04:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 04:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 11:55:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 11:55:44 --> Total execution time: 0.2330
DEBUG - 2023-08-07 08:07:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 08:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 08:07:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 08:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 08:08:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 15:08:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 15:08:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 15:08:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 15:08:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 15:08:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 08:08:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-07 08:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-07 08:08:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-07 08:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-07 08:08:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 15:08:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 15:08:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-07 15:08:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-07 15:08:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-07 15:08:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-07 15:08:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 15:08:06 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-07 15:08:06 --> Total execution time: 0.2058
