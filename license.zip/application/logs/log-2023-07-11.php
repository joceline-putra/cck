<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-07-11 06:07:26 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 06:07:26 --> No URI present. Default controller set.
DEBUG - 2023-07-11 06:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 06:07:26 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-11 06:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-11 06:07:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-11 06:07:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp326\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp326\www\git\jrn\system\core\Common.php 578
ERROR - 2023-07-11 06:07:27 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp326\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
ERROR - 2023-07-11 06:08:19 --> Severity: User Error --> Composer detected issues in your platform: Your Composer dependencies require a PHP version ">= 7.3.0". You are running 7.0.33. C:\Wamp326\www\git\jrn\vendor\composer\platform_check.php 24
ERROR - 2023-07-11 06:08:20 --> Severity: User Error --> Composer detected issues in your platform: Your Composer dependencies require a PHP version ">= 7.3.0". You are running 7.0.33. C:\Wamp326\www\git\jrn\vendor\composer\platform_check.php 24
ERROR - 2023-07-11 06:08:22 --> Severity: User Error --> Composer detected issues in your platform: Your Composer dependencies require a PHP version ">= 7.3.0". You are running 7.0.33. C:\Wamp326\www\git\jrn\vendor\composer\platform_check.php 24
ERROR - 2023-07-11 06:08:22 --> Severity: User Error --> Composer detected issues in your platform: Your Composer dependencies require a PHP version ">= 7.3.0". You are running 7.0.33. C:\Wamp326\www\git\jrn\vendor\composer\platform_check.php 24
DEBUG - 2023-07-11 06:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 06:09:47 --> No URI present. Default controller set.
DEBUG - 2023-07-11 06:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 06:09:47 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-11 06:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-11 06:09:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:09:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:09:49 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/email.php
DEBUG - 2023-07-11 13:09:49 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-11 13:09:49 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-11 13:09:49 --> PHPMailer class is loaded.
DEBUG - 2023-07-11 13:09:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:09:50 --> Phpmailer_lib class already loaded. Second attempt ignored.
ERROR - 2023-07-11 13:09:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp326\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp326\www\git\jrn\application\views\layouts\admin\login\login.php 4
ERROR - 2023-07-11 13:09:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp326\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp326\www\git\jrn\application\views\layouts\admin\login\login.php 5
DEBUG - 2023-07-11 13:09:50 --> Total execution time: 3.3512
DEBUG - 2023-07-11 06:09:51 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 06:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 06:09:51 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-11 06:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-11 06:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:09:51 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/email.php
DEBUG - 2023-07-11 13:09:51 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-11 13:09:51 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-11 13:09:51 --> PHPMailer class is loaded.
DEBUG - 2023-07-11 13:09:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-11 13:09:52 --> 404 Page Not Found: 
DEBUG - 2023-07-11 06:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 06:31:02 --> No URI present. Default controller set.
DEBUG - 2023-07-11 06:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 06:31:02 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-11 06:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-11 06:31:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:31:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:31:02 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/email.php
DEBUG - 2023-07-11 13:31:02 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-11 13:31:02 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-11 13:31:02 --> PHPMailer class is loaded.
DEBUG - 2023-07-11 13:31:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:31:02 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:31:02 --> Total execution time: 0.1979
DEBUG - 2023-07-11 06:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 06:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 06:31:03 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/pagination.php
DEBUG - 2023-07-11 06:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-07-11 06:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-11 13:31:03 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/email.php
DEBUG - 2023-07-11 13:31:03 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-07-11 13:31:03 --> Config file loaded: C:\Wamp326\www\git\jrn\application\config/firebase.php
DEBUG - 2023-07-11 13:31:03 --> PHPMailer class is loaded.
DEBUG - 2023-07-11 13:31:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-07-11 13:31:03 --> 404 Page Not Found: 
