<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-20 07:48:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:10 --> No URI present. Default controller set.
DEBUG - 2023-09-20 07:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:32 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:33 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:33 --> Total execution time: 23.9778
DEBUG - 2023-09-20 07:48:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:40 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:40 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:40 --> Total execution time: 1.0256
DEBUG - 2023-09-20 07:48:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:41 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:42 --> Total execution time: 1.4941
DEBUG - 2023-09-20 07:48:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 14:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 07:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 14:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:43 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 14:48:43 --> Total execution time: 0.6118
DEBUG - 2023-09-20 07:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 07:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 14:48:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 07:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:44 --> Total execution time: 0.6561
DEBUG - 2023-09-20 07:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 07:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 14:48:44 --> Total execution time: 1.2151
DEBUG - 2023-09-20 07:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 14:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 07:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:44 --> Total execution time: 1.1626
DEBUG - 2023-09-20 07:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:44 --> Total execution time: 1.2182
DEBUG - 2023-09-20 07:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 07:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 14:48:44 --> Total execution time: 1.2975
DEBUG - 2023-09-20 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:45 --> Total execution time: 0.6776
DEBUG - 2023-09-20 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:45 --> Total execution time: 0.5108
DEBUG - 2023-09-20 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:45 --> Total execution time: 0.6723
DEBUG - 2023-09-20 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:45 --> Total execution time: 1.5719
DEBUG - 2023-09-20 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:45 --> Total execution time: 1.5667
DEBUG - 2023-09-20 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:45 --> Total execution time: 0.9842
DEBUG - 2023-09-20 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 14:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 14:48:45 --> Total execution time: 0.4592
DEBUG - 2023-09-20 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 14:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:45 --> Total execution time: 0.4624
DEBUG - 2023-09-20 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:45 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:46 --> Total execution time: 0.5098
DEBUG - 2023-09-20 07:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:46 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 07:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:46 --> Total execution time: 0.4891
DEBUG - 2023-09-20 07:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 07:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 14:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:46 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:46 --> Total execution time: 0.4822
DEBUG - 2023-09-20 07:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:46 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 07:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 14:48:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:46 --> Total execution time: 0.7277
DEBUG - 2023-09-20 07:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:48:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:48:46 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:48:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:48:46 --> Total execution time: 0.8795
DEBUG - 2023-09-20 07:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:49:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:49:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:49:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:49:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:49:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:49:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:49:24 --> PHPMailer class is loaded.
ERROR - 2023-09-20 14:49:25 --> Severity: Notice --> Undefined variable: user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 635
ERROR - 2023-09-20 14:49:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 635
ERROR - 2023-09-20 14:49:25 --> Severity: Notice --> Undefined variable: menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 652
ERROR - 2023-09-20 14:49:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 652
DEBUG - 2023-09-20 14:49:25 --> Total execution time: 1.0548
DEBUG - 2023-09-20 07:49:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:49:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:49:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:49:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:49:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:49:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:49:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:49:26 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:49:26 --> Total execution time: 0.1892
DEBUG - 2023-09-20 07:49:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:49:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:49:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:49:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:49:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:49:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:49:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:49:27 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 14:49:27 --> Total execution time: 0.2712
DEBUG - 2023-09-20 07:50:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 07:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 07:50:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 07:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 07:50:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:50:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:50:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 14:50:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 14:50:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 14:50:10 --> PHPMailer class is loaded.
ERROR - 2023-09-20 14:50:10 --> Query error: Unknown column 'ug.user_group_names' in 'field list' - Invalid query: SELECT `u`.`user_id`, `u`.`user_type`, `u`.`user_code`, `u`.`user_activation_code`, `u`.`user_username`, `u`.`user_fullname`, `u`.`user_email_1`, `u`.`user_phone_1`, `u`.`user_flag`, `ug`.`user_group_names`, `b`.*, fn_time_ago(u.user_date_last_login) AS time_ago
FROM `users` AS `u`
LEFT JOIN `users_groups` AS `ug` ON `u`.`user_user_group_id`=`ug`.`user_group_id`
LEFT JOIN `branchs` AS `b` ON `u`.`user_branch_id`=`b`.`branch_id`
WHERE `user_branch_id` >0
AND   (
`user_username` LIKE '%asa%' ESCAPE '!'
OR  `user_fullname` LIKE '%asa%' ESCAPE '!'
 )
ORDER BY `user_username` ASC
 LIMIT 10
DEBUG - 2023-09-20 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 08:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 08:16:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 08:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 08:16:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:16:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:16:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 15:16:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 15:16:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 15:16:43 --> PHPMailer class is loaded.
ERROR - 2023-09-20 15:16:43 --> Severity: Notice --> Undefined variable: user C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 635
ERROR - 2023-09-20 15:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 635
ERROR - 2023-09-20 15:16:43 --> Severity: Notice --> Undefined variable: menu C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 652
ERROR - 2023-09-20 15:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\user.php 652
DEBUG - 2023-09-20 15:16:43 --> Total execution time: 0.2592
DEBUG - 2023-09-20 08:16:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 08:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 08:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 08:16:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 08:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 08:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-20 08:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 08:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 15:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 15:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 15:16:44 --> PHPMailer class is loaded.
DEBUG - 2023-09-20 15:16:44 --> Total execution time: 0.2006
DEBUG - 2023-09-20 08:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-20 08:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-20 15:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-20 15:16:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-20 15:16:44 --> PHPMailer class is loaded.
ERROR - 2023-09-20 15:16:44 --> Query error: Unknown column 'ug.user_group_names' in 'field list' - Invalid query: SELECT `u`.`user_id`, `u`.`user_type`, `u`.`user_code`, `u`.`user_activation_code`, `u`.`user_username`, `u`.`user_fullname`, `u`.`user_email_1`, `u`.`user_phone_1`, `u`.`user_flag`, `ug`.`user_group_names`, `b`.*, fn_time_ago(u.user_date_last_login) AS time_ago
FROM `users` AS `u`
LEFT JOIN `users_groups` AS `ug` ON `u`.`user_user_group_id`=`ug`.`user_group_id`
LEFT JOIN `branchs` AS `b` ON `u`.`user_branch_id`=`b`.`branch_id`
WHERE `user_branch_id` >0
ORDER BY `user_username` ASC
 LIMIT 10
