<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-19 03:57:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:11 --> No URI present. Default controller set.
DEBUG - 2023-08-19 03:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:31 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:32 --> Total execution time: 21.9641
DEBUG - 2023-08-19 03:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:35 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:35 --> Total execution time: 0.8167
DEBUG - 2023-08-19 03:57:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:36 --> Total execution time: 0.8977
DEBUG - 2023-08-19 03:57:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 03:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:38 --> Total execution time: 0.5551
DEBUG - 2023-08-19 03:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:38 --> Total execution time: 0.4606
DEBUG - 2023-08-19 03:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:38 --> Total execution time: 0.7438
DEBUG - 2023-08-19 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.2396
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.3428
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.3292
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.4092
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.4698
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.5133
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.2760
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.2711
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.2473
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.2605
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.2491
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.2509
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.2545
DEBUG - 2023-08-19 03:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:39 --> Total execution time: 0.2638
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 03:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 03:57:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 03:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 10:57:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:40 --> Total execution time: 0.7098
DEBUG - 2023-08-19 03:57:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 10:57:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 10:57:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 10:57:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 10:57:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:57:40 --> Total execution time: 0.7185
DEBUG - 2023-08-19 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:44 --> Total execution time: 0.2429
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:02:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.1967
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.1960
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.2667
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.2179
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.2490
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.2202
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.2877
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.3784
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.2655
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.2378
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.2390
DEBUG - 2023-08-19 04:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:45 --> Total execution time: 0.2566
DEBUG - 2023-08-19 04:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:46 --> Total execution time: 0.2506
DEBUG - 2023-08-19 04:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:02:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:46 --> Total execution time: 0.2499
DEBUG - 2023-08-19 04:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:46 --> Total execution time: 0.2503
DEBUG - 2023-08-19 04:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:46 --> Total execution time: 0.2448
DEBUG - 2023-08-19 04:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:02:46 --> Total execution time: 0.2546
DEBUG - 2023-08-19 04:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:02:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Total execution time: 0.2547
DEBUG - 2023-08-19 04:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:02:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:02:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:02:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:02:46 --> Total execution time: 0.2606
DEBUG - 2023-08-19 04:03:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:22 --> Total execution time: 0.2169
DEBUG - 2023-08-19 04:03:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:03:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.1934
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.1641
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.1828
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.2073
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.2205
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.2550
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.3785
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.3474
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.4699
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.3395
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.3532
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.3207
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:03:23 --> Total execution time: 0.3075
DEBUG - 2023-08-19 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:03:24 --> Total execution time: 0.2573
DEBUG - 2023-08-19 04:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:03:24 --> Total execution time: 0.2813
DEBUG - 2023-08-19 04:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:03:24 --> Total execution time: 0.2450
DEBUG - 2023-08-19 04:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:03:24 --> Total execution time: 0.2520
DEBUG - 2023-08-19 04:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:03:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Total execution time: 0.2589
DEBUG - 2023-08-19 04:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:03:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:03:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:03:24 --> Total execution time: 0.2688
DEBUG - 2023-08-19 04:07:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:14 --> Total execution time: 0.2184
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Total execution time: 0.2088
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:15 --> Total execution time: 0.1665
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:15 --> Total execution time: 0.1872
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:15 --> Total execution time: 0.1964
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:15 --> Total execution time: 0.2385
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:15 --> Total execution time: 0.2579
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:15 --> Total execution time: 0.3038
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:15 --> Total execution time: 0.3005
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:15 --> Total execution time: 0.3316
DEBUG - 2023-08-19 04:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.3195
DEBUG - 2023-08-19 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.3101
DEBUG - 2023-08-19 04:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.3182
DEBUG - 2023-08-19 04:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.3226
DEBUG - 2023-08-19 04:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.3233
DEBUG - 2023-08-19 04:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.3134
DEBUG - 2023-08-19 04:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.2508
DEBUG - 2023-08-19 04:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.2575
DEBUG - 2023-08-19 04:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.2592
DEBUG - 2023-08-19 04:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:16 --> Total execution time: 0.2652
DEBUG - 2023-08-19 04:07:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:53 --> Total execution time: 0.2389
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Total execution time: 0.1956
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:55 --> Total execution time: 0.1636
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:55 --> Total execution time: 0.2295
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:55 --> Total execution time: 0.2143
DEBUG - 2023-08-19 04:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:55 --> Total execution time: 0.2651
DEBUG - 2023-08-19 04:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:55 --> Total execution time: 0.3132
DEBUG - 2023-08-19 04:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:55 --> Total execution time: 0.2883
DEBUG - 2023-08-19 04:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:55 --> Total execution time: 0.3773
DEBUG - 2023-08-19 04:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2794
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2391
DEBUG - 2023-08-19 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2367
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2289
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2360
DEBUG - 2023-08-19 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2392
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2388
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2437
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2445
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2514
DEBUG - 2023-08-19 04:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:07:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:07:56 --> Total execution time: 0.2529
DEBUG - 2023-08-19 04:08:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:08:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:49 --> Total execution time: 0.2256
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:08:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.1962
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2315
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2398
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2006
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2331
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2737
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.3304
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2478
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2495
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2440
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2417
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2444
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:08:51 --> Total execution time: 0.2432
DEBUG - 2023-08-19 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:08:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:08:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:08:52 --> Total execution time: 0.2407
DEBUG - 2023-08-19 04:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:08:52 --> Total execution time: 0.2502
DEBUG - 2023-08-19 04:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:08:52 --> Total execution time: 0.2488
DEBUG - 2023-08-19 04:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:08:52 --> Total execution time: 0.2527
DEBUG - 2023-08-19 04:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:08:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Total execution time: 0.2510
DEBUG - 2023-08-19 04:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:08:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:08:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:08:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:08:52 --> Total execution time: 0.2500
DEBUG - 2023-08-19 04:10:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:10:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:10:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:13 --> Total execution time: 0.2326
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:10:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2040
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2185
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2389
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2163
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2542
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2848
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.3049
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2882
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2831
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2463
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2491
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2526
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2570
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2582
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:15 --> Total execution time: 0.2643
DEBUG - 2023-08-19 04:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:16 --> Total execution time: 0.2711
DEBUG - 2023-08-19 04:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:10:16 --> Total execution time: 0.2730
DEBUG - 2023-08-19 04:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:10:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:16 --> Total execution time: 0.2691
DEBUG - 2023-08-19 04:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:10:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:16 --> Total execution time: 0.2788
DEBUG - 2023-08-19 04:10:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:10:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:10:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:10:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:10:53 --> Total execution time: 3.1370
DEBUG - 2023-08-19 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:10:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:10:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=10488 C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=10488 C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=10488 C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Unable to connect to the database
ERROR - 2023-08-19 04:11:04 --> Unable to connect to the database
ERROR - 2023-08-19 04:11:04 --> Unable to connect to the database
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=10488 C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
DEBUG - 2023-08-19 04:11:04 --> UTF-8 Support Enabled
ERROR - 2023-08-19 04:11:04 --> Unable to connect to the database
DEBUG - 2023-08-19 04:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:11:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:11:04 --> UTF-8 Support Enabled
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=10488 C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Unable to connect to the database
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=10488 C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-19 04:11:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
DEBUG - 2023-08-19 04:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:11:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:11:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-08-19 04:11:04 --> Unable to connect to the database
DEBUG - 2023-08-19 04:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:11:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:11:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:11:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:11:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:11:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:13:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:13:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:38 --> Total execution time: 0.2445
DEBUG - 2023-08-19 04:13:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:13:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2115
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.1822
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2005
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.1908
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2483
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2505
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2539
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.3474
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2933
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2460
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2465
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2468
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2498
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2484
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2434
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2440
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:13:40 --> Total execution time: 0.2458
DEBUG - 2023-08-19 04:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:13:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:41 --> Total execution time: 0.2505
DEBUG - 2023-08-19 04:13:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:13:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:13:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:13:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:13:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:13:41 --> Total execution time: 0.2525
DEBUG - 2023-08-19 04:15:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:15:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:25 --> Total execution time: 0.2409
DEBUG - 2023-08-19 04:15:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:15:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:26 --> Total execution time: 0.1972
DEBUG - 2023-08-19 04:15:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.1663
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.1954
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.1895
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.1920
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2402
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.3036
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2786
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.3321
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2689
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2339
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2470
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2442
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2479
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2462
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2472
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2455
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:15:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2489
DEBUG - 2023-08-19 04:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:15:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:15:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:15:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:15:27 --> Total execution time: 0.2527
DEBUG - 2023-08-19 04:16:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:10 --> Total execution time: 1.0458
DEBUG - 2023-08-19 04:16:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Total execution time: 2.7765
DEBUG - 2023-08-19 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:14 --> Total execution time: 2.7276
DEBUG - 2023-08-19 04:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:16:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:16:14 --> Total execution time: 2.7631
DEBUG - 2023-08-19 04:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:14 --> Total execution time: 2.7787
DEBUG - 2023-08-19 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:14 --> Total execution time: 2.8374
DEBUG - 2023-08-19 04:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:16:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:15 --> Total execution time: 2.8980
DEBUG - 2023-08-19 04:16:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:18 --> Total execution time: 3.4736
DEBUG - 2023-08-19 04:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:16:18 --> Total execution time: 3.4476
DEBUG - 2023-08-19 04:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:16:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:16:18 --> Total execution time: 3.4658
DEBUG - 2023-08-19 04:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:16:18 --> Total execution time: 3.4023
DEBUG - 2023-08-19 04:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:16:18 --> Total execution time: 3.3749
DEBUG - 2023-08-19 04:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:16:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:16:18 --> Total execution time: 3.3590
DEBUG - 2023-08-19 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:16:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:19 --> Total execution time: 1.6495
DEBUG - 2023-08-19 04:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:16:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:19 --> Total execution time: 1.6696
DEBUG - 2023-08-19 04:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:16:19 --> Total execution time: 1.6673
DEBUG - 2023-08-19 04:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:16:20 --> Total execution time: 1.6718
DEBUG - 2023-08-19 04:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:20 --> Total execution time: 1.6745
DEBUG - 2023-08-19 04:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:20 --> Total execution time: 1.6743
DEBUG - 2023-08-19 04:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:16:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:16:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:16:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:16:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:16:20 --> Total execution time: 0.5182
DEBUG - 2023-08-19 04:18:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:50 --> Total execution time: 0.2300
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Total execution time: 0.1992
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:52 --> Total execution time: 0.1608
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:18:52 --> Total execution time: 0.2232
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:52 --> Total execution time: 0.1884
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:18:52 --> Total execution time: 0.1847
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:18:52 --> Total execution time: 0.3055
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:18:52 --> Total execution time: 0.3298
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:18:52 --> Total execution time: 0.3945
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:18:52 --> Total execution time: 0.3317
DEBUG - 2023-08-19 04:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.2398
DEBUG - 2023-08-19 04:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.2742
DEBUG - 2023-08-19 04:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:18:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:18:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.2670
DEBUG - 2023-08-19 04:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:18:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:18:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.3031
DEBUG - 2023-08-19 04:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:18:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.3312
DEBUG - 2023-08-19 04:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.3093
DEBUG - 2023-08-19 04:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.3299
DEBUG - 2023-08-19 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.3181
DEBUG - 2023-08-19 04:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.3255
DEBUG - 2023-08-19 04:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:18:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:18:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:18:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:18:53 --> Total execution time: 0.2968
DEBUG - 2023-08-19 04:19:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:47 --> Total execution time: 0.2280
DEBUG - 2023-08-19 04:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:19:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:19:48 --> Total execution time: 0.2087
DEBUG - 2023-08-19 04:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.1894
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.1889
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2169
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2439
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2883
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.3051
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.3642
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.4642
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2812
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2766
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2515
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2414
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2429
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2546
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2579
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2576
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:19:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2751
DEBUG - 2023-08-19 04:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:19:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:19:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:19:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:19:49 --> Total execution time: 0.2876
DEBUG - 2023-08-19 04:20:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:20:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:24 --> Total execution time: 0.2147
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:20:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.2120
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.1817
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.2449
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.2335
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.2776
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.3446
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.3305
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.3474
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.2816
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.2497
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:20:26 --> Total execution time: 0.2583
DEBUG - 2023-08-19 04:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:20:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:20:27 --> Total execution time: 0.2556
DEBUG - 2023-08-19 04:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:20:27 --> Total execution time: 0.2556
DEBUG - 2023-08-19 04:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:20:27 --> Total execution time: 0.2578
DEBUG - 2023-08-19 04:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:20:27 --> Total execution time: 0.2510
DEBUG - 2023-08-19 04:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:20:27 --> Total execution time: 0.2453
DEBUG - 2023-08-19 04:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:20:27 --> Total execution time: 0.2467
DEBUG - 2023-08-19 04:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:20:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Total execution time: 0.2455
DEBUG - 2023-08-19 04:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:20:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:27 --> Total execution time: 0.2492
DEBUG - 2023-08-19 04:20:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:20:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:39 --> Total execution time: 0.4828
DEBUG - 2023-08-19 04:20:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:20:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:20:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:20:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:20:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:20:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:20:40 --> Total execution time: 0.1872
DEBUG - 2023-08-19 04:21:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:34 --> Total execution time: 0.2407
DEBUG - 2023-08-19 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:21:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:35 --> Total execution time: 0.1903
DEBUG - 2023-08-19 04:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:21:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:21:35 --> Total execution time: 0.1672
DEBUG - 2023-08-19 04:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:21:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:21:35 --> Total execution time: 0.2373
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.1960
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2533
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2841
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.3424
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.3504
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2987
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2336
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2660
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2717
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2731
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2809
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2698
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2634
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2480
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:21:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2601
DEBUG - 2023-08-19 04:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:21:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:21:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:21:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:21:36 --> Total execution time: 0.2699
DEBUG - 2023-08-19 04:33:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:01 --> Total execution time: 0.2397
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:33:02 --> Total execution time: 0.2295
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:33:02 --> Total execution time: 0.1623
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:02 --> Total execution time: 0.2608
DEBUG - 2023-08-19 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:02 --> Total execution time: 0.2012
DEBUG - 2023-08-19 04:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:02 --> Total execution time: 0.2753
DEBUG - 2023-08-19 04:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:33:02 --> Total execution time: 0.3140
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:03 --> Total execution time: 0.3204
DEBUG - 2023-08-19 04:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:03 --> Total execution time: 0.3082
DEBUG - 2023-08-19 04:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:03 --> Total execution time: 0.2041
DEBUG - 2023-08-19 04:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:03 --> Total execution time: 0.2877
DEBUG - 2023-08-19 04:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:33:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:03 --> Total execution time: 0.2196
DEBUG - 2023-08-19 04:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:03 --> Total execution time: 0.2926
DEBUG - 2023-08-19 04:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:03 --> Total execution time: 0.2565
DEBUG - 2023-08-19 04:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:03 --> Total execution time: 0.2612
DEBUG - 2023-08-19 04:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:03 --> Total execution time: 0.2649
DEBUG - 2023-08-19 04:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:04 --> Total execution time: 0.9896
DEBUG - 2023-08-19 04:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:04 --> Total execution time: 0.9914
DEBUG - 2023-08-19 04:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:04 --> Total execution time: 0.9668
DEBUG - 2023-08-19 04:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:04 --> Total execution time: 1.0599
DEBUG - 2023-08-19 04:33:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:36 --> Total execution time: 0.2150
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Total execution time: 0.1898
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:37 --> Total execution time: 0.1775
DEBUG - 2023-08-19 04:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:33:37 --> Total execution time: 0.2030
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:37 --> Total execution time: 0.1873
DEBUG - 2023-08-19 04:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:37 --> Total execution time: 0.2239
DEBUG - 2023-08-19 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.3628
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.2798
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.4856
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.4647
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.3879
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.3861
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.4334
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.4573
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.3685
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.3626
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.3224
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.3254
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:33:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.2522
DEBUG - 2023-08-19 04:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:33:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:33:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:33:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:33:38 --> Total execution time: 0.2795
DEBUG - 2023-08-19 04:34:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:06 --> Total execution time: 0.2291
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Total execution time: 0.1906
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:07 --> Total execution time: 0.1638
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:07 --> Total execution time: 0.1872
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:07 --> Total execution time: 0.2227
DEBUG - 2023-08-19 04:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:07 --> Total execution time: 0.2853
DEBUG - 2023-08-19 04:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:07 --> Total execution time: 0.3325
DEBUG - 2023-08-19 04:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:07 --> Total execution time: 0.3589
DEBUG - 2023-08-19 04:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:34:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:07 --> Total execution time: 0.3593
DEBUG - 2023-08-19 04:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:07 --> Total execution time: 0.3532
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:34:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2635
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2713
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2747
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2718
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2698
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2610
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2586
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2580
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2544
DEBUG - 2023-08-19 04:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:08 --> Total execution time: 0.2662
DEBUG - 2023-08-19 04:34:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:44 --> Total execution time: 0.2224
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.1901
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.1686
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.2086
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.1978
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.2615
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.3204
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.3358
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.3233
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.3455
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.2925
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.2775
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:46 --> Total execution time: 0.2734
DEBUG - 2023-08-19 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:47 --> Total execution time: 0.2774
DEBUG - 2023-08-19 04:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:34:47 --> Total execution time: 0.2740
DEBUG - 2023-08-19 04:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:47 --> Total execution time: 0.2461
DEBUG - 2023-08-19 04:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:34:47 --> Total execution time: 0.2445
DEBUG - 2023-08-19 04:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:47 --> Total execution time: 0.2445
DEBUG - 2023-08-19 04:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Total execution time: 0.2493
DEBUG - 2023-08-19 04:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:34:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:34:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:34:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:34:47 --> Total execution time: 0.2465
DEBUG - 2023-08-19 04:36:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:36:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:43 --> Total execution time: 0.2270
DEBUG - 2023-08-19 04:36:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:36:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.1938
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.1888
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2402
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2040
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2728
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.3245
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.3846
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.3480
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.3572
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2774
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2978
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2913
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2688
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2473
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2589
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:36:45 --> Total execution time: 0.2635
DEBUG - 2023-08-19 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 11:36:46 --> Total execution time: 0.2621
DEBUG - 2023-08-19 04:36:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:36:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:46 --> Total execution time: 0.2696
DEBUG - 2023-08-19 04:36:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:36:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:36:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:36:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:36:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:36:46 --> Total execution time: 0.2993
DEBUG - 2023-08-19 04:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 04:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 04:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 04:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 04:38:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:38:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 11:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 11:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 11:38:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 11:38:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 11:38:49 --> Total execution time: 0.2118
ERROR - 2023-08-19 06:11:18 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
ERROR - 2023-08-19 06:11:18 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
ERROR - 2023-08-19 06:11:18 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
ERROR - 2023-08-19 06:11:18 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
ERROR - 2023-08-19 06:11:19 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
ERROR - 2023-08-19 06:11:19 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
ERROR - 2023-08-19 06:11:26 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\Wamp\www\git\jrn\system\core\Common.php 604
DEBUG - 2023-08-19 06:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:38:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:38:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:33 --> Total execution time: 6.6128
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:38:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Total execution time: 0.1948
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:34 --> Total execution time: 0.1736
DEBUG - 2023-08-19 06:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:38:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:38:34 --> Total execution time: 0.1901
DEBUG - 2023-08-19 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:34 --> Total execution time: 0.2048
DEBUG - 2023-08-19 06:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:38:34 --> Total execution time: 0.2524
DEBUG - 2023-08-19 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:34 --> Total execution time: 0.3007
DEBUG - 2023-08-19 06:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:38:34 --> Total execution time: 0.2801
DEBUG - 2023-08-19 06:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.3536
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.3005
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2502
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2387
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2438
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2444
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2459
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2447
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2429
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2351
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:38:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2440
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:38:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.2461
DEBUG - 2023-08-19 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:38:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:38:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:38:35 --> Total execution time: 0.1884
DEBUG - 2023-08-19 06:39:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:21 --> Total execution time: 0.2403
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:39:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.1891
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.1960
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2174
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.1878
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2136
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2410
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2648
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2370
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2243
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2631
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2606
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2734
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2707
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2738
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2828
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:22 --> Total execution time: 0.2556
DEBUG - 2023-08-19 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:23 --> Total execution time: 0.2548
DEBUG - 2023-08-19 06:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:39:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:23 --> Total execution time: 0.2568
DEBUG - 2023-08-19 06:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:39:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:23 --> Total execution time: 0.2607
DEBUG - 2023-08-19 06:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:39:23 --> Total execution time: 0.1936
DEBUG - 2023-08-19 06:39:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:39:40 --> Total execution time: 0.5758
DEBUG - 2023-08-19 06:39:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:39:41 --> Total execution time: 0.1605
DEBUG - 2023-08-19 06:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:39:41 --> Total execution time: 0.2245
DEBUG - 2023-08-19 06:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:39:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:39:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:39:41 --> Total execution time: 0.2120
DEBUG - 2023-08-19 06:40:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:40:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:40:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:40:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:40:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:40:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:40:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:40:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:40:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:40:09 --> Total execution time: 0.1889
DEBUG - 2023-08-19 06:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:40:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:40:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:40:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:40:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:40:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:40:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:40:12 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:40:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:40:12 --> Total execution time: 0.2605
DEBUG - 2023-08-19 06:40:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:40:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:40:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:40:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:40:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:40:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:40:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:40:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:40:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:40:55 --> Total execution time: 0.2462
DEBUG - 2023-08-19 06:41:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:41:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:41:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:41:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:41:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:41:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:41:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:41:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:41:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:41:13 --> Total execution time: 0.2747
DEBUG - 2023-08-19 06:41:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:41:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:41:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:41:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:41:37 --> Total execution time: 0.2543
DEBUG - 2023-08-19 06:43:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:43:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:43:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:43:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:43:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:43:04 --> Total execution time: 0.2288
DEBUG - 2023-08-19 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 06:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:43:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:43:06 --> Total execution time: 0.1665
DEBUG - 2023-08-19 06:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:43:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:43:06 --> Total execution time: 0.2252
DEBUG - 2023-08-19 06:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:43:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:43:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:43:06 --> Total execution time: 0.2038
DEBUG - 2023-08-19 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:43:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:43:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:43:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:43:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:43:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:43:10 --> Total execution time: 0.2153
DEBUG - 2023-08-19 06:43:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:43:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:43:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:43:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:43:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:43:11 --> Total execution time: 0.1632
DEBUG - 2023-08-19 06:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:43:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:43:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:43:11 --> Total execution time: 0.2254
DEBUG - 2023-08-19 06:43:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:43:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:43:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:43:11 --> Total execution time: 0.1946
DEBUG - 2023-08-19 06:43:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:43:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:43:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:43:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:43:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:43:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:43:13 --> Total execution time: 0.2398
DEBUG - 2023-08-19 06:44:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:44:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:44:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:44:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:44:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:44:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:44:38 --> Total execution time: 0.2521
DEBUG - 2023-08-19 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:44:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:44:39 --> Total execution time: 0.1731
DEBUG - 2023-08-19 06:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:44:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:44:39 --> Total execution time: 0.2223
DEBUG - 2023-08-19 06:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:44:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:44:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:44:39 --> Total execution time: 0.2012
DEBUG - 2023-08-19 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:44:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:44:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:44:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:44:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:44:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:44:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:44:41 --> Total execution time: 0.3204
DEBUG - 2023-08-19 06:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:45:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:45:41 --> Total execution time: 0.2355
DEBUG - 2023-08-19 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:45:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:45:43 --> Total execution time: 0.1559
DEBUG - 2023-08-19 06:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:45:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:45:43 --> Total execution time: 0.2209
DEBUG - 2023-08-19 06:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:45:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:45:43 --> Total execution time: 0.2115
DEBUG - 2023-08-19 06:47:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:47:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:47:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:47:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:47:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:47:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:47:07 --> Total execution time: 0.2476
DEBUG - 2023-08-19 06:47:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:47:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:47:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:47:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:47:09 --> Total execution time: 0.1725
DEBUG - 2023-08-19 06:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:47:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:47:09 --> Total execution time: 0.2494
DEBUG - 2023-08-19 06:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:47:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:47:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:47:09 --> Total execution time: 0.2371
DEBUG - 2023-08-19 06:48:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:48:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:48:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:48:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:48:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:48:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:48:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:48:14 --> Total execution time: 0.3169
DEBUG - 2023-08-19 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:53:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:39 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:40 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:40 --> Total execution time: 0.1710
DEBUG - 2023-08-19 06:53:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:53:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:50 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:50 --> Total execution time: 0.6260
DEBUG - 2023-08-19 06:53:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:50 --> Total execution time: 0.2237
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:53:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.1879
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.1669
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2165
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.1888
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2135
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2597
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2645
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.3349
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2887
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2770
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2739
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2653
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2546
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2399
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:52 --> Total execution time: 0.2371
DEBUG - 2023-08-19 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:53 --> Total execution time: 0.2357
DEBUG - 2023-08-19 06:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:53:53 --> Total execution time: 0.2355
DEBUG - 2023-08-19 06:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:53:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:53 --> Total execution time: 0.2430
DEBUG - 2023-08-19 06:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:53:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:53:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:53:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:53:53 --> Total execution time: 0.2499
DEBUG - 2023-08-19 06:54:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:46 --> Total execution time: 0.2141
DEBUG - 2023-08-19 06:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:54:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:47 --> Total execution time: 0.1896
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.1657
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.1863
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.1881
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2506
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2870
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.3035
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.3204
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.3235
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2790
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2402
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2458
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2524
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2434
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2494
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2527
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2550
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:54:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2637
DEBUG - 2023-08-19 06:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:54:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:54:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:54:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:54:48 --> Total execution time: 0.2663
DEBUG - 2023-08-19 06:55:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:55:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:55:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:55:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:55:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:55:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:55:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:55:21 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:55:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:55:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:55:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:55:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:55:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:55:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:55:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:55:21 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:55:21 --> Total execution time: 0.1572
DEBUG - 2023-08-19 06:56:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:56:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:56:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:56:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:56:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:56:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:56:29 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:56:29 --> Total execution time: 0.1720
DEBUG - 2023-08-19 06:58:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:58:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:58:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:58:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:58:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:58:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:58:25 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:58:25 --> Total execution time: 0.1591
DEBUG - 2023-08-19 06:58:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:58:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:58:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:58:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:58:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:58:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:58:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:58:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:58:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:58:36 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:58:36 --> Total execution time: 0.1652
DEBUG - 2023-08-19 06:59:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:59:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:59:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:59:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:59:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:59:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:59:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:08 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:08 --> Total execution time: 0.1620
DEBUG - 2023-08-19 06:59:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:59:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:59:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:59:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:59:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:59:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:18 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:18 --> Total execution time: 0.1680
DEBUG - 2023-08-19 06:59:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 06:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 06:59:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 06:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 06:59:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 13:59:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 13:59:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 13:59:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 13:59:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:39 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 13:59:39 --> Total execution time: 0.1627
DEBUG - 2023-08-19 07:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:02:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:21 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:21 --> Total execution time: 0.1752
DEBUG - 2023-08-19 07:02:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:02:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:24 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:25 --> Total execution time: 0.6100
DEBUG - 2023-08-19 07:02:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:02:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:25 --> Total execution time: 0.2175
DEBUG - 2023-08-19 07:02:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 07:02:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 14:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 07:02:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:02:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:02:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 07:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:25 --> Total execution time: 0.2756
DEBUG - 2023-08-19 07:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2213
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2592
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2357
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2871
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.3106
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.3106
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.3305
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.3107
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2911
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2990
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2882
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2682
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2559
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2382
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2686
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2696
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:02:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2884
DEBUG - 2023-08-19 07:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:02:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:02:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:02:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:02:26 --> Total execution time: 0.2900
DEBUG - 2023-08-19 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:03:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:03:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:03:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-19 14:03:36 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
ERROR - 2023-08-19 14:03:36 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\unit.php 208
DEBUG - 2023-08-19 14:03:36 --> Total execution time: 0.9776
DEBUG - 2023-08-19 07:03:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:03:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:03:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:03:37 --> Total execution time: 0.1648
DEBUG - 2023-08-19 07:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:03:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:03:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:03:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:37 --> Total execution time: 0.2170
DEBUG - 2023-08-19 07:03:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:03:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:03:46 --> PHPMailer class is loaded.
ERROR - 2023-08-19 14:03:46 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
ERROR - 2023-08-19 14:03:46 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
DEBUG - 2023-08-19 14:03:46 --> Total execution time: 0.2818
DEBUG - 2023-08-19 07:03:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:03:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:03:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:03:46 --> Total execution time: 0.1642
DEBUG - 2023-08-19 07:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:03:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:03:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:03:46 --> Total execution time: 0.2141
DEBUG - 2023-08-19 07:06:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:06:54 --> PHPMailer class is loaded.
ERROR - 2023-08-19 14:06:55 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
ERROR - 2023-08-19 14:06:55 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
DEBUG - 2023-08-19 14:06:55 --> Total execution time: 0.1862
DEBUG - 2023-08-19 07:06:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:06:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:06:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:06:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:06:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:06:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:06:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:06:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:06:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:06:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:06:55 --> Total execution time: 0.1605
DEBUG - 2023-08-19 07:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:06:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:06:56 --> Total execution time: 0.2196
DEBUG - 2023-08-19 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:07:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:07:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:07:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:07:49 --> PHPMailer class is loaded.
ERROR - 2023-08-19 14:07:49 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
ERROR - 2023-08-19 14:07:49 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
DEBUG - 2023-08-19 14:07:49 --> Total execution time: 0.1979
DEBUG - 2023-08-19 07:07:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:07:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:07:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:07:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:07:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:07:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:07:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:07:50 --> Total execution time: 0.1608
DEBUG - 2023-08-19 07:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:07:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:07:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:07:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:07:50 --> Total execution time: 0.2169
DEBUG - 2023-08-19 07:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:07:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:07:55 --> PHPMailer class is loaded.
ERROR - 2023-08-19 14:07:55 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
ERROR - 2023-08-19 14:07:55 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\reference\room.php 214
DEBUG - 2023-08-19 14:07:55 --> Total execution time: 0.1958
DEBUG - 2023-08-19 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:07:56 --> Total execution time: 0.1562
DEBUG - 2023-08-19 07:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:07:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:07:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:07:56 --> Total execution time: 0.2150
DEBUG - 2023-08-19 07:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:07:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:07:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:07:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:07:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:07:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:07:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:58 --> Total execution time: 0.7228
DEBUG - 2023-08-19 07:07:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:07:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:07:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:07:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:07:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:07:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:07:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:07:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:07:58 --> Total execution time: 0.1612
DEBUG - 2023-08-19 07:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:07:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:07:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:07:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:07:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:07:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:07:58 --> Total execution time: 0.2283
DEBUG - 2023-08-19 07:08:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-19 14:08:29 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
ERROR - 2023-08-19 14:08:29 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\supplier.php 262
DEBUG - 2023-08-19 14:08:29 --> Total execution time: 0.6153
DEBUG - 2023-08-19 07:08:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:29 --> Total execution time: 0.1645
DEBUG - 2023-08-19 07:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:29 --> Total execution time: 0.2149
DEBUG - 2023-08-19 07:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:31 --> PHPMailer class is loaded.
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:31 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:32 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:32 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:32 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:32 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 144
ERROR - 2023-08-19 14:08:32 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 175
ERROR - 2023-08-19 14:08:32 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\contact\category_contact.php 175
DEBUG - 2023-08-19 14:08:32 --> Total execution time: 0.3613
DEBUG - 2023-08-19 07:08:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:32 --> Total execution time: 0.1615
DEBUG - 2023-08-19 07:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:32 --> Total execution time: 0.2197
DEBUG - 2023-08-19 07:08:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:44 --> Total execution time: 0.4503
DEBUG - 2023-08-19 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:44 --> Total execution time: 0.1624
DEBUG - 2023-08-19 07:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 07:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:08:44 --> Total execution time: 0.1897
DEBUG - 2023-08-19 07:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:44 --> Total execution time: 0.2234
DEBUG - 2023-08-19 07:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:44 --> Total execution time: 0.2829
DEBUG - 2023-08-19 07:08:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:56 --> Total execution time: 0.3323
DEBUG - 2023-08-19 07:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:08:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:08:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:08:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:08:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:08:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:08:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:08:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:00 --> Total execution time: 0.5017
DEBUG - 2023-08-19 07:09:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:09:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:09:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:09:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:09:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:09:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:09:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:09:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:09:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:09:01 --> Total execution time: 0.1578
DEBUG - 2023-08-19 07:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:09:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:09:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 07:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:09:01 --> Total execution time: 0.2810
DEBUG - 2023-08-19 07:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:09:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:09:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Total execution time: 0.3433
DEBUG - 2023-08-19 07:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:09:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:09:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:09:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:09:01 --> Total execution time: 0.4393
DEBUG - 2023-08-19 07:15:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:15:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:15:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:15:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:15:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:15:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:39 --> Total execution time: 0.3473
DEBUG - 2023-08-19 07:15:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:15:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:15:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:15:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 07:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 14:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:15:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:15:41 --> Total execution time: 0.2165
DEBUG - 2023-08-19 07:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:15:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:15:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 07:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:15:41 --> Total execution time: 0.2231
DEBUG - 2023-08-19 07:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 07:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:15:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:15:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:41 --> Total execution time: 0.2519
DEBUG - 2023-08-19 07:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:15:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:15:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:15:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:15:41 --> Total execution time: 0.3477
DEBUG - 2023-08-19 07:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:22:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:22:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:22:49 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:22:49 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:22:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:49 --> Total execution time: 0.3323
DEBUG - 2023-08-19 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 07:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 07:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 07:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:22:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:22:50 --> Total execution time: 0.1839
DEBUG - 2023-08-19 07:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:22:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:22:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 07:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 07:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 14:22:50 --> Total execution time: 0.2173
DEBUG - 2023-08-19 07:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:22:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:22:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:50 --> Total execution time: 0.2512
DEBUG - 2023-08-19 07:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 14:22:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 14:22:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 14:22:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:22:51 --> Total execution time: 0.3471
DEBUG - 2023-08-19 08:14:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:14:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:14:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:14:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:14:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:14:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:14:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:14:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:14:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:14:59 --> Total execution time: 0.4456
DEBUG - 2023-08-19 08:15:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:15:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:15:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:15:02 --> Total execution time: 0.2057
DEBUG - 2023-08-19 08:15:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:15:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:15:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:15:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:15:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:15:03 --> Total execution time: 0.6531
DEBUG - 2023-08-19 08:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:15:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:03 --> Total execution time: 0.6151
DEBUG - 2023-08-19 08:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:15:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:15:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:15:03 --> Total execution time: 0.7994
DEBUG - 2023-08-19 08:25:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:25:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:25:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:25:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:25:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:25:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:29 --> Total execution time: 0.3433
DEBUG - 2023-08-19 08:25:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:25:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:25:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:25:30 --> Total execution time: 0.1648
DEBUG - 2023-08-19 08:25:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:25:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:25:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:25:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:25:31 --> Total execution time: 0.2212
DEBUG - 2023-08-19 08:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:25:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:31 --> Total execution time: 0.2520
DEBUG - 2023-08-19 08:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:25:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:25:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:25:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:25:31 --> Total execution time: 0.3325
DEBUG - 2023-08-19 08:26:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:26:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:08 --> Total execution time: 0.3242
DEBUG - 2023-08-19 08:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:10 --> Total execution time: 0.1659
DEBUG - 2023-08-19 08:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:26:10 --> Total execution time: 0.2182
DEBUG - 2023-08-19 08:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:11 --> Total execution time: 0.2636
DEBUG - 2023-08-19 08:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:11 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:11 --> Total execution time: 0.3568
DEBUG - 2023-08-19 08:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:26:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:13 --> Total execution time: 0.3282
DEBUG - 2023-08-19 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:15 --> Total execution time: 0.1665
DEBUG - 2023-08-19 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:26:15 --> Total execution time: 0.2198
DEBUG - 2023-08-19 08:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Total execution time: 0.2635
DEBUG - 2023-08-19 08:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:26:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:26:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:26:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:26:15 --> Total execution time: 0.3578
DEBUG - 2023-08-19 08:28:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:28:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:28:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:28:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:28:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:28:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:28:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:05 --> Total execution time: 0.3576
DEBUG - 2023-08-19 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:28:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:28:07 --> Total execution time: 0.1598
DEBUG - 2023-08-19 08:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:28:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:28:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:28:07 --> Total execution time: 0.2161
DEBUG - 2023-08-19 08:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:28:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:28:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Total execution time: 0.2558
DEBUG - 2023-08-19 08:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:28:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:28:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:28:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:28:07 --> Total execution time: 0.3475
DEBUG - 2023-08-19 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:29:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:29:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:29:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:29:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:29:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:56 --> Total execution time: 0.3421
DEBUG - 2023-08-19 08:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:29:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:29:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 15:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:29:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:29:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:29:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:29:57 --> Total execution time: 0.1703
DEBUG - 2023-08-19 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:29:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:29:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:58 --> Total execution time: 0.2138
DEBUG - 2023-08-19 08:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:29:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:29:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:29:58 --> Total execution time: 0.2178
DEBUG - 2023-08-19 08:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:29:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:29:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:29:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:29:58 --> Total execution time: 0.3000
DEBUG - 2023-08-19 08:30:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:30:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:30:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:30:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:30:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:17 --> Total execution time: 0.3200
DEBUG - 2023-08-19 08:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:30:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 08:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 15:30:17 --> Total execution time: 0.1619
DEBUG - 2023-08-19 08:30:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:30:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:30:18 --> Total execution time: 0.2201
DEBUG - 2023-08-19 08:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:30:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:18 --> Total execution time: 0.2726
DEBUG - 2023-08-19 08:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:30:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:30:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:30:18 --> Total execution time: 0.3436
DEBUG - 2023-08-19 08:31:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:31:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:31:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:31:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:31:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:31:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:31:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:44 --> Total execution time: 0.3254
DEBUG - 2023-08-19 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 15:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 08:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:31:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 15:31:45 --> Total execution time: 0.1689
DEBUG - 2023-08-19 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:31:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:31:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:45 --> Total execution time: 0.2165
DEBUG - 2023-08-19 08:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:31:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:31:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:45 --> Total execution time: 0.2255
DEBUG - 2023-08-19 08:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:31:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:31:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:31:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:31:45 --> Total execution time: 0.3481
DEBUG - 2023-08-19 08:32:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:22 --> Total execution time: 0.3372
DEBUG - 2023-08-19 08:32:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:23 --> Total execution time: 0.1844
DEBUG - 2023-08-19 08:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:32:23 --> Total execution time: 0.2723
DEBUG - 2023-08-19 08:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Total execution time: 0.3011
DEBUG - 2023-08-19 08:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:23 --> Total execution time: 0.3726
DEBUG - 2023-08-19 08:32:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:32:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:40 --> Total execution time: 0.3395
DEBUG - 2023-08-19 08:32:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:41 --> Total execution time: 0.1633
DEBUG - 2023-08-19 08:32:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:41 --> Total execution time: 0.2156
DEBUG - 2023-08-19 08:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:42 --> Total execution time: 0.2699
DEBUG - 2023-08-19 08:32:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:32:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:32:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:32:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:32:42 --> Total execution time: 0.3178
DEBUG - 2023-08-19 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:33:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:33:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:33:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:33:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:05 --> Total execution time: 0.3319
DEBUG - 2023-08-19 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 15:33:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 15:33:06 --> Total execution time: 0.1835
DEBUG - 2023-08-19 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:33:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:33:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Total execution time: 0.2116
DEBUG - 2023-08-19 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:33:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:33:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Total execution time: 0.2225
DEBUG - 2023-08-19 08:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:33:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:33:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:06 --> Total execution time: 0.3061
DEBUG - 2023-08-19 08:33:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:33:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:33:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:33:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:33:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:44 --> Total execution time: 0.3241
DEBUG - 2023-08-19 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 08:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-19 08:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:33:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:33:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:33:45 --> Total execution time: 0.1910
DEBUG - 2023-08-19 08:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:33:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:33:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:33:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 08:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 08:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-19 15:33:45 --> Total execution time: 0.2147
DEBUG - 2023-08-19 08:33:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:33:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:33:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Total execution time: 0.2479
DEBUG - 2023-08-19 08:33:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-19 15:33:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-19 15:33:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-19 15:33:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:33:45 --> Total execution time: 0.3395
