<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-12 01:36:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:36:13 --> No URI present. Default controller set.
DEBUG - 2023-08-12 01:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:36:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:36:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:36:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:36:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:36:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:13 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:13 --> Total execution time: 0.2155
DEBUG - 2023-08-12 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:36:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:36:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:36:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:36:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:36:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:36:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:16 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:17 --> Total execution time: 0.6418
DEBUG - 2023-08-12 01:36:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:36:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:36:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:36:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:36:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:36:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:36:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:36:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-12 08:36:17 --> Query error: FUNCTION banj5733_jrn.fn_time_ago does not exist - Invalid query: SELECT `u`.`user_id`, `u`.`user_type`, `u`.`user_code`, `u`.`user_activation_code`, `u`.`user_username`, `u`.`user_fullname`, `u`.`user_email_1`, `u`.`user_phone_1`, `u`.`user_flag`, `ug`.`user_group_name`, `b`.*, fn_time_ago(u.user_date_last_login) AS time_ago
FROM `users` AS `u`
LEFT JOIN `users_groups` AS `ug` ON `u`.`user_user_group_id`=`ug`.`user_group_id`
LEFT JOIN `branchs` AS `b` ON `u`.`user_branch_id`=`b`.`branch_id`
WHERE `user_branch_id` = '1'
ORDER BY `user_username` ASC
DEBUG - 2023-08-12 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:26 --> Total execution time: 0.2483
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:38:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.2232
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.1672
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.1982
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.2101
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.3082
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.3104
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.4034
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.4143
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.3837
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.2720
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.2642
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.2627
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.2803
DEBUG - 2023-08-12 01:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 01:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:38:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:38:27 --> Total execution time: 0.2942
DEBUG - 2023-08-12 01:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:38:28 --> Total execution time: 0.3119
DEBUG - 2023-08-12 01:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:38:28 --> Total execution time: 0.3224
DEBUG - 2023-08-12 01:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:38:28 --> Total execution time: 0.3081
DEBUG - 2023-08-12 01:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Total execution time: 0.3235
DEBUG - 2023-08-12 01:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:38:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:38:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:38:28 --> Total execution time: 0.3068
DEBUG - 2023-08-12 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:21 --> Total execution time: 0.3469
DEBUG - 2023-08-12 01:41:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:22 --> Total execution time: 0.1878
DEBUG - 2023-08-12 01:41:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:35 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:35 --> Total execution time: 0.3208
DEBUG - 2023-08-12 01:41:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:36 --> Total execution time: 0.5121
DEBUG - 2023-08-12 01:41:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:37 --> Total execution time: 0.1597
DEBUG - 2023-08-12 01:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:41:37 --> Total execution time: 0.2262
DEBUG - 2023-08-12 01:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Total execution time: 0.2942
DEBUG - 2023-08-12 01:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:37 --> Total execution time: 0.3731
DEBUG - 2023-08-12 01:41:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:40 --> Total execution time: 0.1875
DEBUG - 2023-08-12 01:41:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:42 --> Total execution time: 0.1921
DEBUG - 2023-08-12 01:41:45 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:45 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Total execution time: 0.5245
DEBUG - 2023-08-12 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Total execution time: 0.3022
DEBUG - 2023-08-12 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:41:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:41:46 --> Total execution time: 0.2030
DEBUG - 2023-08-12 01:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 01:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:46 --> Total execution time: 0.1621
DEBUG - 2023-08-12 01:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:46 --> Total execution time: 0.1980
DEBUG - 2023-08-12 01:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:41:47 --> Total execution time: 0.1889
DEBUG - 2023-08-12 01:41:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:47 --> Total execution time: 0.2298
DEBUG - 2023-08-12 01:41:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:50 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:50 --> Total execution time: 0.3980
DEBUG - 2023-08-12 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:51 --> Total execution time: 0.1612
DEBUG - 2023-08-12 01:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:41:51 --> Total execution time: 0.2165
DEBUG - 2023-08-12 01:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:51 --> Total execution time: 0.2210
DEBUG - 2023-08-12 01:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:53 --> Total execution time: 0.2505
DEBUG - 2023-08-12 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:53 --> Total execution time: 0.2777
DEBUG - 2023-08-12 01:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:53 --> Total execution time: 0.3254
DEBUG - 2023-08-12 01:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:53 --> Total execution time: 0.3752
DEBUG - 2023-08-12 01:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:41:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:41:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:41:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:41:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:41:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:41:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:41:58 --> Total execution time: 0.2359
DEBUG - 2023-08-12 01:42:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:00 --> Total execution time: 0.1895
DEBUG - 2023-08-12 01:42:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:03 --> Total execution time: 0.3107
DEBUG - 2023-08-12 01:42:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:04 --> Total execution time: 0.8096
DEBUG - 2023-08-12 01:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Total execution time: 0.2108
DEBUG - 2023-08-12 01:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Total execution time: 0.1894
DEBUG - 2023-08-12 01:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 01:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:14 --> Total execution time: 0.1603
DEBUG - 2023-08-12 01:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:14 --> Total execution time: 0.1968
DEBUG - 2023-08-12 01:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:14 --> Total execution time: 0.1963
DEBUG - 2023-08-12 01:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:14 --> Total execution time: 0.2446
DEBUG - 2023-08-12 01:42:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:20 --> Total execution time: 0.1942
DEBUG - 2023-08-12 01:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:21 --> Total execution time: 0.1873
DEBUG - 2023-08-12 01:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:26 --> Total execution time: 0.1820
DEBUG - 2023-08-12 01:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:30 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:30 --> Total execution time: 0.5439
DEBUG - 2023-08-12 01:42:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:30 --> Total execution time: 0.2168
DEBUG - 2023-08-12 01:42:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:31 --> Total execution time: 0.1918
DEBUG - 2023-08-12 01:42:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.1635
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.1941
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.1831
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2142
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2474
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2905
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.3431
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.3017
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2361
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2356
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2355
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2439
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2688
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2779
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2811
DEBUG - 2023-08-12 01:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2899
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2965
DEBUG - 2023-08-12 01:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:32 --> Total execution time: 0.2914
DEBUG - 2023-08-12 01:42:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:53 --> Total execution time: 0.3214
DEBUG - 2023-08-12 01:42:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:42:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:42:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:42:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:42:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:42:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:42:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:42:56 --> Total execution time: 0.2912
DEBUG - 2023-08-12 01:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:43:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:08 --> Total execution time: 0.2878
DEBUG - 2023-08-12 01:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:43:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:17 --> Total execution time: 0.2301
DEBUG - 2023-08-12 01:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:43:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.1887
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2000
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2242
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2581
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2339
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.3428
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.3859
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.3281
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.3368
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2464
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2501
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2482
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2531
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2557
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2495
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2543
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2555
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:43:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Total execution time: 0.2628
DEBUG - 2023-08-12 01:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:43:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:19 --> Total execution time: 0.2651
DEBUG - 2023-08-12 01:43:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:43:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:43:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:43:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:43:22 --> Total execution time: 0.3138
DEBUG - 2023-08-12 01:45:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:22 --> Total execution time: 0.3251
DEBUG - 2023-08-12 01:45:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:37 --> Total execution time: 0.9874
DEBUG - 2023-08-12 01:45:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Total execution time: 2.4360
DEBUG - 2023-08-12 01:45:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:45:40 --> Total execution time: 2.3848
DEBUG - 2023-08-12 01:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:45:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:40 --> Total execution time: 2.4626
DEBUG - 2023-08-12 01:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:45:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:45:40 --> Total execution time: 2.4107
DEBUG - 2023-08-12 01:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:45:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:40 --> Total execution time: 2.4884
DEBUG - 2023-08-12 01:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:45:41 --> Total execution time: 2.5593
DEBUG - 2023-08-12 01:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:41 --> Total execution time: 1.2545
DEBUG - 2023-08-12 01:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:42 --> Total execution time: 1.2389
DEBUG - 2023-08-12 01:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:45:42 --> Total execution time: 1.2353
DEBUG - 2023-08-12 01:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 01:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:45:42 --> Total execution time: 1.2469
DEBUG - 2023-08-12 01:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:45:42 --> Total execution time: 1.1952
DEBUG - 2023-08-12 01:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:45:42 --> Total execution time: 1.1673
DEBUG - 2023-08-12 01:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:42 --> Total execution time: 1.0100
DEBUG - 2023-08-12 01:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:45:43 --> Total execution time: 1.0283
DEBUG - 2023-08-12 01:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:45:43 --> Total execution time: 1.0321
DEBUG - 2023-08-12 01:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 01:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:43 --> Total execution time: 1.1218
DEBUG - 2023-08-12 01:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:43 --> Total execution time: 1.1367
DEBUG - 2023-08-12 01:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 01:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Total execution time: 1.1477
DEBUG - 2023-08-12 01:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:43 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:43 --> Total execution time: 0.4335
DEBUG - 2023-08-12 01:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:45:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:45:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:45:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:45:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:45:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:45:47 --> Total execution time: 0.3676
DEBUG - 2023-08-12 01:46:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:55 --> Total execution time: 0.2162
DEBUG - 2023-08-12 01:46:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:46:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:46:56 --> Total execution time: 0.1905
DEBUG - 2023-08-12 01:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.1637
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2322
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.1875
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2084
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2400
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.3040
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2738
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2511
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.3566
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2160
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2794
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2637
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2842
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2774
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.2827
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:46:57 --> Total execution time: 0.3940
DEBUG - 2023-08-12 01:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:57 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:57 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:58 --> Total execution time: 0.2865
DEBUG - 2023-08-12 01:46:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:46:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:46:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:46:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:46:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:46:58 --> Total execution time: 0.3583
DEBUG - 2023-08-12 01:52:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:52:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-08-12 01:52:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-12 01:52:12 --> Unable to connect to the database
DEBUG - 2023-08-12 01:52:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:52:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-08-12 01:52:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-12 01:52:24 --> Unable to connect to the database
DEBUG - 2023-08-12 01:52:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:52:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-08-12 01:52:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-12 01:52:42 --> Unable to connect to the database
DEBUG - 2023-08-12 01:57:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:34 --> Total execution time: 0.2209
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:57:35 --> Total execution time: 0.1927
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:35 --> Total execution time: 0.1660
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 08:57:35 --> Total execution time: 0.2480
DEBUG - 2023-08-12 01:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 01:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:57:35 --> Total execution time: 0.1950
DEBUG - 2023-08-12 01:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:57:35 --> Total execution time: 0.2357
DEBUG - 2023-08-12 01:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:35 --> Total execution time: 0.3016
DEBUG - 2023-08-12 01:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:57:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:35 --> Total execution time: 0.3036
DEBUG - 2023-08-12 01:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:35 --> Total execution time: 0.3403
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:36 --> Total execution time: 0.1893
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:57:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:57:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 08:57:36 --> Total execution time: 0.2793
DEBUG - 2023-08-12 01:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 01:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 08:57:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:36 --> Total execution time: 0.3144
DEBUG - 2023-08-12 01:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:36 --> Total execution time: 0.3290
DEBUG - 2023-08-12 01:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:36 --> Total execution time: 0.3649
DEBUG - 2023-08-12 01:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:36 --> Total execution time: 0.3661
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:36 --> Total execution time: 0.3123
DEBUG - 2023-08-12 01:57:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 01:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 01:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 01:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:57:36 --> Total execution time: 0.2180
DEBUG - 2023-08-12 01:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 01:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-12 08:57:37 --> Total execution time: 0.2621
DEBUG - 2023-08-12 01:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:37 --> Total execution time: 0.2676
DEBUG - 2023-08-12 01:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-12 08:57:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-12 08:57:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-12 08:57:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-12 08:57:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-12 08:57:37 --> Total execution time: 0.2852
