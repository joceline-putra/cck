<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-16 03:48:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:48:39 --> No URI present. Default controller set.
DEBUG - 2023-08-16 03:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:48:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:48:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:48:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:48:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:48:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:48:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:48:42 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:48:42 --> Total execution time: 3.0175
DEBUG - 2023-08-16 03:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:17 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:17 --> Total execution time: 0.8654
DEBUG - 2023-08-16 03:49:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:18 --> Total execution time: 0.2805
DEBUG - 2023-08-16 03:49:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 03:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:28 --> Total execution time: 0.5330
DEBUG - 2023-08-16 03:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:28 --> Total execution time: 0.5376
DEBUG - 2023-08-16 03:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:28 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:28 --> Total execution time: 0.5137
DEBUG - 2023-08-16 03:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:28 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.2269
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.2824
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.3877
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.3995
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.4685
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.5128
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.5050
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.4980
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.4889
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.4877
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.4883
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.4792
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.2348
DEBUG - 2023-08-16 03:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:29 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:29 --> Total execution time: 0.2663
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 03:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 10:49:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 03:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 10:49:30 --> Total execution time: 0.6031
DEBUG - 2023-08-16 03:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 03:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:30 --> Total execution time: 0.6574
DEBUG - 2023-08-16 03:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 03:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:30 --> Total execution time: 0.2110
DEBUG - 2023-08-16 03:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:30 --> Total execution time: 0.2371
DEBUG - 2023-08-16 03:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:30 --> Total execution time: 0.2359
DEBUG - 2023-08-16 03:49:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:54 --> Total execution time: 0.2181
DEBUG - 2023-08-16 03:49:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:49:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:49:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 03:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 10:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 03:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 10:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:55 --> Total execution time: 0.1652
DEBUG - 2023-08-16 03:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:49:55 --> Total execution time: 0.2323
DEBUG - 2023-08-16 03:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:49:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:49:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:49:55 --> Total execution time: 0.2200
DEBUG - 2023-08-16 03:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:51:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:51:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:51:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:51:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:51:14 --> Total execution time: 0.2321
DEBUG - 2023-08-16 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:51:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:51:16 --> Total execution time: 0.1610
DEBUG - 2023-08-16 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:51:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:51:16 --> Total execution time: 0.2260
DEBUG - 2023-08-16 03:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:51:16 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:51:16 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:51:16 --> Total execution time: 0.2143
DEBUG - 2023-08-16 03:51:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:51:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:51:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:51:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:51:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:51:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:51:33 --> Total execution time: 0.2214
DEBUG - 2023-08-16 03:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:51:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:51:34 --> Total execution time: 0.1615
DEBUG - 2023-08-16 03:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:51:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:51:34 --> Total execution time: 0.2256
DEBUG - 2023-08-16 03:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:51:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:51:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:51:34 --> Total execution time: 0.2239
DEBUG - 2023-08-16 03:52:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:52:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:52:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:52:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:52:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:52:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:52:02 --> Total execution time: 0.2225
DEBUG - 2023-08-16 03:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:52:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:52:04 --> Total execution time: 0.1572
DEBUG - 2023-08-16 03:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:52:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:52:04 --> Total execution time: 0.2517
DEBUG - 2023-08-16 03:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:52:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:52:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:52:04 --> Total execution time: 0.2418
DEBUG - 2023-08-16 03:52:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:52:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:52:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:52:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:52:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:52:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:52:35 --> Total execution time: 0.2366
DEBUG - 2023-08-16 03:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 03:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 10:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:52:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:52:37 --> Total execution time: 0.1599
DEBUG - 2023-08-16 03:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:52:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 03:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 10:52:37 --> Total execution time: 0.2269
DEBUG - 2023-08-16 03:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:52:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:52:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:52:37 --> Total execution time: 0.2098
DEBUG - 2023-08-16 03:54:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:54:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:54:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:54:27 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 03:54:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 03:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 03:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 03:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 03:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 10:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 10:54:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 10:54:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 10:54:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:54:27 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:54:27 --> Total execution time: 0.1737
DEBUG - 2023-08-16 04:00:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:00:22 --> No URI present. Default controller set.
DEBUG - 2023-08-16 04:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:00:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:00:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:00:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:00:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:00:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:00:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:00:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:00:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:00:22 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:00:23 --> Total execution time: 0.1729
DEBUG - 2023-08-16 04:01:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:01:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
ERROR - 2023-08-16 04:02:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\Wamp\www\git\jrn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-08-16 04:02:08 --> Unable to connect to the database
DEBUG - 2023-08-16 04:02:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:02:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:02:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:02:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:02:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:02:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:02:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:02:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:02:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:02:30 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:02:30 --> Total execution time: 17.2826
DEBUG - 2023-08-16 04:03:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:23 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:23 --> Total execution time: 0.6544
DEBUG - 2023-08-16 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:23 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:23 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:23 --> Total execution time: 0.2313
DEBUG - 2023-08-16 04:03:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Total execution time: 0.1970
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:25 --> Total execution time: 0.1652
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:25 --> Total execution time: 0.1888
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:25 --> Total execution time: 0.2248
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:25 --> Total execution time: 0.3593
DEBUG - 2023-08-16 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:25 --> Total execution time: 0.3896
DEBUG - 2023-08-16 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:25 --> Total execution time: 0.4633
DEBUG - 2023-08-16 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:25 --> Total execution time: 0.4353
DEBUG - 2023-08-16 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:25 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:25 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.4943
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:03:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.3656
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:03:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.2768
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 04:03:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.2824
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:03:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.2933
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.3009
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.2809
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.2719
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.2668
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.2564
DEBUG - 2023-08-16 04:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:26 --> Total execution time: 0.2606
DEBUG - 2023-08-16 04:03:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:31 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:31 --> Total execution time: 0.2206
DEBUG - 2023-08-16 04:03:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:31 --> Total execution time: 0.2272
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:03:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Total execution time: 0.1901
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:32 --> Total execution time: 0.1722
DEBUG - 2023-08-16 04:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:32 --> Total execution time: 0.2413
DEBUG - 2023-08-16 04:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:32 --> Total execution time: 0.2161
DEBUG - 2023-08-16 04:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:03:32 --> Total execution time: 0.2661
DEBUG - 2023-08-16 04:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:32 --> Total execution time: 0.3162
DEBUG - 2023-08-16 04:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:03:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.3581
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.3297
DEBUG - 2023-08-16 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.2886
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.3118
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.3127
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.3339
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.3332
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.3423
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.2744
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.2753
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.2755
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.2792
DEBUG - 2023-08-16 04:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:33 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:33 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:33 --> Total execution time: 0.2583
DEBUG - 2023-08-16 04:03:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:35 --> Total execution time: 0.2402
DEBUG - 2023-08-16 04:03:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:36 --> Total execution time: 0.1769
DEBUG - 2023-08-16 04:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:03:36 --> Total execution time: 0.2388
DEBUG - 2023-08-16 04:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:36 --> Total execution time: 0.2390
DEBUG - 2023-08-16 04:03:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:03:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:03:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:03:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:03:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:03:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:03:44 --> Total execution time: 0.2383
DEBUG - 2023-08-16 04:05:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:05:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:05:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:05:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:05:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:05:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:05:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:05:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:05:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:05:02 --> Total execution time: 0.2431
DEBUG - 2023-08-16 04:06:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:17 --> Total execution time: 0.2158
DEBUG - 2023-08-16 04:06:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:18 --> Total execution time: 0.1614
DEBUG - 2023-08-16 04:06:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:18 --> Total execution time: 0.2399
DEBUG - 2023-08-16 04:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:18 --> Total execution time: 0.1908
DEBUG - 2023-08-16 04:06:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:24 --> Total execution time: 0.2328
DEBUG - 2023-08-16 04:06:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:54 --> Total execution time: 0.2448
DEBUG - 2023-08-16 04:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:54 --> Total execution time: 0.2305
DEBUG - 2023-08-16 04:06:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:56 --> Total execution time: 0.1619
DEBUG - 2023-08-16 04:06:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:56 --> Total execution time: 0.2188
DEBUG - 2023-08-16 04:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:56 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:56 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:56 --> Total execution time: 0.1867
DEBUG - 2023-08-16 04:06:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:06:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:06:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:06:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:06:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:06:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:06:58 --> Total execution time: 0.2500
DEBUG - 2023-08-16 04:07:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:07:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:07:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:07:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:07:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:07:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:07:46 --> Total execution time: 0.2204
DEBUG - 2023-08-16 04:07:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:07:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:07:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:07:48 --> Total execution time: 0.1645
DEBUG - 2023-08-16 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:07:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:07:48 --> Total execution time: 0.2246
DEBUG - 2023-08-16 04:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:07:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:07:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:07:48 --> Total execution time: 0.1934
DEBUG - 2023-08-16 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:07:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:07:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:07:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:07:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:07:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:07:52 --> Total execution time: 0.2353
DEBUG - 2023-08-16 04:09:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:09:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:09:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:09:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:09:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:09:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:09:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:09:13 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:09:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:09:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:09:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:09:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:09:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:09:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:09:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:09:13 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:09:13 --> Total execution time: 0.1624
DEBUG - 2023-08-16 04:20:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:20:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:20:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:08 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:08 --> Total execution time: 0.6316
DEBUG - 2023-08-16 04:20:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:20:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:20:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:08 --> Total execution time: 0.2243
DEBUG - 2023-08-16 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.1996
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.1772
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2177
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2311
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2941
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2802
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2940
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.3747
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.3338
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2516
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2535
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2608
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2676
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2756
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2749
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2761
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2569
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Total execution time: 0.2512
DEBUG - 2023-08-16 04:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:20:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:20:10 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:20:11 --> Total execution time: 0.2690
DEBUG - 2023-08-16 04:43:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:43:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:43:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:43:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:43:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:43:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:43:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:43:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:43:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:44:00 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
ERROR - 2023-08-16 11:44:00 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
DEBUG - 2023-08-16 11:44:00 --> Total execution time: 0.4534
DEBUG - 2023-08-16 04:44:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:44:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:44:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:44:01 --> Total execution time: 0.1652
DEBUG - 2023-08-16 04:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:44:01 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:44:01 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:44:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:44:01 --> Total execution time: 0.2152
DEBUG - 2023-08-16 04:53:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:53:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:53:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:53:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:53:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:53:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:53:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:53:30 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:53:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:53:30 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
ERROR - 2023-08-16 11:53:30 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
DEBUG - 2023-08-16 11:53:30 --> Total execution time: 0.2030
DEBUG - 2023-08-16 04:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:53:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:53:34 --> Total execution time: 0.1738
DEBUG - 2023-08-16 04:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:53:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:53:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:53:34 --> Total execution time: 0.2209
DEBUG - 2023-08-16 04:54:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:17 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:17 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:54:17 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
ERROR - 2023-08-16 11:54:17 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
DEBUG - 2023-08-16 11:54:17 --> Total execution time: 0.2002
DEBUG - 2023-08-16 04:54:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:18 --> Total execution time: 0.1565
DEBUG - 2023-08-16 04:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:18 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:18 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:18 --> Total execution time: 0.2274
DEBUG - 2023-08-16 04:54:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:54:34 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
ERROR - 2023-08-16 11:54:34 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
DEBUG - 2023-08-16 11:54:34 --> Total execution time: 0.6267
DEBUG - 2023-08-16 04:54:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:35 --> Total execution time: 0.1659
DEBUG - 2023-08-16 04:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:35 --> Total execution time: 0.2153
DEBUG - 2023-08-16 04:54:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:54:38 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\message\device.php 240
ERROR - 2023-08-16 11:54:38 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\message\device.php 240
DEBUG - 2023-08-16 11:54:38 --> Total execution time: 0.4973
DEBUG - 2023-08-16 04:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:38 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:38 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:54:38 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\message\device.php 240
ERROR - 2023-08-16 11:54:38 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\message\device.php 240
DEBUG - 2023-08-16 11:54:38 --> Total execution time: 0.2023
DEBUG - 2023-08-16 04:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Total execution time: 0.3914
DEBUG - 2023-08-16 04:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:54:39 --> Total execution time: 0.5169
DEBUG - 2023-08-16 04:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:54:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:39 --> Total execution time: 0.4146
DEBUG - 2023-08-16 04:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:39 --> Total execution time: 0.2527
DEBUG - 2023-08-16 04:54:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:54:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 04:54:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:54:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 04:54:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:54:40 --> Total execution time: 0.5454
DEBUG - 2023-08-16 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:41 --> Total execution time: 0.1669
DEBUG - 2023-08-16 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Total execution time: 0.2190
DEBUG - 2023-08-16 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:54:41 --> Total execution time: 0.1643
DEBUG - 2023-08-16 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:41 --> Total execution time: 0.1639
DEBUG - 2023-08-16 04:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:54:41 --> Total execution time: 0.2199
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:41 --> Total execution time: 0.2548
DEBUG - 2023-08-16 04:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 04:54:41 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 04:54:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:54:42 --> Total execution time: 0.2766
DEBUG - 2023-08-16 04:54:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:53 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:53 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:54:53 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
ERROR - 2023-08-16 11:54:53 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
DEBUG - 2023-08-16 11:54:53 --> Total execution time: 0.2095
DEBUG - 2023-08-16 04:54:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:54:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:54 --> Total execution time: 0.1679
DEBUG - 2023-08-16 04:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:54:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:54:54 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:54:54 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:54:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:54:54 --> Total execution time: 0.2202
DEBUG - 2023-08-16 04:55:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:55:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:55:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:55:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:55:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:55:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:55:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:55:31 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
ERROR - 2023-08-16 11:55:31 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\branch.php 215
DEBUG - 2023-08-16 11:55:31 --> Total execution time: 0.1924
DEBUG - 2023-08-16 04:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:55:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:55:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:55:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:55:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:55:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:55:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:55:32 --> Total execution time: 0.3928
DEBUG - 2023-08-16 04:55:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:55:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:55:32 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:55:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:55:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:32 --> Total execution time: 0.4283
DEBUG - 2023-08-16 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:55:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:55:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:55:43 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:55:43 --> PHPMailer class is loaded.
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_id" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined array key "product_category_name" C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 96
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 129
ERROR - 2023-08-16 11:55:43 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\article\category_article.php 129
DEBUG - 2023-08-16 11:55:43 --> Total execution time: 1.1310
DEBUG - 2023-08-16 04:55:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:55:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:55:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:55:44 --> Total execution time: 0.7017
DEBUG - 2023-08-16 04:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:55:44 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:55:44 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:55:44 --> Total execution time: 0.7467
DEBUG - 2023-08-16 04:56:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:56:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:56:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:56:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:56:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:56:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:56:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:09 --> Total execution time: 0.2584
DEBUG - 2023-08-16 04:56:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:56:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:56:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:56:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:56:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:56:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:56:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:56:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:56:09 --> Total execution time: 0.1639
DEBUG - 2023-08-16 04:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:56:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:56:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:56:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:56:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:56:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:10 --> Total execution time: 0.2626
DEBUG - 2023-08-16 04:56:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:56:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:56:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:56:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:56:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:56:21 --> Total execution time: 0.5226
DEBUG - 2023-08-16 04:56:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:56:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:56:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:56:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:56:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:56:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:56:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:56:22 --> Total execution time: 0.1611
DEBUG - 2023-08-16 04:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:56:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:56:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:56:22 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:56:22 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:56:22 --> Total execution time: 0.1797
DEBUG - 2023-08-16 04:57:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:57:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:57:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:57:24 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:57:24 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:57:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:57:24 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
ERROR - 2023-08-16 11:57:24 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
ERROR - 2023-08-16 11:57:24 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
DEBUG - 2023-08-16 11:57:24 --> Total execution time: 0.3410
DEBUG - 2023-08-16 04:57:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:57:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:57:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:57:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:57:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:57:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:57:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:57:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:57:26 --> Total execution time: 0.1660
DEBUG - 2023-08-16 04:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:57:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:57:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:57:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:57:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:57:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:26 --> Total execution time: 0.2106
DEBUG - 2023-08-16 04:57:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:57:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:57:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:57:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:57:31 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:57:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:31 --> Total execution time: 0.2192
DEBUG - 2023-08-16 04:57:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:57:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:57:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:57:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:57:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:57:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:57:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:57:51 --> Total execution time: 0.2210
DEBUG - 2023-08-16 04:58:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:13 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:58:13 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
ERROR - 2023-08-16 11:58:13 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
ERROR - 2023-08-16 11:58:13 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
DEBUG - 2023-08-16 11:58:13 --> Total execution time: 0.3628
DEBUG - 2023-08-16 04:58:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:14 --> Total execution time: 0.1603
DEBUG - 2023-08-16 04:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:14 --> Total execution time: 0.2114
DEBUG - 2023-08-16 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:58:39 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\message\device.php 240
ERROR - 2023-08-16 11:58:39 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\message\device.php 240
DEBUG - 2023-08-16 11:58:39 --> Total execution time: 0.2069
DEBUG - 2023-08-16 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:58:39 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\message\device.php 240
ERROR - 2023-08-16 11:58:39 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\message\device.php 240
DEBUG - 2023-08-16 11:58:39 --> Total execution time: 0.1975
DEBUG - 2023-08-16 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:39 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:39 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:39 --> Total execution time: 0.1638
DEBUG - 2023-08-16 04:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:40 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:40 --> Total execution time: 0.2436
DEBUG - 2023-08-16 04:58:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:41 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 04:58:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 04:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:58:42 --> Total execution time: 0.2119
DEBUG - 2023-08-16 04:58:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 04:58:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 04:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:42 --> Total execution time: 0.2845
DEBUG - 2023-08-16 04:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:42 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:42 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:42 --> Total execution time: 0.3148
DEBUG - 2023-08-16 04:58:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:48 --> Total execution time: 0.2128
DEBUG - 2023-08-16 04:58:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:48 --> Total execution time: 0.2111
DEBUG - 2023-08-16 04:58:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:51 --> Total execution time: 0.2126
DEBUG - 2023-08-16 04:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:52 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:52 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:52 --> Total execution time: 0.3991
DEBUG - 2023-08-16 04:58:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:58:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:58:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:58:55 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:58:55 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:58:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:58:55 --> Total execution time: 0.2074
DEBUG - 2023-08-16 04:59:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:00 --> Total execution time: 0.2047
DEBUG - 2023-08-16 04:59:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:00 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:00 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:00 --> Total execution time: 0.2059
DEBUG - 2023-08-16 04:59:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:03 --> Total execution time: 0.2088
DEBUG - 2023-08-16 04:59:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:03 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:03 --> Total execution time: 0.2124
DEBUG - 2023-08-16 04:59:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:06 --> Total execution time: 0.2217
DEBUG - 2023-08-16 04:59:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:06 --> Total execution time: 0.2120
DEBUG - 2023-08-16 04:59:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:14 --> Total execution time: 0.1876
DEBUG - 2023-08-16 04:59:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:15 --> Total execution time: 0.1840
DEBUG - 2023-08-16 04:59:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:19 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:19 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:19 --> Total execution time: 0.5138
DEBUG - 2023-08-16 04:59:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:19 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:20 --> Total execution time: 0.3065
DEBUG - 2023-08-16 04:59:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:20 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:20 --> Total execution time: 0.1898
DEBUG - 2023-08-16 04:59:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:20 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 04:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:59:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 11:59:21 --> Total execution time: 0.1607
DEBUG - 2023-08-16 04:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 04:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:21 --> Total execution time: 0.1948
DEBUG - 2023-08-16 04:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:21 --> Total execution time: 0.1869
DEBUG - 2023-08-16 04:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:21 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:21 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:21 --> Total execution time: 0.2209
DEBUG - 2023-08-16 04:59:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:26 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:26 --> Total execution time: 0.2242
DEBUG - 2023-08-16 04:59:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:27 --> Total execution time: 0.1844
DEBUG - 2023-08-16 04:59:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:27 --> Total execution time: 0.1770
DEBUG - 2023-08-16 04:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:27 --> Total execution time: 0.2102
DEBUG - 2023-08-16 04:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:27 --> Total execution time: 0.1873
DEBUG - 2023-08-16 04:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:27 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:27 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:27 --> Total execution time: 0.2329
DEBUG - 2023-08-16 04:59:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:36 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:36 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:36 --> Total execution time: 0.2077
DEBUG - 2023-08-16 04:59:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:37 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:37 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:37 --> Total execution time: 0.1560
DEBUG - 2023-08-16 04:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:46 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:46 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:59:46 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\account.php 317
ERROR - 2023-08-16 11:59:46 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\account.php 317
ERROR - 2023-08-16 11:59:46 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\account.php 317
ERROR - 2023-08-16 11:59:46 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\account.php 334
ERROR - 2023-08-16 11:59:46 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\account.php 334
DEBUG - 2023-08-16 11:59:47 --> Total execution time: 0.3107
DEBUG - 2023-08-16 04:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:47 --> Total execution time: 0.1671
DEBUG - 2023-08-16 04:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:47 --> Total execution time: 0.2102
DEBUG - 2023-08-16 04:59:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:50 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 04:59:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 11:59:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 11:59:51 --> Total execution time: 0.2310
DEBUG - 2023-08-16 04:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:51 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:51 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:51 --> Total execution time: 0.2247
DEBUG - 2023-08-16 04:59:58 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:58 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:58 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:58 --> Total execution time: 0.1955
DEBUG - 2023-08-16 04:59:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 04:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 04:59:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 04:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 04:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 11:59:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 11:59:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 11:59:59 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 11:59:59 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 11:59:59 --> Total execution time: 0.1611
DEBUG - 2023-08-16 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:02 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:02 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:02 --> Total execution time: 0.1846
DEBUG - 2023-08-16 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:03 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:04 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:04 --> Total execution time: 0.1768
DEBUG - 2023-08-16 05:00:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:06 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:06 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:06 --> Total execution time: 1.0336
DEBUG - 2023-08-16 05:00:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:06 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:07 --> Total execution time: 0.2280
DEBUG - 2023-08-16 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 12:00:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 12:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:07 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:07 --> Total execution time: 0.1828
DEBUG - 2023-08-16 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:07 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:08 --> Total execution time: 0.7572
DEBUG - 2023-08-16 05:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 12:00:08 --> Total execution time: 0.8127
DEBUG - 2023-08-16 05:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 12:00:08 --> Total execution time: 0.9331
DEBUG - 2023-08-16 05:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 12:00:08 --> Total execution time: 0.8627
DEBUG - 2023-08-16 05:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:08 --> Total execution time: 1.0343
DEBUG - 2023-08-16 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:08 --> Total execution time: 0.9623
DEBUG - 2023-08-16 05:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:08 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:08 --> Total execution time: 0.2451
DEBUG - 2023-08-16 05:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2509
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2454
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2431
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2684
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2771
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2783
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2861
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2881
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2908
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2876
DEBUG - 2023-08-16 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:09 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:09 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:09 --> Total execution time: 0.2883
DEBUG - 2023-08-16 05:00:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:47 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:47 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-08-16 12:00:47 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
ERROR - 2023-08-16 12:00:47 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
ERROR - 2023-08-16 12:00:47 --> Severity: Warning --> Undefined variable $selected C:\Wamp\www\git\jrn\application\views\layouts\admin\menu\configuration\menu.php 167
DEBUG - 2023-08-16 12:00:47 --> Total execution time: 0.4070
DEBUG - 2023-08-16 05:00:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:00:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 05:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 12:00:48 --> Total execution time: 0.3053
DEBUG - 2023-08-16 05:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:00:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:00:48 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:00:48 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:00:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:00:48 --> Total execution time: 0.2716
DEBUG - 2023-08-16 05:01:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:01:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:01:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:01:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:01:34 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:01:34 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:01:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:01:34 --> Total execution time: 0.2269
DEBUG - 2023-08-16 05:01:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:01:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:01:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:01:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:01:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:01:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:01:35 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:01:35 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:01:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:01:35 --> Total execution time: 0.2177
DEBUG - 2023-08-16 05:02:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:02:13 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:02:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:02:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:02:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:02:14 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:02:14 --> Total execution time: 0.1962
DEBUG - 2023-08-16 05:02:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 05:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 05:02:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 05:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 05:02:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:02:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:02:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 12:02:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 12:02:15 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 12:02:15 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 12:02:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 12:02:15 --> Total execution time: 0.2213
DEBUG - 2023-08-16 08:54:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 08:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 08:54:04 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 08:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 08:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 15:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 15:54:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 15:54:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 15:54:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 15:54:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 15:54:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 15:54:05 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 08:54:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 08:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 08:54:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-16 08:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-16 08:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 15:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 15:54:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-16 15:54:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-16 15:54:05 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-16 15:54:05 --> PHPMailer class is loaded.
DEBUG - 2023-08-16 15:54:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 15:54:05 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 15:54:05 --> Total execution time: 0.1855
