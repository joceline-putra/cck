<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-10 03:39:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-10 03:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-10 03:39:30 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-10 03:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-10 03:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-10 10:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-10 10:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-10 10:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-10 10:39:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-10 10:39:32 --> PHPMailer class is loaded.
DEBUG - 2023-08-10 10:39:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-10 10:39:32 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-10 10:39:32 --> Total execution time: 2.5077
