<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-15 06:03:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-15 06:03:31 --> No URI present. Default controller set.
DEBUG - 2023-08-15 06:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 06:03:31 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-08-15 06:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-15 06:03:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-15 13:03:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-15 13:03:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-08-15 13:03:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-08-15 13:03:45 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-08-15 13:03:45 --> PHPMailer class is loaded.
DEBUG - 2023-08-15 13:03:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-08-15 13:03:45 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-08-15 13:03:45 --> Total execution time: 13.5964
