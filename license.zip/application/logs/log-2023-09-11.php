<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-11 07:07:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:07:13 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:07:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:07:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:07:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:07:30 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:33:11 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:33:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:33:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:33:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:33:11 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:33:11 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:33:11 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:33:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:33:12 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:33:12 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:33:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:33:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:33:12 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 07:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:33:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:33:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:33:12 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 07:33:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:33:14 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:33:14 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:33:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:33:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:33:15 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 07:43:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:43:29 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:43:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:43:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:43:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:43:29 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 07:49:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:49:26 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:49:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:49:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:49:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:49:26 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 07:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:49:29 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:49:29 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:49:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:49:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:49:29 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 07:58:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:58:26 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:58:26 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:58:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:58:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:58:26 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 07:58:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 07:58:40 --> No URI present. Default controller set.
DEBUG - 2023-09-11 07:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 07:58:40 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 07:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 07:58:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 07:58:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php:526) C:\Wamp\www\git\jrn\system\core\Common.php 578
ERROR - 2023-09-11 07:58:40 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\Wamp\www\git\jrn\application\libraries\PHPExcel\Shared\String.php 526
DEBUG - 2023-09-11 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 08:00:08 --> No URI present. Default controller set.
DEBUG - 2023-09-11 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 08:00:08 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/pagination.php
DEBUG - 2023-09-11 08:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-11 08:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:00:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:00:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/email.php
DEBUG - 2023-09-11 15:00:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/whatsapp.php
DEBUG - 2023-09-11 15:00:10 --> Config file loaded: C:\Wamp\www\git\jrn\application\config/firebase.php
DEBUG - 2023-09-11 15:00:11 --> PHPMailer class is loaded.
DEBUG - 2023-09-11 15:00:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:00:11 --> Phpmailer_lib class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:00:11 --> Total execution time: 3.0898
