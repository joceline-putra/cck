<script>
    function headerMenu() {
        $("body").toggleMenu();
        // $("#horizontal-menu").css('margin-left','0!important');
        // $("#page-content").css("margin-left","0");
    }
</script>