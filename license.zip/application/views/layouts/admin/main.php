<?php
if (isset($_view) && $_view)
    $this->load->view($_view);
?>
