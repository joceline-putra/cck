<?php defined('BASEPATH') OR exit('No direct script access allowed');

//Teknologi Dolphin
// $config = array(
// 	'apiKey' => 'AIzaSyDzMPLXej0dRKyt_SBGIMvEiOgfV0fvVPQ',
// 	'authDomain' => 'push-notification-61e32.firebaseapp.com',
// 	'databaseURL' => 'https://push-notification-61e32.firebaseio.com',
// 	'projectId' => 'push-notification-61e32',
// 	'storageBucket' => 'push-notification-61e32.appspot.com',
// 	'messagingSenderId' => '319706332594',
// 	'appId' => '1:319706332594:web:bee9b735478bc08c',
//	'measurementId' => ''
// );

//Joceline Putra
// $config = array(
// 	'apiKey' => 'AIzaSyBf0wGlvt4vbL22BXgiZ-zggBG0uafrSYw',
// 	'authDomain' => 'jurnal-cloud.firebaseapp.com',
// 	'databaseURL' => 'https://jurnal-cloud-default-rtdb.firebaseio.com',
// 	'projectId' => 'jurnal-cloud',
// 	'storageBucket' => 'jurnal-cloud.appspot.com',
// 	'messagingSenderId' => '352276204080',
// 	'appId' => '1:352276204080:web:a864e471c75a1d67547bf5',
// 	'measurementId' => 'G-7LG1FH72WK'
// );

//GPS
// $config = array(
// 	'apiKey' => 'AIzaSyD_F_psdMsvNMaymo5irWGNzFSX77QvfvM-zggBG0uafrSYw',
// 	'authDomain' => 'gps-ef89e.firebaseapp.com',
// 	'databaseURL' => 'https://gps-ef89e-default-rtdb.asia-southeast1.firebasedatabase.app',
// 	'projectId' => 'gps-ef89e',
// 	'storageBucket' => 'gps-ef89e.appspot.com',
// 	'messagingSenderId' => '270408891308',
// 	'appId' => '1:270408891308:web:39aaf90974cb08abc6d809',
//     'measurementId' => 'G-CDZ73LK019'
// );

//JRN
// $config = array(
// 	'apiKey' => 'AIzaSyBkcyYTcQc14mUjbTiemOf-uq48sYSSSss',
// 	'authDomain' => 'jrncloud-e51c0.firebaseapp.com',
// 	'databaseURL' => 'https://jrncloud-e51c0-default-rtdb.asia-southeast1.firebasedatabase.app',
// 	'projectId' => 'jrncloud-e51c0',
// 	'storageBucket' => 'jrncloud-e51c0.appspot.com',
// 	'messagingSenderId' => '408501365104',
// 	'appId' => '1:408501365104:web:ad678df3675500540bc7b5',
// 	'measurementId' => 'G-D55SRNX1PB'    
// );

// JOE
$config = array(
	'apiKey' => 'AIzaSyA4JqoY-8DgrTw81Yg_cJyEwpXoMvbRYzo',
	'authDomain' => 'joe-cloud.firebaseapp.com',
	'databaseURL' => 'https://joe-cloud-default-rtdb.asia-southeast1.firebasedatabase.app',
	'projectId' => 'joe-cloud',
	'storageBucket' => 'joe-cloud.appspot.com',
	'messagingSenderId' => '370746377418',
	'appId' => '1:370746377418:web:7aef0b601f5950ff2be033',
	'measurementId' => 'G-CX8FTGQ0B7'    
);